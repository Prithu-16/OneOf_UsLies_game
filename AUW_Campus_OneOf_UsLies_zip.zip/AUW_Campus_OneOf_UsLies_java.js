/* ==========================================================================
   STANDALONE OFFLINE EXPORTER
   ========================================================================== */
function downloadOfflineGame() {
    sfx.click();
    const htmlContent = '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AUW_Campus_Security_Breach.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/* ==========================================================================
   10 AUW STUDENT COUNTRIES (WHITE LETTERS INSIDE BOXES)
   ========================================================================== */
const COUNTRIES = [
    { id: 'bd', code: 'BD', name: 'Bangladesh',  flag: '🇧🇩', color: '#10b981' },
    { id: 'in', code: 'IN', name: 'India',       flag: '🇮🇳', color: '#f97316' },
    { id: 'pk', code: 'PK', name: 'Pakistan',    flag: '🇵🇰', color: '#22c55e' },
    { id: 'np', code: 'NP', name: 'Nepal',       flag: '🇳🇵', color: '#ef4444' },
    { id: 'bt', code: 'BT', name: 'Bhutan',      flag: '🇧🇹', color: '#facc15' },
    { id: 'lk', code: 'LK', name: 'Sri Lanka',   flag: '🇱🇰', color: '#eab308' },
    { id: 'vn', code: 'VN', name: 'Vietnam',     flag: '🇻🇳', color: '#dc2626' },
    { id: 'mm', code: 'MM', name: 'Myanmar',     flag: '🇲🇲', color: '#84cc16' },
    { id: 'af', code: 'AF', name: 'Afghanistan', flag: '🇦🇫', color: '#3b82f6' },
    { id: 'cn', code: 'CN', name: 'China',       flag: '🇨🇳', color: '#f43f5e' }
];
let selectedCountry = COUNTRIES[0];

function renderCountrySelection() {
    const grid = document.getElementById('country-grid');
    if (!grid) return;
    grid.innerHTML = '';
    COUNTRIES.forEach(c => {
        const isSelected = selectedCountry.id === c.id;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `p-2 rounded-xl border-2 text-center transition flex flex-col items-center justify-center ${
            isSelected
                ? 'border-amber-400 bg-amber-950/60 shadow-[0_0_14px_rgba(251,191,36,0.45)] scale-[1.03]'
                : 'border-slate-700 bg-slate-950/70 hover:border-cyan-400'
        }`;
        btn.innerHTML = `
            <div class="flex items-center justify-center gap-1 mb-0.5">
                <span class="text-sm font-orbitron font-black text-white">${c.code}</span>
                <span class="text-lg leading-none">${c.flag}</span>
            </div>
            <span class="text-[11px] font-bold text-white leading-tight">${c.name}</span>
        `;
        btn.onclick = () => {
            sfx.click();
            selectedCountry = c;
            document.getElementById('selected-country-badge').innerText = `${c.code} • ${c.flag} ${c.name}`;
            document.getElementById('start-btn-country').innerText = `${c.code} • ${c.flag} ${c.name.toUpperCase()}`;
            renderCountrySelection();
        };
        grid.appendChild(btn);
    });
}

/* ==========================================================================
   WEB AUDIO SOUND ENGINE, FOOTSTEPS & AMBIENT MUSIC
   ========================================================================== */
const sfx = {
    ctx: null,
    muted: false,
    musicEnabled: true,
    ambienceTimer: null,
    stepTimer: 0,
    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) this.ctx = new AudioCtx();
        }
        if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
    },
    tone(freq, type = 'sine', dur = 0.14, gainVal = 0.12) {
        if (this.muted) return;
        this.init();
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + dur);
    },
    click()        { this.tone(520, 'triangle', 0.08, 0.1); },
    error()        { this.tone(170, 'sawtooth', 0.24, 0.14); },
    swish()        { this.tone(660, 'sine', 0.22, 0.12); },
    pianoNote(f)   { this.tone(f, 'triangle', 0.35, 0.15); },
    vent()         { this.tone(240, 'square', 0.2, 0.1); },
    kill()         { this.tone(110, 'sawtooth', 0.35, 0.2); },
    footstep()     { this.tone(135 + Math.random() * 25, 'triangle', 0.05, 0.045); },
    doorSlide()    { this.tone(290, 'sine', 0.16, 0.06); },
    clueFound()    {
        this.tone(440, 'sine', 0.12, 0.11);
        setTimeout(() => this.tone(587.33, 'sine', 0.18, 0.12), 110);
    },
    paChime()      {
        this.tone(523.25, 'sine', 0.18, 0.09);
        setTimeout(() => this.tone(659.25, 'sine', 0.26, 0.09), 170);
    },
    taskComplete() {
        this.tone(523.25, 'triangle', 0.14, 0.12);
        setTimeout(() => this.tone(659.25, 'triangle', 0.14, 0.12), 110);
        setTimeout(() => this.tone(783.99, 'triangle', 0.24, 0.14), 220);
    },
    alarm() {
        this.tone(740, 'sawtooth', 0.22, 0.14);
        setTimeout(() => this.tone(480, 'sawtooth', 0.26, 0.14), 230);
    },
    startAmbience() {
        if (this.ambienceTimer) clearInterval(this.ambienceTimer);
        const droneNotes = [110, 130.81, 146.83, 123.47];
        let idx = 0;
        this.ambienceTimer = setInterval(() => {
            if (!this.musicEnabled || this.muted || gameState !== 'PLAYING') return;
            this.tone(droneNotes[idx % droneNotes.length], 'sine', 1.6, 0.032);
            idx++;
        }, 2200);
    }
};

function toggleSound() {
    sfx.muted = !sfx.muted;
    document.getElementById('btn-sound').innerText = sfx.muted ? '🔇' : '🔊';
}

function toggleMusic() {
    sfx.musicEnabled = !sfx.musicEnabled;
    document.getElementById('btn-music').innerText = sfx.musicEnabled ? '🎵' : '🔕';
}

function acknowledgeSecurityAlert() {
    sfx.init();
    sfx.alarm();
    sfx.startAmbience();
    const alertModal = document.getElementById('modal-security-alert');
    alertModal.classList.add('opacity-0', 'scale-105', 'pointer-events-none');
    setTimeout(() => {
        alertModal.classList.add('hidden');
        renderCountrySelection();
        renderCharacterCustomizer();
        document.getElementById('modal-role-select').classList.remove('hidden');
        gameState = 'ROLE_SELECT';
    }, 350);
}

/* ==========================================================================
   AUW CAMPUS MAP ARCHITECTURE (9 CONNECTED ROOMS + SEAMLESS CORRIDORS)
   ========================================================================== */
const ROOMS = [
    { id: 'library',     name: 'Library',          x: 160,  y: 160, w: 520, h: 360, fill: '#261e2e', border: '#6b5b7b' },
    { id: 'cafeteria',   name: 'Cafeteria',        x: 840,  y: 160, w: 560, h: 360, fill: '#2b221e', border: '#7c5e4b' },
    { id: 'classroom',   name: 'Classroom',        x: 1560, y: 160, w: 520, h: 360, fill: '#291f24', border: '#775362' },
    { id: 'lab',         name: 'Lab room',         x: 2240, y: 160, w: 520, h: 360, fill: '#1a2726', border: '#4a706c' },
    { id: 'tales',       name: 'Tales space',      x: 160,  y: 720, w: 520, h: 360, fill: '#1c2530', border: '#4f6982' },
    { id: 'dinning',     name: 'Dinning',          x: 840,  y: 720, w: 560, h: 360, fill: '#2a251c', border: '#786b4d' },
    { id: 'residential', name: 'Residential',      x: 1560, y: 720, w: 520, h: 360, fill: '#2a1f22', border: '#75535b' },
    { id: 'basketball',  name: 'Basketball Field', x: 2240, y: 720, w: 520, h: 360, fill: '#1d2b22', border: '#4e735c' },
    { id: 'garden',      name: 'Campus Garden',    x: 840,  y: 1220, w: 560, h: 340, fill: '#1e2c23', border: '#527960' }
];

const CORRIDORS = [
    { x: 680,  y: 300, w: 160, h: 90 },
    { x: 1400, y: 300, w: 160, h: 90 },
    { x: 2080, y: 300, w: 160, h: 90 },
    { x: 680,  y: 860, w: 160, h: 90 },
    { x: 1400, y: 860, w: 160, h: 90 },
    { x: 2080, y: 860, w: 160, h: 90 },
    { x: 375,  y: 520, w: 90,  h: 200 },
    { x: 1075, y: 520, w: 90,  h: 200 },
    { x: 1775, y: 520, w: 90,  h: 200 },
    { x: 2455, y: 520, w: 90,  h: 200 },
    { x: 1075, y: 1080, w: 90, h: 140 }
];

const VENTS = [
    { id: 0, x: 230,  y: 230,  room: 'Library',          to: 1 },
    { id: 1, x: 2680, y: 230,  room: 'Lab room',         to: 2 },
    { id: 2, x: 2680, y: 1010, room: 'Basketball Field', to: 3 },
    { id: 3, x: 230,  y: 1010, room: 'Tales space',      to: 0 }
];

const EMERGENCY_BUTTON = { x: 1120, y: 285, r: 34 };
const POWER_BREAKER = { x: 2295, y: 265, w: 46, h: 46 };

// CCTV Security Console inside Lab Room + Live Camera Feeds for all other Campus Rooms
const CCTV_TERMINAL = { x: 2375, y: 265, w: 66, h: 52 };
const CCTV_CAMERAS = [
    { id: 'cam1', name: 'CAM 01 • LIBRARY',          x: 420,  y: 340, room: 'Library' },
    { id: 'cam2', name: 'CAM 02 • CAFETERIA',        x: 1120, y: 340, room: 'Cafeteria' },
    { id: 'cam3', name: 'CAM 03 • CLASSROOM',        x: 1820, y: 340, room: 'Classroom' },
    { id: 'cam4', name: 'CAM 04 • TALES SPACE',      x: 420,  y: 900, room: 'Tales space' },
    { id: 'cam5', name: 'CAM 05 • DINNING',          x: 1120, y: 900, room: 'Dinning' },
    { id: 'cam6', name: 'CAM 06 • RESIDENTIAL',      x: 1820, y: 900, room: 'Residential' },
    { id: 'cam7', name: 'CAM 07 • BASKETBALL FIELD', x: 2500, y: 900, room: 'Basketball Field' },
    { id: 'cam8', name: 'CAM 08 • CAMPUS GARDEN',    x: 1120, y: 1390, room: 'Campus Garden' }
];

const CLUES = [
    { id: 'c1', room: 'Library',     x: 245,  y: 440, title: 'Torn Maroon Lanyard',      detail: 'Found behind the archives shelf—someone fled in a hurry toward the east corridor.', found: false },
    { id: 'c2', room: 'Cafeteria',   x: 1325, y: 445, title: 'Dropped Master Keycard',   detail: 'An unlabelled security keycard dropped near the cafeteria exit.', found: false },
    { id: 'c3', room: 'Residential', x: 1625, y: 1015, title: 'Muddy Courtyard Footprints', detail: 'Wet footprints leading from the outdoor garden straight into the dormitory hall.', found: false },
    { id: 'c4', room: 'Classroom',   x: 2015, y: 435, title: 'Encrypted Schedule Note',  detail: 'A crumpled note listing campus power breaker timings.', found: false },
    { id: 'c5', room: 'Tales space', x: 615,  y: 805, title: 'Scraped Vent Cover',       detail: 'Fresh scratch marks around the corner vent screws!', found: false }
];

const DOORS = CORRIDORS.map((c, idx) => ({
    id: idx,
    x: c.x + c.w / 2,
    y: c.y + c.h / 2,
    w: c.w < c.h ? c.w : 24,
    h: c.w < c.h ? 24 : c.h,
    horizontal: c.w > c.h,
    openAmount: 0,
    locked: false
}));

const TASKS = [
    {
        id: 1, key: 'cafeteria', roomName: 'Cafeteria',
        title: 'Eat Smart! (Nutrition & Budget)', objectLabel: 'FOOD COUNTER & MENU', icon: '🥗',
        desc: 'Select a healthy balanced meal (Protein + Carbs + Vegetables + Fruit/Drink) within your 250 BDT student budget.',
        x: 930, y: 255, w: 106, h: 52, completed: false
    },
    {
        id: 2, key: 'dinning', roomName: 'Dinning',
        title: 'Waste Less, Save More!', objectLabel: 'SORTING BINS STATION', icon: '♻️',
        desc: 'Identify each dining hall waste item and sort it into Recycling, Compost, or General Waste with instant eco-feedback.',
        x: 1120, y: 900, w: 108, h: 52, completed: false
    },
    {
        id: 3, key: 'library', roomName: 'Library',
        title: 'Think Before You Search', objectLabel: 'RESEARCH DESK & ARCHIVE', icon: '📖',
        desc: 'Search the library catalog and complete the information-literacy quiz to spot reliable sources vs fake news.',
        x: 420, y: 265, w: 96, h: 52, completed: false
    },
    {
        id: 4, key: 'lab', roomName: 'Lab room',
        title: 'Digital Safety & Cyber Lab', objectLabel: 'CYBER SECURITY TERMINAL', icon: '💻',
        desc: 'Identify phishing emails, build a strong password, repair basic HTML tags, and answer online privacy checks.',
        x: 2500, y: 250, w: 102, h: 52, completed: false
    },
    {
        id: 5, key: 'garden', roomName: 'Campus Garden',
        title: 'Keep It Green!', objectLabel: 'GARDEN FOUNTAIN & PLANTERS', icon: '🌿',
        desc: 'Water campus plants, identify native flora, sort garden recyclables, and practice water conservation.',
        x: 1120, y: 1380, w: 112, h: 54, completed: false
    },
    {
        id: 6, key: 'residential', roomName: 'Residential',
        title: 'Dormitory Door Unlock', objectLabel: 'DORM SECURITY DOOR', icon: '🔐',
        desc: 'Complete the 5×5 Sudoku keypad so each row and column contains numbers 1 to 5 without repeating.',
        x: 1820, y: 775, w: 96, h: 46, completed: false
    },
    {
        id: 7, key: 'classroom', roomName: 'Classroom',
        title: 'CSS Colour Modification', objectLabel: 'CLASSROOM SMART BOARD', icon: '🎨',
        desc: 'Apply the required CSS colours to the sky, sun, and campus hill in the live scenery preview.',
        x: 1820, y: 245, w: 110, h: 48, completed: false
    },
    {
        id: 8, key: 'basketball', roomName: 'Basketball Field',
        title: 'Basketball Shooting', objectLabel: 'BASKETBALL & HOOP', icon: '🏀',
        desc: 'Aim and shoot the basketball into the hoop! Score at least 3 baskets within 6 attempts.',
        x: 2500, y: 900, w: 90, h: 54, completed: false
    },
    {
        id: 9, key: 'tales', roomName: 'Tales space',
        title: 'Piano Lesson', objectLabel: 'TALES SPACE GRAND PIANO', icon: '🎹',
        desc: 'Follow the musical guidebook and play the melody sequence: C - E - G - E - C on the piano keys.',
        x: 420, y: 900, w: 105, h: 54, completed: false
    }
];

/* ==========================================================================
   GAME STATE, CHARACTER CUSTOMIZER (OUTFIT + DRESS COLOURS) & CONTROLS
   ========================================================================== */
let selectedRole = 'CREWMATE';
let connectionMode = 'OFFLINE';
let activeRoomCode = 'AUW-SERVER-1';
let lastNetSync = 0;
let syncedPaId = 0;
let activeMeetingState = null;
let onlineLobbyCount = 0;
let gameState = 'ALERT';
let players = [];
let deadBodies = [];
let localPlayer = null;
let sabotageLights = false;
let killCooldown = 0;
let sabotageCooldown = 0;
let disguiseCooldown = 0;
let disguiseTimer = 0;
let disguiseAppearance = null;
let activeTask = null;
let checklistVisible = true;
let meetingInterval = null;
let campusScore = 0;
let roundElapsedTime = 0;
let nextRandomEventTimer = 24;
let lockdownTimer = 0;
let activeCctvIdx = 0;
let witnessReports = [];
let weatherMode = 'CLOUDY';
let rainDrops = Array.from({ length: 75 }, () => ({
    x: Math.random() * 1600,
    y: Math.random() * 1000,
    len: 10 + Math.random() * 10,
    speed: 420 + Math.random() * 180
}));
const keys = {};
const dpad = { up: false, down: false, left: false, right: false };

const CHAR_COLORS = [
    { id: 'pink',     name: 'Pastel Pink',   main: '#f9a8d4', shade: '#ec4899', trim: '#fce7f3' },
    { id: 'lavender', name: 'Lavender',      main: '#c4b5fd', shade: '#8b5cf6', trim: '#ede9fe' },
    { id: 'skyblue',  name: 'Sky Blue',      main: '#7dd3fc', shade: '#0284c7', trim: '#e0f2fe' },
    { id: 'mint',     name: 'Mint Green',    main: '#6ee7b7', shade: '#059669', trim: '#d1fae5' },
    { id: 'yellow',   name: 'Butter Yellow', main: '#fde047', shade: '#ca8a04', trim: '#fef9c3' },
    { id: 'peach',    name: 'Peach',         main: '#fdba74', shade: '#ea580c', trim: '#ffedd5' },
    { id: 'red',      name: 'Crimson Red',   main: '#f87171', shade: '#dc2626', trim: '#fee2e2' },
    { id: 'navy',     name: 'Dark Navy',     main: '#3b82f6', shade: '#1e3a8a', trim: '#dbeafe' }
];

const DRESS_COLORS = [
    { id: 'rose',     name: 'Rose Dress',     main: '#f43f5e', hem: '#ffe4e6' },
    { id: 'emerald',  name: 'Emerald Dress',  main: '#10b981', hem: '#d1fae5' },
    { id: 'cobalt',   name: 'Cobalt Dress',   main: '#2563eb', hem: '#dbeafe' },
    { id: 'violet',   name: 'Violet Dress',   main: '#7c3aed', hem: '#ede9fe' },
    { id: 'marigold', name: 'Marigold Dress', main: '#f59e0b', hem: '#fef3c7' },
    { id: 'teal',     name: 'Teal Dress',     main: '#0d9488', hem: '#ccfbf1' },
    { id: 'coral',    name: 'Coral Dress',    main: '#fb7185', hem: '#fff1f2' },
    { id: 'plum',     name: 'Plum Dress',     main: '#9d174d', hem: '#fce7f3' }
];

const CHAR_ACCESSORIES = [
    { id: 'headphones', name: 'Headphones', icon: '🎧' },
    { id: 'bow',        name: 'Ribbon Bow', icon: '🎀' },
    { id: 'glasses',    name: 'Glasses',    icon: '👓' },
    { id: 'backpack',   name: 'Backpack',   icon: '🎒' },
    { id: 'cap',        name: 'Campus Cap', icon: '🧢' },
    { id: 'hairclip',   name: 'Star Clip',  icon: '⭐' },
    { id: 'hat',        name: 'Beret Hat',  icon: '🎩' },
    { id: 'none',       name: 'Minimal',    icon: '✨' }
];

let selectedCharColor = CHAR_COLORS[0];
let selectedDressColor = DRESS_COLORS[0];
let selectedCharAcc = CHAR_ACCESSORIES[0];
let previewAnimState = 'walk';

function setPreviewAnim(mode) {
    sfx.click();
    previewAnimState = mode;
}

function updateCharCustomizerBadge() {
    const badge = document.getElementById('selected-char-badge');
    if (badge) badge.innerText = `${selectedCharColor.name} • ${selectedDressColor.name} • ${selectedCharAcc.name}`;
}

function renderCharacterCustomizer() {
    const colorGrid = document.getElementById('char-color-grid');
    const dressGrid = document.getElementById('char-dress-grid');
    const accGrid = document.getElementById('char-acc-grid');
    if (!colorGrid || !dressGrid || !accGrid) return;

    colorGrid.innerHTML = '';
    CHAR_COLORS.forEach(c => {
        const active = selectedCharColor.id === c.id;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.title = c.name;
        btn.className = `w-6 h-6 rounded-full border-2 transition ${active ? 'border-white scale-110 shadow-[0_0_10px_rgba(255,255,255,0.7)]' : 'border-slate-700 opacity-85 hover:opacity-100'}`;
        btn.style.background = c.main;
        btn.onclick = () => {
            sfx.click();
            selectedCharColor = c;
            updateCharCustomizerBadge();
            renderCharacterCustomizer();
        };
        colorGrid.appendChild(btn);
    });

    dressGrid.innerHTML = '';
    DRESS_COLORS.forEach(d => {
        const active = selectedDressColor.id === d.id;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.title = d.name;
        btn.className = `px-2 py-0.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition ${
            active ? 'border-amber-400 bg-amber-950/70 text-white scale-105' : 'border-slate-700 bg-slate-900 text-slate-200 hover:border-cyan-400'
        }`;
        btn.innerHTML = `<span class="w-2.5 h-2.5 rounded-full inline-block border border-white/40" style="background:${d.main}"></span><span>${d.name.replace(' Dress', '')}</span>`;
        btn.onclick = () => {
            sfx.click();
            selectedDressColor = d;
            updateCharCustomizerBadge();
            renderCharacterCustomizer();
        };
        dressGrid.appendChild(btn);
    });

    accGrid.innerHTML = '';
    CHAR_ACCESSORIES.forEach(acc => {
        const active = selectedCharAcc.id === acc.id;
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `px-2 py-0.5 rounded-lg border text-[10px] font-bold transition ${
            active ? 'border-amber-400 bg-amber-950/70 text-amber-200' : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-cyan-400'
        }`;
        btn.innerText = `${acc.icon} ${acc.name}`;
        btn.onclick = () => {
            sfx.click();
            selectedCharAcc = acc;
            updateCharCustomizerBadge();
            renderCharacterCustomizer();
        };
        accGrid.appendChild(btn);
    });
    updateCharCustomizerBadge();
}

function drawCharacterPreviewLoop() {
    const pCanvas = document.getElementById('preview-character');
    if (pCanvas && gameState === 'ROLE_SELECT') {
        const pCtx = pCanvas.getContext('2d');
        pCtx.clearRect(0, 0, pCanvas.width, pCanvas.height);
        pCtx.save();
        pCtx.translate(42, 54);
        pCtx.scale(1.45, 1.45);
        drawOriginalCharacter(pCtx, {
            charColor: selectedCharColor,
            dressColor: selectedDressColor,
            accessory: selectedCharAcc.id,
            facingRight: true,
            animState: previewAnimState,
            animTime: performance.now() / 1000
        });
        pCtx.restore();
    }
    requestAnimationFrame(drawCharacterPreviewLoop);
}

function selectRole(role) {
    sfx.click();
    selectedRole = role;
    const crewBtn = document.getElementById('btn-pick-crewmate');
    const impBtn = document.getElementById('btn-pick-impostor');
    if (role === 'IMPOSTOR') {
        impBtn.className = 'p-3 rounded-2xl border-4 border-red-400 bg-red-950/70 text-center transition';
        crewBtn.className = 'p-3 rounded-2xl border-4 border-slate-700 bg-slate-950/70 text-center transition';
    } else {
        crewBtn.className = 'p-3 rounded-2xl border-4 border-cyan-400 bg-cyan-950/70 text-center transition';
        impBtn.className = 'p-3 rounded-2xl border-4 border-slate-700 bg-slate-950/70 text-center transition';
    }
}

function showOnlineSetupError(msg) {
    const box = document.getElementById('online-setup-error');
    const txt = document.getElementById('online-setup-error-text');
    const pill = document.getElementById('network-status-pill');
    if (box && txt) {
        txt.innerText = msg;
        box.classList.remove('hidden');
    }
    if (pill) {
        pill.innerText = '❌ ONLINE ERROR';
        pill.className = 'px-2 py-0.5 rounded-full bg-red-950 border border-red-400 text-[10px] font-bold text-red-200';
    }
}

function clearOnlineSetupError() {
    const box = document.getElementById('online-setup-error');
    if (box) box.classList.add('hidden');
}

function retryOnlineConnection() {
    sfx.click();
    clearOnlineSetupError();
    selectConnectionMode('ONLINE');
}

function selectConnectionMode(mode) {
    sfx.click();
    connectionMode = mode;
    const offBtn = document.getElementById('btn-mode-offline');
    const onBtn = document.getElementById('btn-mode-online');
    const offPanel = document.getElementById('offline-mode-panel');
    const onPanel = document.getElementById('online-mode-panel');
    const pill = document.getElementById('network-status-pill');

    if (mode === 'ONLINE') {
        clearOnlineSetupError();
        onBtn.className = 'p-2.5 rounded-xl border-2 border-cyan-400 bg-cyan-950/70 text-left transition';
        offBtn.className = 'p-2.5 rounded-xl border-2 border-slate-700 bg-slate-900/80 text-left transition hover:border-emerald-400';
        offPanel.classList.add('hidden');
        onPanel.classList.remove('hidden');
        pill.innerText = '⏳ CONNECTING TO ONLINE SERVER...';
        pill.className = 'px-2 py-0.5 rounded-full bg-amber-950 border border-amber-400 text-[10px] font-bold text-amber-200';
        if (window.mpBackend) {
            window.mpBackend.renderServerBrowser([]);
            window.mpBackend.ensureAuth().then(uid => {
                const uidEl = document.getElementById('online-uid-display');
                if (uid) {
                    pill.innerText = '🟢 ONLINE SERVER CONNECTED';
                    pill.className = 'px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-400 text-[10px] font-bold text-cyan-300';
                    if (uidEl) uidEl.innerText = `Player ID: ${uid.slice(0, 14)}`;
                    window.mpBackend.watchServerList();
                } else {
                    showOnlineSetupError('❌ Could not connect to the online multiplayer server. Check your internet connection and click RETRY.');
                    if (uidEl) uidEl.innerText = 'Offline / Unreachable';
                }
            });
        }
    } else {
        offBtn.className = 'p-2.5 rounded-xl border-2 border-emerald-400 bg-emerald-950/70 text-left transition';
        onBtn.className = 'p-2.5 rounded-xl border-2 border-slate-700 bg-slate-900/80 text-left transition hover:border-cyan-400';
        onPanel.classList.add('hidden');
        offPanel.classList.remove('hidden');
        pill.innerText = '📴 OFFLINE MODE READY';
        pill.className = 'px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-400 text-[10px] font-bold text-emerald-300';
    }
}

function generateRandomRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let suffix = '';
    for (let i = 0; i < 6; i++) {
        suffix += chars[Math.floor(Math.random() * chars.length)];
    }
    const code = 'AUW-' + suffix;
    const inp = document.getElementById('online-room-code');
    if (inp) inp.value = code;
    return code;
}

function createNewOnlineRoom() {
    sfx.click();
    clearOnlineSetupError();
    connectionMode = 'ONLINE';
    const newCode = generateRandomRoomCode();
    activeRoomCode = newCode;
    initGame(true);
}

function joinEnteredOnlineRoom() {
    sfx.click();
    clearOnlineSetupError();
    connectionMode = 'ONLINE';
    const inp = document.getElementById('online-room-code');
    const raw = (inp ? inp.value : '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    if (!raw) {
        showOnlineSetupError('⚠️ Please enter a valid Room Code (e.g. AUW-7K9P2M) before joining.');
        return;
    }
    if (inp) inp.value = raw;
    activeRoomCode = raw;
    initGame(false);
}

function copyRoomCode() {
    sfx.click();
    const inp = document.getElementById('online-room-code');
    if (!inp) return;
    const code = (inp.value.trim() || 'AUW-SERVER-1').toUpperCase();
    inp.value = code;
    const temp = document.createElement('textarea');
    temp.value = code;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand('copy');
    document.body.removeChild(temp);
    const btn = document.getElementById('btn-copy-room');
    if (btn) {
        btn.innerText = '✅';
        setTimeout(() => { btn.innerText = '📋'; }, 1600);
    }
}

function copyLobbyServerCode() {
    sfx.click();
    const code = activeRoomCode || 'AUW-SERVER-1';
    const temp = document.createElement('textarea');
    temp.value = code;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand('copy');
    document.body.removeChild(temp);
    const btn = document.getElementById('btn-lobby-copy');
    if (btn) {
        btn.innerText = '✅ COPIED!';
        setTimeout(() => { btn.innerText = '📋 COPY ROOM CODE'; }, 1600);
    }
}

function sendLobbyChatMessage() {
    const inp = document.getElementById('lobby-chat-input');
    if (!inp) return;
    const msg = inp.value.trim();
    if (!msg || !window.mpBackend) return;
    sfx.click();
    window.mpBackend.sendLobbyChat(`${selectedCountry.flag} ${selectedCountry.name}`, selectedCharColor.main, msg);
    inp.value = '';
}

function requestStartOnlineMatch() {
    if (!window.mpBackend) return;
    sfx.click();
    window.mpBackend.launchOnlineMatchFromLobby();
}

function leaveOnlineLobby() {
    sfx.click();
    if (window.mpBackend) window.mpBackend.leaveRoom();
    document.getElementById('modal-online-lobby').classList.add('hidden');
    document.getElementById('modal-role-select').classList.remove('hidden');
    gameState = 'ROLE_SELECT';
}

function returnToRoleSelect() {
    sfx.click();
    if (window.mpBackend) window.mpBackend.leaveRoom();
    document.getElementById('modal-gameover').classList.add('hidden');
    document.getElementById('modal-online-lobby').classList.add('hidden');
    document.getElementById('modal-role-select').classList.remove('hidden');
    renderCountrySelection();
    renderCharacterCustomizer();
    gameState = 'ROLE_SELECT';
}

async function initGame(isCreatingRoom = false) {
    sfx.init();
    sfx.click();

    if (connectionMode === 'ONLINE') {
        clearOnlineSetupError();
        if (!window.mpBackend || !window.mpBackend.available) {
            showOnlineSetupError('❌ Online multiplayer module unavailable. Please refresh and check internet connection.');
            return;
        }
        const uid = await window.mpBackend.ensureAuth();
        if (!uid) {
            showOnlineSetupError('❌ Failed to connect to the public online server. Check your internet connection and retry.');
            return;
        }

        const roomInp = document.getElementById('online-room-code');
        const rawCode = (roomInp ? roomInp.value : 'AUW-SERVER-1').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
        if (!rawCode) {
            showOnlineSetupError('⚠️ Enter a valid Room Code or click CREATE NEW ROOM.');
            return;
        }
        activeRoomCode = rawCode;

        const joinResult = await window.mpBackend.joinServerLobby(activeRoomCode, {
            uid,
            name: selectedCountry.name,
            flag: selectedCountry.flag,
            color: selectedCharColor.main,
            charColor: selectedCharColor,
            dressColor: selectedDressColor,
            accessory: selectedCharAcc.id,
            preferredRole: selectedRole
        }, { createNew: Boolean(isCreatingRoom) });

        if (!joinResult || !joinResult.ok) {
            showOnlineSetupError((joinResult && joinResult.error) || `❌ Could not join room "${activeRoomCode}". Verify the room code and try again.`);
            return;
        }

        const lobbyErr = document.getElementById('lobby-error-banner');
        if (lobbyErr) lobbyErr.classList.add('hidden');
        document.getElementById('modal-role-select').classList.add('hidden');
        document.getElementById('modal-online-lobby').classList.remove('hidden');
        gameState = 'ONLINE_LOBBY';
        return;
    }

    if (window.mpBackend) window.mpBackend.leaveRoom();
    document.getElementById('modal-role-select').classList.add('hidden');

    deadBodies = [];
    sabotageLights = false;
    killCooldown = 8;
    sabotageCooldown = 10;
    disguiseCooldown = 5;
    disguiseTimer = 0;
    disguiseAppearance = null;
    campusScore = 0;
    roundElapsedTime = 0;
    nextRandomEventTimer = 22;
    lockdownTimer = 0;
    witnessReports = [];
    syncedPaId = 0;
    activeMeetingState = null;
    weatherMode = Math.random() < 0.55 ? 'RAIN' : 'CLOUDY';
    const weatherBadge = document.getElementById('hud-weather-badge');
    if (weatherBadge) weatherBadge.innerText = weatherMode === 'RAIN' ? '🌧️ LIGHT RAIN' : '☁️ OVERCAST';
    TASKS.forEach(t => t.completed = false);
    CLUES.forEach(c => c.found = false);
    DOORS.forEach(d => { d.openAmount = 0; d.locked = false; });

    const connBadge = document.getElementById('hud-connection-badge');
    if (connBadge) {
        connBadge.innerText = '📴 OFFLINE';
        connBadge.className = 'bg-slate-900/90 border border-emerald-400/70 px-2.5 py-1.5 rounded-xl font-orbitron font-black text-[10px] text-emerald-300 shadow-lg';
    }

    const otherCountries = COUNTRIES.filter(c => c.id !== selectedCountry.id);
    const roster = [
        { name: selectedCountry.name, flag: selectedCountry.flag, color: selectedCountry.color },
        ...otherCountries.map(c => ({ name: c.name, flag: c.flag, color: c.color }))
    ];

    const impostorIndices = new Set();
    if (selectedRole === 'IMPOSTOR') {
        impostorIndices.add(0);
    } else {
        impostorIndices.add(1 + Math.floor(Math.random() * (roster.length - 1)));
    }

    const botColors = CHAR_COLORS.filter(c => c.id !== selectedCharColor.id);
    const botDresses = DRESS_COLORS.filter(d => d.id !== selectedDressColor.id);
    const botAccs = ['bow', 'glasses', 'backpack', 'cap', 'hairclip', 'hat', 'headphones', 'bow', 'glasses'];

    players = roster.map((r, idx) => {
        const charColor = idx === 0 ? selectedCharColor : botColors[idx % botColors.length];
        const dressColor = idx === 0 ? selectedDressColor : botDresses[idx % botDresses.length];
        const accessory = idx === 0 ? selectedCharAcc.id : botAccs[idx % botAccs.length];
        return {
            id: idx,
            uid: null,
            isRemoteHuman: false,
            name: r.name,
            flag: r.flag,
            color: charColor.main,
            charColor,
            dressColor,
            accessory,
            isUser: idx === 0,
            isImpostor: impostorIndices.has(idx),
            isDead: false,
            x: 1000 + (idx % 5) * 60,
            y: 350 + Math.floor(idx / 5) * 60,
            targetX: 1120,
            targetY: 360,
            aiWait: Math.random() * 2,
            aiKillTimer: 12 + Math.random() * 8,
            facingRight: true,
            animState: 'idle',
            animTime: Math.random() * 5,
            celebrateTimer: 0
        };
    });

    localPlayer = players[0];

    document.getElementById('hud-player-profile').innerText = `${selectedCountry.flag} ${selectedCountry.name} (${selectedDressColor.name})`;
    const roleLbl = document.getElementById('hud-role-label');
    roleLbl.innerText = localPlayer.isImpostor ? 'IMPOSTOR' : 'CREWMATE';
    roleLbl.className = localPlayer.isImpostor ? 'text-red-400' : 'text-cyan-400';

    document.getElementById('btn-kill').classList.toggle('hidden', !localPlayer.isImpostor);
    document.getElementById('btn-vent').classList.toggle('hidden', !localPlayer.isImpostor);
    document.getElementById('btn-sabotage').classList.toggle('hidden', !localPlayer.isImpostor);
    document.getElementById('btn-disguise').classList.toggle('hidden', !localPlayer.isImpostor);

    updateTaskHUD();
    gameState = 'PLAYING';
    triggerPaAnnouncement('CAMPUS SECURITY NOTICE: Complete your tasks, inspect clues, and watch CCTV in the Lab Room.');
}

function triggerPaAnnouncement(text) {
    const bar = document.getElementById('pa-announcement-bar');
    const label = document.getElementById('pa-announcement-text');
    if (!bar || !label) return;
    sfx.paChime();
    label.innerText = text;
    bar.classList.remove('hidden');
    clearTimeout(bar._hideTimer);
    bar._hideTimer = setTimeout(() => bar.classList.add('hidden'), 6000);
}

function openCctvModal() {
    if (gameState !== 'PLAYING' || !localPlayer || getPlayerRoomName(localPlayer) !== 'Lab room') return;
    sfx.click();
    document.getElementById('modal-cctv').classList.remove('hidden');
    const tabs = document.getElementById('cctv-cam-tabs');
    tabs.innerHTML = '';
    CCTV_CAMERAS.forEach((cam, idx) => {
        const btn = document.createElement('button');
        btn.className = `px-2.5 py-1 rounded-xl border text-[10px] font-orbitron font-black ${
            idx === activeCctvIdx ? 'border-emerald-400 bg-emerald-950 text-emerald-200' : 'border-slate-700 bg-slate-800 text-slate-300'
        }`;
        btn.innerText = cam.room.toUpperCase();
        btn.onclick = () => {
            sfx.click();
            activeCctvIdx = idx;
            openCctvModal();
        };
        tabs.appendChild(btn);
    });
    document.getElementById('cctv-cam-title').innerText = CCTV_CAMERAS[activeCctvIdx].name;
}

function closeCctvModal() {
    sfx.click();
    document.getElementById('modal-cctv').classList.add('hidden');
}

function renderCctvFeed() {
    const modal = document.getElementById('modal-cctv');
    const cCanvas = document.getElementById('cctvCanvas');
    if (!modal || modal.classList.contains('hidden') || !cCanvas) return;

    const cam = CCTV_CAMERAS[activeCctvIdx];
    const cCtx = cCanvas.getContext('2d');
    cCtx.clearRect(0, 0, cCanvas.width, cCanvas.height);

    cCtx.fillStyle = '#091512';
    cCtx.fillRect(0, 0, cCanvas.width, cCanvas.height);

    cCtx.save();
    cCtx.translate(cCanvas.width / 2 - cam.x * 0.78, cCanvas.height / 2 - cam.y * 0.78);
    cCtx.scale(0.78, 0.78);

    ROOMS.forEach(r => {
        cCtx.fillStyle = r.room === cam.room || r.name === cam.room ? '#173129' : '#11211c';
        cCtx.fillRect(r.x, r.y, r.w, r.h);
        cCtx.strokeStyle = '#34d399';
        cCtx.lineWidth = 3;
        cCtx.strokeRect(r.x, r.y, r.w, r.h);
    });

    CORRIDORS.forEach(c => {
        cCtx.fillStyle = '#1b332c';
        cCtx.fillRect(c.x, c.y, c.w, c.h);
    });

    TASKS.forEach(t => {
        if (t.roomName === cam.room) {
            cCtx.fillStyle = t.completed ? '#064e3b' : '#1e293b';
            cCtx.fillRect(t.x - 36, t.y - 18, 72, 36);
            cCtx.strokeStyle = '#34d399';
            cCtx.lineWidth = 2;
            cCtx.strokeRect(t.x - 36, t.y - 18, 72, 36);
            cCtx.font = '14px sans-serif';
            cCtx.textAlign = 'center';
            cCtx.fillText(t.icon, t.x, t.y + 5);
        }
    });

    const spotted = [];
    players.forEach(p => {
        if (p.isDead) return;
        const d = Math.hypot(p.x - cam.x, p.y - cam.y);
        if (d < 340) {
            const shown = (p.isUser && disguiseTimer > 0 && disguiseAppearance) ? disguiseAppearance : p;
            spotted.push(`${shown.flag || ''} ${shown.name}`);
            cCtx.save();
            cCtx.translate(p.x, p.y);
            cCtx.font = '700 11px system-ui, sans-serif';
            cCtx.textAlign = 'center';
            cCtx.fillStyle = '#a7f3d0';
            cCtx.fillText(`${shown.flag || ''} ${shown.name}`, 0, -30);
            drawOriginalCharacter(cCtx, {
                ...shown,
                facingRight: p.facingRight,
                animState: p.animState,
                animTime: p.animTime
            });
            cCtx.restore();
        }
    });

    cCtx.restore();

    cCtx.fillStyle = 'rgba(16, 185, 129, 0.06)';
    for (let sy = 0; sy < cCanvas.height; sy += 4) {
        cCtx.fillRect(0, sy, cCanvas.width, 1);
    }

    const tsEl = document.getElementById('cctv-cam-timestamp');
    if (tsEl) {
        const nowStr = new Date().toTimeString().split(' ')[0];
        tsEl.innerText = `LAB-TERM // ${nowStr}`;
    }

    const actEl = document.getElementById('cctv-activity-tag');
    if (actEl) {
        actEl.innerText = spotted.length
            ? `LIVE FEED [${cam.room.toUpperCase()}]: ${spotted.join(', ')}`
            : `LIVE FEED [${cam.room.toUpperCase()}]: Sector clear — no students currently inside.`;
    }
}

function toggleChecklist() {
    sfx.click();
    checklistVisible = !checklistVisible;
    const list = document.getElementById('hud-task-list');
    const btn = document.getElementById('btn-toggle-list');
    if (list) list.classList.toggle('hidden', !checklistVisible);
    if (btn) btn.innerText = checklistVisible ? '▼' : '▶';
}

function updateTaskHUD() {
    const completed = TASKS.filter(t => t.completed).length;
    const total = TASKS.length;
    const countEl = document.getElementById('hud-task-count');
    const barEl = document.getElementById('hud-task-bar');
    const listEl = document.getElementById('hud-task-list');

    if (countEl) countEl.innerText = `${completed}/${total} • ${campusScore} PTS`;
    if (barEl) barEl.style.width = `${Math.round((completed / total) * 100)}%`;

    if (listEl) {
        listEl.innerHTML = TASKS.map(t => `
            <div class="flex items-center justify-between gap-1.5 px-2 py-1 rounded-lg ${t.completed ? 'bg-emerald-950/60 text-emerald-300 line-through opacity-80' : 'bg-slate-950/70 text-slate-200'}">
                <span class="truncate">${t.completed ? '✅' : '⬜'} <strong>${t.roomName}:</strong> ${t.title}</span>
            </div>
        `).join('');
    }
}

function reportBodyOrEmergency() {
    if (gameState !== 'PLAYING' || !localPlayer || localPlayer.isDead) return;
    const body = getNearbyBody();
    if (body) {
        startMeeting(`DEAD BODY REPORTED (${body.name.toUpperCase()})`);
    } else if (Math.hypot(localPlayer.x - EMERGENCY_BUTTON.x, localPlayer.y - EMERGENCY_BUTTON.y) < 95) {
        startMeeting('EMERGENCY MEETING CALLED');
    }
}

function completeTask(taskId) {
    const t = TASKS.find(item => item.id === taskId);
    if (!t) return;
    if (!t.completed) {
        t.completed = true;
        campusScore += 100;
        if (connectionMode === 'ONLINE' && window.mpBackend) {
            window.mpBackend.syncTaskCompleted(t);
        }
    }
    if (localPlayer) {
        localPlayer.celebrateTimer = 2.2;
        localPlayer.animState = 'celebrate';
    }
    sfx.taskComplete();
    updateTaskHUD();

    const toast = document.getElementById('toast-task-done');
    document.getElementById('toast-task-sub').innerText = `${t.roomName}: ${t.title} (+100 PTS)`;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 2600);
}

/* ==========================================================================
   COLLISION, ROOM DETECTION & INTERACTION SYSTEM
   ========================================================================== */
function isPointWalkable(px, py) {
    for (const d of DOORS) {
        if (d.locked) {
            const halfW = d.horizontal ? 18 : 48;
            const halfH = d.horizontal ? 48 : 18;
            if (Math.abs(px - d.x) < halfW && Math.abs(py - d.y) < halfH) {
                return false;
            }
        }
    }
    for (const r of ROOMS) {
        if (px >= r.x + 14 && px <= r.x + r.w - 14 && py >= r.y + 14 && py <= r.y + r.h - 14) {
            return true;
        }
    }
    for (const c of CORRIDORS) {
        if (px >= c.x - 24 && px <= c.x + c.w + 24 && py >= c.y - 24 && py <= c.y + c.h + 24) {
            return true;
        }
    }
    return false;
}

function getPlayerRoomName(p) {
    for (const r of ROOMS) {
        if (p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h) {
            return r.name;
        }
    }
    return 'Corridor';
}

function getNearbyTask() {
    if (!localPlayer || localPlayer.isDead) return null;
    for (const t of TASKS) {
        if (Math.hypot(localPlayer.x - t.x, localPlayer.y - t.y) < 92) {
            return t;
        }
    }
    return null;
}

function getNearbyBody() {
    if (!localPlayer || localPlayer.isDead) return null;
    for (const b of deadBodies) {
        if (Math.hypot(localPlayer.x - b.x, localPlayer.y - b.y) < 95) return b;
    }
    return null;
}

function getNearbyKillTarget() {
    if (!localPlayer || !localPlayer.isImpostor || localPlayer.isDead || killCooldown > 0) return null;
    for (const p of players) {
        if (!p.isUser && !p.isImpostor && !p.isDead && Math.hypot(localPlayer.x - p.x, localPlayer.y - p.y) < 85) {
            return p;
        }
    }
    return null;
}

function getNearbyVent() {
    if (!localPlayer || !localPlayer.isImpostor || localPlayer.isDead) return null;
    for (const v of VENTS) {
        if (Math.hypot(localPlayer.x - v.x, localPlayer.y - v.y) < 75) return v;
    }
    return null;
}

function getNearbyClue() {
    if (!localPlayer || localPlayer.isDead) return null;
    for (const c of CLUES) {
        if (!c.found && Math.hypot(localPlayer.x - c.x, localPlayer.y - c.y) < 78) return c;
    }
    return null;
}

function isNearPowerBreaker() {
    return localPlayer && !localPlayer.isDead && sabotageLights &&
        Math.hypot(localPlayer.x - POWER_BREAKER.x, localPlayer.y - POWER_BREAKER.y) < 82;
}

function isNearCctvTerminal() {
    return localPlayer && !localPlayer.isDead &&
        getPlayerRoomName(localPlayer) === 'Lab room' &&
        Math.hypot(localPlayer.x - CCTV_TERMINAL.x, localPlayer.y - CCTV_TERMINAL.y) < 95;
}

function interactWithNearby() {
    if (gameState !== 'PLAYING' || activeTask) return;

    if (isNearPowerBreaker()) {
        sabotageLights = false;
        campusScore += 50;
        sfx.taskComplete();
        updateTaskHUD();
        triggerPaAnnouncement('⚡ POWER RESTORED: Lab electrical breaker reset (+50 PTS).');
        if (connectionMode === 'ONLINE' && window.mpBackend) {
            window.mpBackend.syncSabotage(false, '⚡ POWER RESTORED: Lab electrical breaker reset.');
        }
        return;
    }

    if (isNearCctvTerminal()) {
        openCctvModal();
        return;
    }

    const clue = getNearbyClue();
    if (clue) {
        clue.found = true;
        campusScore += 40;
        sfx.clueFound();
        updateTaskHUD();
        triggerPaAnnouncement(`🔍 CLUE FOUND (${clue.title}): ${clue.detail}`);
        return;
    }

    const task = getNearbyTask();
    if (task) {
        sfx.click();
        openTaskModal(task);
        return;
    }
    if (Math.hypot(localPlayer.x - EMERGENCY_BUTTON.x, localPlayer.y - EMERGENCY_BUTTON.y) < 90) {
        startMeeting('EMERGENCY MEETING CALLED');
    }
}

function attemptKill() {
    const target = getNearbyKillTarget();
    if (!target) return;
    killPlayer(target);
    killCooldown = 14;
}

function killPlayer(victim) {
    if (victim.isDead) return;
    victim.isDead = true;
    const bodyObj = {
        x: victim.x,
        y: victim.y,
        color: victim.color,
        name: victim.name,
        charColor: victim.charColor,
        dressColor: victim.dressColor,
        accessory: victim.accessory,
        discovered: false,
        elimTime: performance.now() / 1000
    };
    deadBodies.push(bodyObj);
    sfx.kill();

    if (connectionMode === 'ONLINE' && window.mpBackend) {
        window.mpBackend.syncElimination(bodyObj, victim.uid || null);
    }

    const killer = players.find(p => p.isImpostor && !p.isDead);
    const shownKiller = (killer && killer.isUser && disguiseTimer > 0 && disguiseAppearance) ? disguiseAppearance : killer;
    players.forEach(witness => {
        if (!witness.isUser && !witness.isRemoteHuman && !witness.isDead && !witness.isImpostor && Math.hypot(witness.x - victim.x, witness.y - victim.y) < 260) {
            const room = getPlayerRoomName(victim);
            witnessReports.push(`${witness.flag} ${witness.name}: "I saw ${shownKiller ? shownKiller.name : 'someone'} near ${victim.name} in ${room}!"`);
            witness.aiWait = 0;
            witness.targetX = EMERGENCY_BUTTON.x;
            witness.targetY = EMERGENCY_BUTTON.y;
        }
    });

    if (victim.isUser) {
        endGame('ELIMINATED BY INTRUDER!', 'The disguised Impostor caught you alone on the AUW campus!', '💀', 'text-red-500');
        return;
    }
    checkWinConditions();
}

function useVent() {
    const v = getNearbyVent();
    if (!v) return;
    const dest = VENTS[v.to];
    localPlayer.x = dest.x;
    localPlayer.y = dest.y;
    sfx.vent();
}

function triggerSabotage() {
    if (!localPlayer || !localPlayer.isImpostor || sabotageCooldown > 0) return;
    sabotageLights = true;
    sabotageCooldown = 22;
    sfx.alarm();
    triggerPaAnnouncement('⚠️ POWER FAILURE: Campus lights cut! Reset breaker in Lab room.');
    if (connectionMode === 'ONLINE' && window.mpBackend) {
        window.mpBackend.syncSabotage(true, '⚠️ POWER FAILURE: Campus lights cut! Reset breaker in Lab room.');
    }
}

function activateImpostorDisguise() {
    if (!localPlayer || !localPlayer.isImpostor || disguiseCooldown > 0 || disguiseTimer > 0) return;
    const candidates = players.filter(p => !p.isUser && !p.isDead);
    if (!candidates.length) return;
    const target = candidates[Math.floor(Math.random() * candidates.length)];
    disguiseAppearance = {
        name: target.name,
        flag: target.flag,
        color: target.color,
        charColor: target.charColor,
        dressColor: target.dressColor,
        accessory: target.accessory
    };
    disguiseTimer = 15;
    disguiseCooldown = 28;
    sfx.vent();
    triggerPaAnnouncement(`🎭 DISGUISE ACTIVE: You appear as ${target.flag} ${target.name} for 15s.`);
}

function checkWinConditions() {
    if (connectionMode === 'ONLINE' && TASKS.every(t => t.completed)) {
        if (window.mpBackend) {
            window.mpBackend.syncGameOver('CREWMATES WIN!', 'All 9 AUW Campus missions were completed by the team!', '🏆', 'text-emerald-400');
        }
        endGame('CREWMATES WIN!', 'All 9 AUW Campus missions were completed by the team!', '🏆', 'text-emerald-400');
        return;
    }
    const aliveCrew = players.filter(p => !p.isDead && !p.isImpostor).length;
    const aliveImp  = players.filter(p => !p.isDead && p.isImpostor).length;
    if (aliveImp === 0) {
        if (connectionMode === 'ONLINE' && window.mpBackend) {
            window.mpBackend.syncGameOver('CREWMATES WIN!', 'The disguised intruder was voted off the AUW campus!', '🏆', 'text-emerald-400');
        }
        endGame('CREWMATES WIN!', 'The disguised intruder was voted off the AUW campus!', '🏆', 'text-emerald-400');
    } else if (aliveImp >= aliveCrew) {
        if (connectionMode === 'ONLINE' && window.mpBackend) {
            window.mpBackend.syncGameOver('IMPOSTOR WINS!', 'The intruder took over the AUW campus!', '🔪', 'text-red-500');
        }
        endGame('IMPOSTOR WINS!', 'The intruder took over the AUW campus!', '🔪', 'text-red-500');
    }
}

function endGame(title, desc, emoji, colorClass) {
    if (activeTask) closeTaskModal();
    if (meetingInterval) clearInterval(meetingInterval);
    document.getElementById('modal-meeting').classList.add('hidden');
    gameState = 'GAMEOVER';
    document.getElementById('gameover-emoji').innerText = emoji;
    const tEl = document.getElementById('gameover-title');
    tEl.innerText = title;
    tEl.className = `font-orbitron font-black text-2xl sm:text-4xl mb-2 ${colorClass}`;
    document.getElementById('gameover-desc').innerText = desc;

    const completedCount = TASKS.filter(t => t.completed).length;
    const foundCluesCount = CLUES.filter(c => c.found).length;
    document.getElementById('scoreboard-country').innerText = `${selectedCountry.flag} ${selectedCountry.name}`;
    document.getElementById('scoreboard-tasks').innerText = `${completedCount} / ${TASKS.length}`;
    document.getElementById('scoreboard-points').innerText = `${campusScore} PTS`;
    document.getElementById('scoreboard-survival').innerText = `${Math.floor(roundElapsedTime)}s • ${foundCluesCount}/${CLUES.length} Clues`;

    const achWrap = document.getElementById('scoreboard-achievements');
    if (achWrap) {
        const badges = [];
        if (completedCount === TASKS.length) badges.push('🎓 AUW Honor Scholar');
        else if (completedCount >= 5) badges.push('📚 Diligent Student');
        if (foundCluesCount >= 3) badges.push('🔍 Campus Detective');
        if (roundElapsedTime >= 60) badges.push('🛡️ Campus Survivor');
        if (localPlayer && localPlayer.isImpostor) badges.push('🎭 Master of Disguise');
        if (badges.length === 0) badges.push('🌟 First Campus Patrol');
        achWrap.innerHTML = badges.map(b => `<span class="px-2.5 py-1 rounded-lg bg-amber-950/80 border border-amber-400/60 text-amber-200 font-bold">${b}</span>`).join('');
    }

    document.getElementById('modal-gameover').classList.remove('hidden');
}

/* ==========================================================================
   TASK OVERLAY SYSTEM (9 FULLY PLAYABLE MISSIONS)
   ========================================================================== */
function openTaskModal(task) {
    activeTask = task;
    gameState = 'TASK';
    document.getElementById('task-modal-icon').innerText = task.icon;
    document.getElementById('task-modal-room').innerText = task.roomName;
    document.getElementById('task-modal-title').innerText = task.title;
    document.getElementById('task-modal-desc').innerText = task.desc;
    document.getElementById('task-modal-feedback').classList.add('hidden');
    document.getElementById('modal-task').classList.remove('hidden');

    const body = document.getElementById('task-modal-body');
    body.innerHTML = '';

    switch (task.key) {
        case 'cafeteria':   renderCafeteriaEatSmartTask(body, task); break;
        case 'dinning':     renderDiningWasteTask(body, task); break;
        case 'library':     renderLibraryLiteracyTask(body, task); break;
        case 'lab':         renderLabCyberTask(body, task); break;
        case 'garden':      renderCampusGardenTask(body, task); break;
        case 'residential': renderResidentialSudoku(body, task); break;
        case 'classroom':   renderClassroomCssTask(body, task); break;
        case 'basketball':  renderBasketballTask(body, task); break;
        case 'tales':       renderTalesPianoTask(body, task); break;
    }
}

function closeTaskModal() {
    sfx.click();
    activeTask = null;
    document.getElementById('modal-task').classList.add('hidden');
    if (gameState === 'TASK') gameState = 'PLAYING';
}

function showTaskFeedback(ok, msg) {
    const fb = document.getElementById('task-modal-feedback');
    fb.classList.remove('hidden', 'bg-emerald-950', 'border-emerald-500', 'text-emerald-200', 'bg-red-950', 'border-red-500', 'text-red-200');
    if (ok) {
        fb.classList.add('bg-emerald-950', 'border-emerald-500', 'text-emerald-200');
        fb.innerHTML = `<span>${msg}</span><button onclick="closeTaskModal()" class="au-btn-green px-3 py-1 rounded-lg text-white font-bold whitespace-nowrap">BACK TO CAMPUS</button>`;
    } else {
        fb.classList.add('bg-red-950', 'border-red-500', 'text-red-200');
        fb.innerHTML = `<span>${msg}</span>`;
    }
}

/* 1. CAFETERIA – EAT SMART! (HEALTHY BALANCED MEAL & BUDGET) */
function renderCafeteriaEatSmartTask(container, task) {
    const foods = [
        { id: 'f1', name: '🍗 Grilled Chicken',   cat: 'Protein',       price: 85, info: 'Lean protein builds muscle & keeps you energized for classes.' },
        { id: 'f2', name: '🥚 Boiled Eggs & Dal', cat: 'Protein',       price: 55, info: 'Plant & egg protein rich in iron and amino acids.' },
        { id: 'f3', name: '🍚 Steamed Brown Rice',cat: 'Carbohydrates', price: 40, info: 'Whole-grain complex carbs provide steady brain energy.' },
        { id: 'f4', name: '🥦 Mixed Vegetables',  cat: 'Vegetables',    price: 35, info: 'Packed with vitamins, fiber, and antioxidants.' },
        { id: 'f5', name: '🍎 Fresh Banana & Apple',cat:'Fruit/Drink',  price: 30, info: 'Natural vitamins & hydration without added sugar.' },
        { id: 'f6', name: '🥤 Sugary Soda & Fries',cat:'Junk',          price: 95, info: 'High in added sugar & trans fats—causes energy crashes!' }
    ];
    const selected = new Set();

    container.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div id="food-options" class="space-y-1.5"></div>
            <div class="bg-slate-950 p-3.5 rounded-2xl border border-orange-400/70 flex flex-col justify-between">
                <div class="space-y-1.5 font-bold">
                    <div class="text-orange-300 font-orbitron font-black">STUDENT BUDGET: 250 BDT</div>
                    <div>Running Cost: <span id="meal-total" class="text-emerald-400 font-orbitron">0 BDT</span></div>
                    <div id="meal-p">⬜ Protein (Chicken / Eggs)</div>
                    <div id="meal-c">⬜ Carbohydrates (Brown Rice)</div>
                    <div id="meal-v">⬜ Vegetables (Mixed Greens)</div>
                    <div id="meal-f">⬜ Fruit / Water (Apple & Banana)</div>
                    <div id="meal-note" class="text-[11px] text-cyan-300 pt-1 italic">Tap food items on the left to inspect nutrition.</div>
                </div>
                <button id="btn-submit-meal" class="mt-3 w-full au-btn-green py-2.5 rounded-xl font-orbitron font-black text-white">
                    CHECK NUTRITION & BUDGET ✓
                </button>
            </div>
        </div>
    `;

    const optWrap = document.getElementById('food-options');
    foods.forEach(f => {
        const btn = document.createElement('button');
        btn.className = 'w-full flex justify-between items-center px-3 py-2 rounded-xl bg-slate-800 border-2 border-slate-600 font-bold hover:border-amber-400 text-left';
        btn.innerHTML = `<span>${f.name} <span class="text-[10px] text-slate-400">(${f.cat})</span></span><span class="text-emerald-400">${f.price} BDT</span>`;
        btn.onclick = () => {
            sfx.click();
            document.getElementById('meal-note').innerText = `💡 ${f.name}: ${f.info}`;
            if (selected.has(f.id)) {
                selected.delete(f.id);
                btn.classList.remove('border-amber-400', 'bg-amber-950/50');
            } else {
                selected.add(f.id);
                btn.classList.add('border-amber-400', 'bg-amber-950/50');
            }
            let total = 0, hasP = false, hasC = false, hasV = false, hasF = false;
            selected.forEach(id => {
                const item = foods.find(x => x.id === id);
                total += item.price;
                if (item.cat === 'Protein') hasP = true;
                if (item.cat === 'Carbohydrates') hasC = true;
                if (item.cat === 'Vegetables') hasV = true;
                if (item.cat === 'Fruit/Drink') hasF = true;
            });
            const tEl = document.getElementById('meal-total');
            tEl.innerText = `${total} BDT`;
            tEl.className = total > 250 ? 'text-red-400 font-orbitron' : 'text-emerald-400 font-orbitron';
            document.getElementById('meal-p').innerText = `${hasP ? '✅' : '⬜'} Protein (Chicken / Eggs)`;
            document.getElementById('meal-c').innerText = `${hasC ? '✅' : '⬜'} Carbohydrates (Brown Rice)`;
            document.getElementById('meal-v').innerText = `${hasV ? '✅' : '⬜'} Vegetables (Mixed Greens)`;
            document.getElementById('meal-f').innerText = `${hasF ? '✅' : '⬜'} Fruit / Water (Apple & Banana)`;
        };
        optWrap.appendChild(btn);
    });

    document.getElementById('btn-submit-meal').onclick = () => {
        let total = 0, hasP = false, hasC = false, hasV = false, hasF = false, hasJunk = false;
        selected.forEach(id => {
            const item = foods.find(x => x.id === id);
            total += item.price;
            if (item.cat === 'Protein') hasP = true;
            if (item.cat === 'Carbohydrates') hasC = true;
            if (item.cat === 'Vegetables') hasV = true;
            if (item.cat === 'Fruit/Drink') hasF = true;
            if (item.cat === 'Junk') hasJunk = true;
        });

        if (total > 250) {
            sfx.error();
            showTaskFeedback(false, `❌ Over budget (${total} BDT / 250 BDT)! Remove an item to manage your student budget.`);
        } else if (hasJunk) {
            sfx.error();
            showTaskFeedback(false, '❌ Sugary Soda & Fries add empty calories and push up costs—swap for healthy whole foods!');
        } else if (!hasP || !hasC || !hasV || !hasF) {
            sfx.error();
            const missing = [!hasP && 'Protein', !hasC && 'Carbohydrates', !hasV && 'Vegetables', !hasF && 'Fruit'].filter(Boolean).join(', ');
            showTaskFeedback(false, `❌ Unbalanced plate! You are missing: ${missing}.`);
        } else {
            completeTask(task.id);
            showTaskFeedback(true, `✅ Smart Choice! Balanced meal (${total} BDT / 250 BDT) with Protein, Carbs, Veggies & Fruit!`);
        }
    };
}

/* 2. DINING HALL – WASTE LESS, SAVE MORE! */
function renderDiningWasteTask(container, task) {
    const wasteItems = [
        { id: 'w1', label: '🍌 Banana Peel',      bin: 'compost',   why: 'Banana peels are organic matter that turns into nutrient-rich soil compost!' },
        { id: 'w2', label: '🧴 Plastic Bottle',   bin: 'recycling', why: 'Clean PET plastic bottles can be melted and remade into new products.' },
        { id: 'w3', label: '🍚 Leftover Food',    bin: 'compost',   why: 'Food scraps belong in Compost rather than landfills where they create methane.' },
        { id: 'w4', label: '📦 Paper Wrapper',    bin: 'recycling', why: 'Dry paper wrappers go into Recycling to save trees and energy.' },
        { id: 'w5', label: '🧻 Used Tissue',      bin: 'general',   why: 'Soiled tissues cannot be recycled, so they go in General Waste.' }
    ];
    let sortedCount = 0;

    container.innerHTML = `
        <div class="space-y-3 text-xs">
            <div id="waste-explain" class="bg-amber-950/60 border border-amber-400/70 px-3 py-2 rounded-xl text-amber-200 font-semibold">
                💡 Drag each item (or tap an item, then tap its bin) to learn proper waste segregation!
            </div>
            <div id="waste-pool" class="flex flex-wrap gap-2 justify-center p-2.5 bg-slate-950 rounded-2xl border border-slate-700"></div>
            <div class="grid grid-cols-3 gap-2.5 text-center">
                <div data-bin="compost" class="waste-bin cursor-pointer p-3 rounded-2xl border-2 border-dashed border-emerald-400 bg-emerald-950/50 hover:bg-emerald-900/50">
                    <div class="text-2xl">🌱</div>
                    <div class="font-orbitron font-black text-emerald-300">COMPOST</div>
                    <div class="text-[10px] text-slate-300">Food & Peels</div>
                </div>
                <div data-bin="recycling" class="waste-bin cursor-pointer p-3 rounded-2xl border-2 border-dashed border-cyan-400 bg-cyan-950/50 hover:bg-cyan-900/50">
                    <div class="text-2xl">♻️</div>
                    <div class="font-orbitron font-black text-cyan-300">RECYCLING</div>
                    <div class="text-[10px] text-slate-300">Plastic & Paper</div>
                </div>
                <div data-bin="general" class="waste-bin cursor-pointer p-3 rounded-2xl border-2 border-dashed border-slate-400 bg-slate-800/60 hover:bg-slate-700/60">
                    <div class="text-2xl">🗑️</div>
                    <div class="font-orbitron font-black text-slate-200">GENERAL</div>
                    <div class="text-[10px] text-slate-300">Used Tissues</div>
                </div>
            </div>
        </div>
    `;

    let selectedWasteId = null;
    const pool = document.getElementById('waste-pool');

    wasteItems.forEach(item => {
        const chip = document.createElement('button');
        chip.id = item.id;
        chip.draggable = true;
        chip.className = 'px-3 py-1.5 rounded-xl bg-slate-800 border-2 border-slate-600 font-bold hover:border-amber-400';
        chip.innerText = item.label;
        chip.ondragstart = e => e.dataTransfer.setData('text/plain', item.id);
        chip.onclick = () => {
            sfx.click();
            selectedWasteId = item.id;
            pool.querySelectorAll('button').forEach(b => b.classList.remove('border-amber-400'));
            chip.classList.add('border-amber-400');
        };
        pool.appendChild(chip);
    });

    const handleDrop = (itemId, targetBin) => {
        const item = wasteItems.find(w => w.id === itemId);
        const el = document.getElementById(itemId);
        if (!item || !el || el.classList.contains('hidden')) return;
        if (item.bin === targetBin) {
            sfx.click();
            el.classList.add('hidden');
            sortedCount++;
            document.getElementById('waste-explain').innerText = `✅ Correct (${item.label} → ${targetBin.toUpperCase()}): ${item.why}`;
            if (sortedCount === wasteItems.length) {
                pool.innerHTML = '<span class="text-emerald-400 font-bold">All 5 dining hall items segregated cleanly!</span>';
                completeTask(task.id);
                showTaskFeedback(true, '✅ Waste Less, Save More! You sorted all 5 items and learned eco-segregation.');
            }
        } else {
            sfx.error();
            showTaskFeedback(false, `❌ Not quite! ${item.label} does not belong in ${targetBin.toUpperCase()}. Try another bin!`);
        }
    };

    document.querySelectorAll('.waste-bin').forEach(binEl => {
        binEl.ondragover = e => e.preventDefault();
        binEl.ondrop = e => {
            e.preventDefault();
            handleDrop(e.dataTransfer.getData('text/plain'), binEl.dataset.bin);
        };
        binEl.onclick = () => {
            if (selectedWasteId) handleDrop(selectedWasteId, binEl.dataset.bin);
        };
    });
}

/* 3. LIBRARY – THINK BEFORE YOU SEARCH */
function renderLibraryLiteracyTask(container, task) {
    container.innerHTML = `
        <div class="space-y-3 text-xs">
            <div class="bg-purple-950/60 border border-purple-400/70 p-3 rounded-2xl space-y-1.5">
                <div class="font-orbitron font-black text-purple-300">📚 STEP 1: CATALOG BOOK SEARCH</div>
                <p class="text-slate-200">Find the call number for <strong>"Digital Media & Critical Thinking"</strong> in the AUW Archive:</p>
                <div class="grid grid-cols-3 gap-2 pt-1">
                    <button type="button" data-book="wrong1" class="book-pick p-2 rounded-xl bg-slate-800 border border-slate-600 hover:border-purple-400 font-bold">QA-101: Campus Sports</button>
                    <button type="button" data-book="right" class="book-pick p-2 rounded-xl bg-slate-800 border border-slate-600 hover:border-purple-400 font-bold">ZA-404: Digital Media Literacy</button>
                    <button type="button" data-book="wrong2" class="book-pick p-2 rounded-xl bg-slate-800 border border-slate-600 hover:border-purple-400 font-bold">TX-210: Culinary Arts</button>
                </div>
            </div>

            <div class="bg-slate-950 border border-slate-700 p-3 rounded-2xl space-y-2">
                <div class="font-orbitron font-black text-amber-300">🔍 STEP 2: SPOT RELIABLE SOURCES VS FAKE NEWS</div>
                <p class="text-slate-200 font-bold">Which headline is a trustworthy academic source rather than clickbait fake news?</p>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="lib-src" value="fake1" class="accent-purple-400">
                    <span>"SHOCKING!! Scientists say drinking soda makes you pass exams instantly!!" (No author or citations)</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="lib-src" value="reliable" class="accent-purple-400">
                    <span>"Peer-Reviewed Study (WHO & University Journal, 2026): Effects of Sleep on Student Memory"</span>
                </label>
            </div>

            <button id="btn-verify-library" class="w-full au-btn-green py-2.5 rounded-xl font-orbitron font-black text-white">
                VERIFY RESEARCH SKILLS ✓
            </button>
        </div>
    `;

    let bookChoice = '';
    container.querySelectorAll('.book-pick').forEach(btn => {
        btn.onclick = () => {
            sfx.click();
            bookChoice = btn.dataset.book;
            container.querySelectorAll('.book-pick').forEach(b => b.classList.remove('border-emerald-400', 'bg-emerald-950/60'));
            btn.classList.add('border-emerald-400', 'bg-emerald-950/60');
        };
    });

    document.getElementById('btn-verify-library').onclick = () => {
        const checked = document.querySelector('input[name="lib-src"]:checked');
        const srcChoice = checked ? checked.value : '';
        if (bookChoice !== 'right') {
            sfx.error();
            showTaskFeedback(false, '❌ Check the catalog! Select ZA-404: Digital Media Literacy.');
        } else if (srcChoice !== 'reliable') {
            sfx.error();
            showTaskFeedback(false, '❌ Watch out for ALL-CAPS sensational headlines without authors! Pick the peer-reviewed journal.');
        } else {
            completeTask(task.id);
            showTaskFeedback(true, '✅ Great research literacy! Peer-reviewed citations & author verification beat fake news.');
        }
    };
}

/* 4. COMPUTER LAB – DIGITAL SAFETY & CYBERSECURITY */
function renderLabCyberTask(container, task) {
    container.innerHTML = `
        <div class="space-y-3 text-xs">
            <div class="bg-emerald-950/50 border border-emerald-400/70 p-3 rounded-2xl space-y-1.5">
                <div class="font-orbitron font-black text-emerald-300">🎣 1. PHISHING EMAIL DETECTOR</div>
                <p class="text-slate-200">You receive: <em>"URGENT: Click http://auw-free-prize-login.xyz and send your student password now!"</em></p>
                <div class="flex gap-2">
                    <button type="button" data-phish="safe" class="phish-btn flex-1 py-1.5 rounded-xl bg-slate-800 border border-slate-600 font-bold">Click Link & Login</button>
                    <button type="button" data-phish="report" class="phish-btn flex-1 py-1.5 rounded-xl bg-slate-800 border border-slate-600 font-bold">Report Phishing & Never Share Password</button>
                </div>
            </div>

            <div class="bg-slate-950 border border-slate-700 p-3 rounded-2xl space-y-1.5">
                <div class="font-orbitron font-black text-cyan-300">🔑 2. CREATE A STRONG PASSWORD (8+ chars, uppercase, number & symbol)</div>
                <input id="cyber-pass" type="text" placeholder="e.g. AuwCampus#2026" class="w-full bg-slate-900 border border-emerald-400 rounded-xl px-3 py-1.5 font-mono-code text-white">
            </div>

            <div class="bg-slate-950 border border-slate-700 p-3 rounded-2xl space-y-1.5 font-mono-code">
                <div class="font-orbitron font-black text-amber-300 font-sans">💻 3. COMPLETE BASIC HTML TAGS</div>
                <div>&lt;<input id="ht-1" maxlength="2" placeholder="h1" class="w-9 bg-slate-800 border border-amber-400 rounded text-center text-amber-300">&gt;AUW Cyber Lab&lt;/h1&gt;  &amp;  &lt;<input id="ht-2" maxlength="1" placeholder="p" class="w-7 bg-slate-800 border border-amber-400 rounded text-center text-amber-300">&gt;Stay safe online!&lt;/p&gt;</div>
            </div>

            <button id="btn-verify-cyber" class="w-full au-btn-green py-2.5 rounded-xl font-orbitron font-black text-white">
                VERIFY DIGITAL SAFETY ✓
            </button>
        </div>
    `;

    let phishChoice = '';
    container.querySelectorAll('.phish-btn').forEach(btn => {
        btn.onclick = () => {
            sfx.click();
            phishChoice = btn.dataset.phish;
            container.querySelectorAll('.phish-btn').forEach(b => b.classList.remove('border-emerald-400', 'bg-emerald-950/60'));
            btn.classList.add('border-emerald-400', 'bg-emerald-950/60');
        };
    });

    document.getElementById('btn-verify-cyber').onclick = () => {
        const pwd = document.getElementById('cyber-pass').value.trim();
        const strongPwd = pwd.length >= 8 && /[A-Z]/.test(pwd) && /[0-9]/.test(pwd) && /[^A-Za-z0-9]/.test(pwd);
        const t1 = document.getElementById('ht-1').value.trim().toLowerCase();
        const t2 = document.getElementById('ht-2').value.trim().toLowerCase();

        if (phishChoice !== 'report') {
            sfx.error();
            showTaskFeedback(false, '❌ Suspicious unverified domains asking for passwords are phishing attacks—report them!');
        } else if (!strongPwd) {
            sfx.error();
            showTaskFeedback(false, '❌ Password needs 8+ characters with an uppercase letter, a number, and a symbol (e.g. AuwSafe#26).');
        } else if (t1 !== 'h1' || t2 !== 'p') {
            sfx.error();
            showTaskFeedback(false, '❌ Fill in h1 for heading and p for paragraph in the HTML code!');
        } else {
            completeTask(task.id);
            showTaskFeedback(true, '✅ Cyber Lab Secured! Phishing blocked, strong password set, and HTML verified.');
        }
    };
}

/* 5. CAMPUS GARDEN – KEEP IT GREEN! */
function renderCampusGardenTask(container, task) {
    let watered = false;
    container.innerHTML = `
        <div class="space-y-3 text-xs">
            <div class="bg-emerald-950/60 border border-emerald-400/70 p-3 rounded-2xl flex items-center justify-between gap-3">
                <div>
                    <div class="font-orbitron font-black text-emerald-300">💧 1. WATER THE CAMPUS SAPLINGS</div>
                    <p id="plant-status" class="text-slate-200 mt-0.5">The campus hibiscus & neem saplings look thirsty!</p>
                </div>
                <button id="btn-water-plants" class="au-btn-green px-4 py-2 rounded-xl font-orbitron font-black text-white whitespace-nowrap">
                    🚿 WATER PLANTS
                </button>
            </div>

            <div class="bg-slate-950 border border-slate-700 p-3 rounded-2xl space-y-1.5">
                <div class="font-orbitron font-black text-amber-300">🌺 2. PLANT IDENTIFICATION & WATER CONSERVATION</div>
                <p class="text-slate-200 font-bold">Which practice best conserves water in the AUW Campus Garden?</p>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="garden-q" value="conserve" class="accent-emerald-400">
                    <span>Water plants early in the morning using collected rainwater & drip irrigation</span>
                </label>
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="garden-q" value="waste" class="accent-emerald-400">
                    <span>Leave the garden hose running at noon under hot sunlight</span>
                </label>
            </div>

            <button id="btn-verify-garden" class="w-full au-btn-green py-2.5 rounded-xl font-orbitron font-black text-white">
                COMPLETE GARDEN MISSION ✓
            </button>
        </div>
    `;

    document.getElementById('btn-water-plants').onclick = () => {
        sfx.swish();
        watered = true;
        document.getElementById('plant-status').innerText = '🌸 Saplings watered! Fresh oxygen and shade keep AUW cool and green.';
        document.getElementById('btn-water-plants').innerText = '✅ WATERED';
    };

    document.getElementById('btn-verify-garden').onclick = () => {
        const checked = document.querySelector('input[name="garden-q"]:checked');
        const ans = checked ? checked.value : '';
        if (!watered) {
            sfx.error();
            showTaskFeedback(false, '❌ Click WATER PLANTS first to hydrate the campus saplings!');
        } else if (ans !== 'conserve') {
            sfx.error();
            showTaskFeedback(false, '❌ Watering at noon causes high evaporation—pick morning rainwater & drip irrigation!');
        } else {
            completeTask(task.id);
            showTaskFeedback(true, '✅ Keep It Green! Plants hydrated and water-conservation principle mastered.');
        }
    };
}

/* 6. RESIDENTIAL – DORMITORY DOOR UNLOCK (5×5 SUDOKU) */
function renderResidentialSudoku(container, task) {
    const solution = [
        [1, 2, 3, 4, 5],
        [2, 3, 4, 5, 1],
        [3, 4, 5, 1, 2],
        [4, 5, 1, 2, 3],
        [5, 1, 2, 3, 4]
    ];
    const puzzle = [
        [1, 0, 3, 4, 5],
        [2, 3, 0, 5, 1],
        [3, 4, 5, 0, 2],
        [4, 5, 1, 2, 0],
        [0, 1, 2, 3, 4]
    ];

    container.innerHTML = `
        <div class="flex flex-col items-center gap-4">
            <div id="dorm-door-visual" class="w-full max-w-xs h-14 rounded-2xl border-3 border-rose-400 bg-rose-950/70 flex items-center justify-center font-orbitron font-black text-sm text-rose-200 transition-all duration-500">
                🔒 DORMITORY DOOR LOCKED
            </div>
            <div id="sudoku-grid" class="grid grid-cols-5 gap-1.5 bg-slate-950 p-3 rounded-2xl border-2 border-slate-700"></div>
            <button id="btn-check-sudoku" class="au-btn-green px-6 py-2.5 rounded-xl font-orbitron font-black text-xs text-white">
                UNLOCK DORMITORY DOOR ✓
            </button>
        </div>
    `;

    const grid = document.getElementById('sudoku-grid');
    for (let r = 0; r < 5; r++) {
        for (let c = 0; c < 5; c++) {
            const val = puzzle[r][c];
            if (val !== 0) {
                const cell = document.createElement('div');
                cell.className = 'w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-slate-800 border border-slate-600 flex items-center justify-center font-orbitron font-black text-lg text-cyan-300';
                cell.innerText = val;
                grid.appendChild(cell);
            } else {
                const inp = document.createElement('input');
                inp.type = 'number';
                inp.min = 1;
                inp.max = 5;
                inp.dataset.r = r;
                inp.dataset.c = c;
                inp.className = 'w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-slate-950 border-2 border-amber-400 text-center font-orbitron font-black text-lg text-amber-300 focus:outline-none';
                grid.appendChild(inp);
            }
        }
    }

    document.getElementById('btn-check-sudoku').onclick = () => {
        const inputs = grid.querySelectorAll('input');
        let allValid = true;
        inputs.forEach(inp => {
            const r = Number(inp.dataset.r);
            const c = Number(inp.dataset.c);
            if (Number(inp.value) !== solution[r][c]) allValid = false;
        });

        if (allValid) {
            const door = document.getElementById('dorm-door-visual');
            door.className = 'w-full max-w-xs h-14 rounded-2xl border-3 border-emerald-400 bg-emerald-900/80 flex items-center justify-center font-orbitron font-black text-sm text-emerald-200 scale-105';
            door.innerText = '🔓 DORMITORY DOOR UNLOCKED!';
            completeTask(task.id);
            showTaskFeedback(true, '✅ Dormitory security keypad solved! Door unlocked.');
        } else {
            sfx.error();
            showTaskFeedback(false, '❌ Incorrect numbers! Ensure each row and column has 1, 2, 3, 4, 5 once.');
        }
    };
}

/* 7. CLASSROOM – CSS COLOUR MODIFICATION */
function renderClassroomCssTask(container, task) {
    container.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <div class="space-y-2.5 text-xs font-mono-code bg-slate-950 p-3.5 rounded-2xl border border-slate-700">
                <div class="text-rose-300 font-bold">Target Rules: Sky = Sky Blue, Sun = Yellow, Hill = Green</div>
                <div class="flex items-center justify-between">
                    <span>.sky { background:</span>
                    <select id="css-sky" class="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white">
                        <option value="#1e293b">dark-slate</option>
                        <option value="#38bdf8">skyblue</option>
                        <option value="#f43f5e">crimson</option>
                    </select>
                    <span>}</span>
                </div>
                <div class="flex items-center justify-between">
                    <span>.sun { background:</span>
                    <select id="css-sun" class="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white">
                        <option value="#94a3b8">grey</option>
                        <option value="#facc15">yellow</option>
                        <option value="#a855f7">purple</option>
                    </select>
                    <span>}</span>
                </div>
                <div class="flex items-center justify-between">
                    <span>.hill { background:</span>
                    <select id="css-hill" class="bg-slate-800 border border-slate-600 rounded px-2 py-1 text-white">
                        <option value="#475569">stone</option>
                        <option value="#22c55e">green</option>
                        <option value="#fb923c">orange</option>
                    </select>
                    <span>}</span>
                </div>
                <button id="btn-apply-css" class="w-full au-btn-green py-2 rounded-xl font-orbitron font-black text-white mt-2">
                    APPLY CSS STYLES ✓
                </button>
            </div>
            <div id="scenery-sky" class="h-44 rounded-2xl border-2 border-slate-500 relative overflow-hidden transition-colors duration-300" style="background:#1e293b;">
                <div id="scenery-sun" class="w-12 h-12 rounded-full absolute top-5 right-6 transition-colors duration-300" style="background:#94a3b8;"></div>
                <div class="absolute top-6 left-5 text-xs font-orbitron font-black text-white drop-shadow">AUW CAMPUS VIEW</div>
                <div id="scenery-hill" class="w-full h-20 rounded-t-[100%] absolute bottom-0 transition-colors duration-300" style="background:#475569;"></div>
            </div>
        </div>
    `;

    const syncScenery = () => {
        sfx.click();
        document.getElementById('scenery-sky').style.background = document.getElementById('css-sky').value;
        document.getElementById('scenery-sun').style.background = document.getElementById('css-sun').value;
        document.getElementById('scenery-hill').style.background = document.getElementById('css-hill').value;
    };
    ['css-sky', 'css-sun', 'css-hill'].forEach(id => document.getElementById(id).addEventListener('change', syncScenery));

    document.getElementById('btn-apply-css').onclick = () => {
        const sky = document.getElementById('css-sky').value;
        const sun = document.getElementById('css-sun').value;
        const hill = document.getElementById('css-hill').value;
        if (sky === '#38bdf8' && sun === '#facc15' && hill === '#22c55e') {
            completeTask(task.id);
            showTaskFeedback(true, '✅ Scenery CSS colours updated perfectly!');
        } else {
            sfx.error();
            showTaskFeedback(false, '❌ Match the instructions: Sky = skyblue, Sun = yellow, Hill = green.');
        }
    };
}

/* 8. BASKETBALL FIELD – BASKETBALL SHOOTING */
function renderBasketballTask(container, task) {
    let made = 0;
    let shotsLeft = 6;
    let ballX = 65, ballY = 165, vx = 0, vy = 0, flying = false;
    const hoopX = 355, hoopY = 78;

    container.innerHTML = `
        <div class="flex flex-col items-center gap-3">
            <div class="flex justify-between w-full max-w-md text-xs font-orbitron font-black">
                <span id="bb-score" class="text-emerald-400">BASKETS: 0 / 3</span>
                <span id="bb-shots" class="text-amber-300">SHOTS LEFT: 6</span>
            </div>
            <canvas id="bbCanvas" width="420" height="200" class="w-full max-w-md rounded-2xl border-2 border-emerald-400 bg-slate-950"></canvas>
            <div class="flex flex-wrap items-center justify-center gap-3 w-full max-w-md text-xs">
                <label class="flex items-center gap-2 font-bold">
                    POWER:
                    <input id="bb-power" type="range" min="9" max="16" step="0.5" value="12.5" class="accent-orange-500">
                </label>
                <button id="btn-shoot-ball" class="au-btn-amber px-5 py-2 rounded-xl font-orbitron font-black text-slate-950">
                    🏀 SHOOT BALL
                </button>
                <button id="btn-reset-bb" class="hidden au-btn px-4 py-2 rounded-xl font-orbitron font-black text-white">
                    RETRY ↻
                </button>
            </div>
        </div>
    `;

    const bCanvas = document.getElementById('bbCanvas');
    const bCtx = bCanvas.getContext('2d');

    const resetBall = () => {
        flying = false;
        ballX = 65;
        ballY = 165;
        if (made >= 3) {
            completeTask(task.id);
            showTaskFeedback(true, '✅ Swish! You scored 3 baskets on the AUW Basketball Field!');
        } else if (shotsLeft <= 0) {
            sfx.error();
            document.getElementById('btn-reset-bb').classList.remove('hidden');
            showTaskFeedback(false, '❌ Out of shots! Click RETRY to try again.');
        }
    };

    document.getElementById('btn-shoot-ball').onclick = () => {
        if (flying || shotsLeft <= 0 || made >= 3) return;
        sfx.click();
        shotsLeft--;
        document.getElementById('bb-shots').innerText = `SHOTS LEFT: ${shotsLeft}`;
        const pwr = Number(document.getElementById('bb-power').value);
        vx = pwr * 0.62;
        vy = -pwr * 0.92;
        flying = true;
    };

    document.getElementById('btn-reset-bb').onclick = () => {
        made = 0; shotsLeft = 6;
        document.getElementById('bb-score').innerText = 'BASKETS: 0 / 3';
        document.getElementById('bb-shots').innerText = 'SHOTS LEFT: 6';
        document.getElementById('btn-reset-bb').classList.add('hidden');
        document.getElementById('task-modal-feedback').classList.add('hidden');
        resetBall();
    };

    function drawCourt() {
        if (!document.getElementById('bbCanvas')) return;
        bCtx.clearRect(0, 0, bCanvas.width, bCanvas.height);

        bCtx.fillStyle = '#14532d';
        bCtx.fillRect(0, 182, 420, 18);

        bCtx.fillStyle = '#f8fafc';
        bCtx.fillRect(382, 34, 8, 56);
        bCtx.strokeStyle = '#f97316';
        bCtx.lineWidth = 5;
        bCtx.beginPath();
        bCtx.moveTo(335, hoopY);
        bCtx.lineTo(382, hoopY);
        bCtx.stroke();

        if (!flying && shotsLeft > 0) {
            const pwr = Number(document.getElementById('bb-power').value);
            bCtx.strokeStyle = 'rgba(250, 204, 21, 0.45)';
            bCtx.setLineDash([4, 4]);
            bCtx.beginPath();
            bCtx.moveTo(ballX, ballY);
            bCtx.lineTo(ballX + pwr * 7, ballY - pwr * 7);
            bCtx.stroke();
            bCtx.setLineDash([]);
        }

        if (flying) {
            ballX += vx;
            ballY += vy;
            vy += 0.36;

            if (Math.hypot(ballX - hoopX, ballY - hoopY) < 20 && vy > 0) {
                made++;
                sfx.swish();
                document.getElementById('bb-score').innerText = `BASKETS: ${made} / 3`;
                resetBall();
            } else if (ballY > 190 || ballX > 415) {
                sfx.error();
                resetBall();
            }
        }

        bCtx.fillStyle = '#ea580c';
        bCtx.beginPath();
        bCtx.arc(ballX, ballY, 13, 0, Math.PI * 2);
        bCtx.fill();
        bCtx.strokeStyle = '#1c1917';
        bCtx.lineWidth = 2;
        bCtx.stroke();

        requestAnimationFrame(drawCourt);
    }
    requestAnimationFrame(drawCourt);
}

/* 9. TALES SPACE – PIANO LESSON */
function renderTalesPianoTask(container, task) {
    const targetSeq = ['C', 'E', 'G', 'E', 'C'];
    const notes = [
        { note: 'C', freq: 261.63 },
        { note: 'D', freq: 293.66 },
        { note: 'E', freq: 329.63 },
        { note: 'F', freq: 349.23 },
        { note: 'G', freq: 392.00 },
        { note: 'A', freq: 440.00 }
    ];
    let played = [];

    container.innerHTML = `
        <div class="flex flex-col items-center gap-4">
            <div class="bg-sky-950/70 border-2 border-sky-400 px-4 py-2.5 rounded-2xl text-center">
                <div class="text-[10px] font-orbitron font-black text-sky-300">📖 TALES SPACE MELODY GUIDEBOOK</div>
                <div class="font-orbitron font-black text-base text-white tracking-widest mt-0.5">C — E — G — E — C</div>
            </div>
            <div id="piano-progress" class="font-orbitron font-black text-xs text-amber-300">
                PLAYED: (none yet)
            </div>
            <div id="piano-keys" class="flex gap-2 justify-center"></div>
            <button id="btn-demo-melody" class="au-btn px-4 py-1.5 rounded-xl text-xs font-bold text-cyan-300">
                🔊 HEAR GUIDE MELODY
            </button>
        </div>
    `;

    document.getElementById('btn-demo-melody').onclick = () => {
        targetSeq.forEach((n, idx) => {
            const obj = notes.find(item => item.note === n);
            setTimeout(() => sfx.pianoNote(obj.freq), idx * 280);
        });
    };

    const keyWrap = document.getElementById('piano-keys');
    notes.forEach(n => {
        const key = document.createElement('button');
        key.className = 'w-12 sm:w-14 h-28 bg-white active:bg-sky-300 text-slate-900 border-2 border-slate-400 rounded-b-2xl font-orbitron font-black text-base flex items-end justify-center pb-3 shadow-lg';
        key.innerText = n.note;
        key.onclick = () => {
            sfx.pianoNote(n.freq);
            played.push(n.note);
            document.getElementById('piano-progress').innerText = `PLAYED: ${played.join(' - ')}`;

            const idx = played.length - 1;
            if (played[idx] !== targetSeq[idx]) {
                sfx.error();
                played = [];
                document.getElementById('piano-progress').innerText = 'WRONG NOTE! RESETTING TO C...';
                showTaskFeedback(false, '❌ Off-key note! Follow the guidebook sequence: C - E - G - E - C.');
                return;
            }

            if (played.length === targetSeq.length) {
                completeTask(task.id);
                showTaskFeedback(true, '✅ Beautiful performance! Tales Space Piano Lesson completed.');
            }
        };
        keyWrap.appendChild(key);
    });
}

/* ==========================================================================
   EMERGENCY MEETING, DISCUSSION & VOTING SYSTEM
   ========================================================================== */
function startMeeting(reason) {
    if (activeTask) closeTaskModal();
    if (connectionMode === 'ONLINE' && window.mpBackend) {
        window.mpBackend.startOnlineMeeting(reason);
        return;
    }
    sfx.alarm();
    gameState = 'MEETING';
    deadBodies = [];
    sabotageLights = false;

    document.getElementById('meeting-badge').innerText = reason;
    document.getElementById('meeting-result-banner').classList.add('hidden');
    document.getElementById('btn-skip-vote').disabled = localPlayer.isDead;
    document.getElementById('modal-meeting').classList.remove('hidden');

    const grid = document.getElementById('meeting-players-grid');
    grid.innerHTML = '';
    players.forEach(p => {
        const btn = document.createElement('button');
        btn.disabled = p.isDead || localPlayer.isDead;
        btn.className = `flex items-center gap-2 p-2 rounded-xl border-2 text-left text-xs font-bold ${
            p.isDead ? 'bg-slate-950 border-slate-800 opacity-40 line-through' : 'bg-slate-800 border-slate-600 hover:border-amber-400'
        }`;
        btn.innerHTML = `<span class="w-3.5 h-3.5 rounded-full inline-block shrink-0" style="background:${p.color}"></span><span>${p.flag || ''} ${p.name}</span>`;
        btn.onclick = () => castPlayerVote(p.id);
        grid.appendChild(btn);
    });

    const chatLog = document.getElementById('meeting-chat-log');
    chatLog.innerHTML = `<div class="text-amber-300 font-bold">System: Discuss who is acting suspicious on the AUW campus!</div>`;

    const aliveBots = players.filter(p => !p.isUser && !p.isDead);
    aliveBots.slice(0, 3).forEach((b, i) => {
        setTimeout(() => {
            if (gameState !== 'MEETING') return;
            if (witnessReports.length > i) {
                appendChat(b.name, b.color, witnessReports[i]);
            } else {
                const clues = [
                    'I was finishing my task in the Library!',
                    'Someone was lurking near the vents in Lab room...',
                    'Stay together in groups of two!'
                ];
                appendChat(b.name, b.color, clues[i % clues.length]);
            }
        }, 1400 * (i + 1));
    });

    let timeLeft = 20;
    document.getElementById('meeting-timer').innerText = `${timeLeft}s`;
    if (meetingInterval) clearInterval(meetingInterval);
    meetingInterval = setInterval(() => {
        timeLeft--;
        document.getElementById('meeting-timer').innerText = `${timeLeft}s`;
        if (timeLeft <= 0) castPlayerVote('SKIP');
    }, 1000);
}

function appendChat(sender, color, text) {
    const chatLog = document.getElementById('meeting-chat-log');
    const line = document.createElement('div');
    line.innerHTML = `<strong style="color:${color}">${sender}:</strong> <span class="text-slate-200">${text}</span>`;
    chatLog.appendChild(line);
    chatLog.scrollTop = chatLog.scrollHeight;
}

function sendMeetingChat() {
    const inp = document.getElementById('meeting-chat-input');
    const msg = inp.value.trim();
    if (!msg || !localPlayer) return;
    if (connectionMode === 'ONLINE' && window.mpBackend) {
        window.mpBackend.sendOnlineChat(`${localPlayer.flag} ${localPlayer.name}`, localPlayer.color, msg);
    } else {
        appendChat(localPlayer.name, localPlayer.color, msg);
    }
    inp.value = '';
}

function castPlayerVote(targetId) {
    if (connectionMode === 'ONLINE' && window.mpBackend) {
        sfx.click();
        window.mpBackend.castOnlineVote(targetId);
        return;
    }
    if (meetingInterval) clearInterval(meetingInterval);
    sfx.click();

    const tally = {};
    if (targetId !== 'SKIP') tally[targetId] = (tally[targetId] || 0) + 1;

    const alive = players.filter(p => !p.isDead);
    alive.forEach(p => {
        if (p.isUser) return;
        if (Math.random() < 0.65) {
            const pick = alive[Math.floor(Math.random() * alive.length)];
            tally[pick.id] = (tally[pick.id] || 0) + 1;
        }
    });

    let topId = null, maxVotes = 0;
    Object.entries(tally).forEach(([id, count]) => {
        if (count > maxVotes) { maxVotes = count; topId = Number(id); }
    });

    const banner = document.getElementById('meeting-result-banner');
    banner.classList.remove('hidden');

    if (topId !== null && maxVotes >= 2) {
        const ejected = players.find(p => p.id === topId);
        ejected.isDead = true;
        banner.innerText = `${ejected.name} was ejected! (${ejected.isImpostor ? 'WAS THE DISGUISED INTRUDER!' : 'Was NOT the Intruder.'})`;
    } else {
        banner.innerText = 'No one was ejected (Skipped / Tie).';
    }

    setTimeout(() => {
        document.getElementById('modal-meeting').classList.add('hidden');
        gameState = 'PLAYING';
        checkWinConditions();
    }, 2600);
}

/* ==========================================================================
   FULL MAP OVERLAY & LIVE TOP-CENTER MINI-MAP RADAR
   ========================================================================== */
function openFullMapModal() {
    sfx.click();
    document.getElementById('modal-full-map').classList.remove('hidden');
    const locLabel = document.getElementById('fullmap-loc-label');
    if (locLabel && localPlayer) locLabel.innerText = getPlayerRoomName(localPlayer);
    const navWrap = document.getElementById('map-quick-nav');
    navWrap.innerHTML = '';
    ROOMS.forEach(r => {
        const b = document.createElement('button');
        b.className = 'px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-cyan-900 border border-slate-600 text-[11px] font-bold text-cyan-200';
        b.innerText = `📍 ${r.name}`;
        b.onclick = () => {
            if (!localPlayer || localPlayer.isDead) return;
            sfx.click();
            localPlayer.x = r.x + r.w / 2;
            localPlayer.y = r.y + r.h / 2 + 40;
            closeFullMapModal();
        };
        navWrap.appendChild(b);
    });
    drawCampusRadar(document.getElementById('fullMapCanvas'), true);
}

function closeFullMapModal() {
    sfx.click();
    document.getElementById('modal-full-map').classList.add('hidden');
}

function drawCampusRadar(targetCanvas, showFullLabels) {
    if (!targetCanvas || !localPlayer) return;
    const mCtx = targetCanvas.getContext('2d');
    const cw = targetCanvas.width;
    const ch = targetCanvas.height;

    const scaleX = (cw - 16) / 2680;
    const scaleY = (ch - 16) / 1480;
    const toX = wx => 8 + (wx - 120) * scaleX;
    const toY = wy => 8 + (wy - 120) * scaleY;

    mCtx.clearRect(0, 0, cw, ch);
    mCtx.fillStyle = '#243129';
    mCtx.fillRect(0, 0, cw, ch);

    mCtx.fillStyle = '#475569';
    CORRIDORS.forEach(c => {
        mCtx.fillRect(toX(c.x), toY(c.y), c.w * scaleX, c.h * scaleY);
    });

    ROOMS.forEach(r => {
        const rx = toX(r.x), ry = toY(r.y), rw = r.w * scaleX, rh = r.h * scaleY;
        mCtx.fillStyle = r.fill;
        mCtx.fillRect(rx, ry, rw, rh);
        mCtx.strokeStyle = r.border;
        mCtx.lineWidth = showFullLabels ? 2.5 : 1.5;
        mCtx.strokeRect(rx, ry, rw, rh);

        mCtx.fillStyle = '#ffffff';
        mCtx.textAlign = 'center';
        mCtx.font = showFullLabels ? '900 11px system-ui, sans-serif' : '700 7px system-ui, sans-serif';
        const label = showFullLabels ? r.name : r.name.split(' ')[0];
        mCtx.fillText(label, rx + rw / 2, ry + rh / 2 + 3);
    });

    TASKS.forEach(t => {
        mCtx.fillStyle = t.completed ? '#34d399' : '#facc15';
        mCtx.beginPath();
        mCtx.arc(toX(t.x), toY(t.y), showFullLabels ? 5 : 2.8, 0, Math.PI * 2);
        mCtx.fill();
    });

    const px = toX(localPlayer.x);
    const py = toY(localPlayer.y);
    const pulse = 5 + Math.sin(performance.now() / 160) * 2.5;
    mCtx.fillStyle = 'rgba(251, 191, 36, 0.38)';
    mCtx.beginPath();
    mCtx.arc(px, py, showFullLabels ? pulse + 5 : pulse, 0, Math.PI * 2);
    mCtx.fill();

    mCtx.fillStyle = '#fbbf24';
    mCtx.beginPath();
    mCtx.arc(px, py, showFullLabels ? 6 : 3.8, 0, Math.PI * 2);
    mCtx.fill();
    mCtx.strokeStyle = '#0f172a';
    mCtx.lineWidth = 1.5;
    mCtx.stroke();
}

/* ==========================================================================
   INPUT BINDINGS & MAIN GAME LOOP
   ========================================================================== */
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    keys[k] = true;
    if (gameState !== 'PLAYING' || activeTask) return;
    if (k === 'e' || e.code === 'Space') interactWithNearby();
    if (k === 'q') attemptKill();
    if (k === 'v') useVent();
    if (k === 'f') activateImpostorDisguise();
    if (k === 'r') reportBodyOrEmergency();
});
window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

canvas.addEventListener('click', e => {
    if (gameState !== 'PLAYING' || activeTask || !localPlayer) return;
    const rect = canvas.getBoundingClientRect();
    const worldX = (e.clientX - rect.left) + (localPlayer.x - canvas.width / 2);
    const worldY = (e.clientY - rect.top) + (localPlayer.y - canvas.height / 2);

    if (getPlayerRoomName(localPlayer) === 'Lab room' && Math.hypot(worldX - CCTV_TERMINAL.x, worldY - CCTV_TERMINAL.y) < 70 && Math.hypot(localPlayer.x - CCTV_TERMINAL.x, localPlayer.y - CCTV_TERMINAL.y) < 115) {
        openCctvModal();
        return;
    }

    for (const t of TASKS) {
        if (Math.hypot(worldX - t.x, worldY - t.y) < 75 && Math.hypot(localPlayer.x - t.x, localPlayer.y - t.y) < 115) {
            sfx.click();
            openTaskModal(t);
            return;
        }
    }
});

function bindDpadButton(id, dir) {
    const btn = document.getElementById(id);
    if (!btn) return;
    const setDir = val => e => { e.preventDefault(); dpad[dir] = val; };
    btn.addEventListener('mousedown', setDir(true));
    btn.addEventListener('mouseup', setDir(false));
    btn.addEventListener('mouseleave', setDir(false));
    btn.addEventListener('touchstart', setDir(true), { passive: false });
    btn.addEventListener('touchend', setDir(false), { passive: false });
}
bindDpadButton('dpad-up', 'up');
bindDpadButton('dpad-down', 'down');
bindDpadButton('dpad-left', 'left');
bindDpadButton('dpad-right', 'right');

function drawRectRounded(x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) {
        ctx.roundRect(x, y, w, h, r);
    } else {
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
    }
}

function drawOutdoorCampusScenery() {
    ctx.fillStyle = '#252b27';
    ctx.fillRect(-400, -400, 3800, 2600);

    const grassLawns = [
        { x: -160, y: -120, w: 260, h: 1900 },
        { x: 2820, y: -120, w: 260, h: 1900 },
        { x: 160,  y: 1140, w: 520, h: 520 },
        { x: 1560, y: 1140, w: 1200, h: 520 },
        { x: 700,  y: 540,  w: 140, h: 160 },
        { x: 1410, y: 540,  w: 140, h: 160 },
        { x: 2090, y: 540,  w: 140, h: 160 }
    ];
    grassLawns.forEach(gl => {
        ctx.fillStyle = '#293b2f';
        drawRectRounded(gl.x, gl.y, gl.w, gl.h, 18);
        ctx.fill();
        ctx.strokeStyle = '#364d3e';
        ctx.lineWidth = 3;
        ctx.stroke();
    });

    ctx.fillStyle = '#373e45';
    drawRectRounded(120, 120, 2680, 1000, 28);
    ctx.fill();
    ctx.strokeStyle = '#525b65';
    ctx.lineWidth = 5;
    ctx.stroke();

    ctx.fillStyle = '#475159';
    ctx.fillRect(720, 565, 1480, 110);
    ctx.fillRect(700, 1120, 840, 480);

    ctx.strokeStyle = 'rgba(148, 163, 184, 0.16)';
    ctx.lineWidth = 1.5;
    for (let px = 740; px <= 2180; px += 60) {
        ctx.beginPath();
        ctx.moveTo(px, 565);
        ctx.lineTo(px, 675);
        ctx.stroke();
    }

    const lampPosts = [
        { x: 745, y: 575 }, { x: 1120, y: 575 }, { x: 1480, y: 575 }, { x: 1840, y: 575 }, { x: 2155, y: 575 },
        { x: 745, y: 665 }, { x: 1480, y: 665 }, { x: 2155, y: 665 },
        { x: 760, y: 1185 }, { x: 1480, y: 1185 }
    ];
    lampPosts.forEach(lp => {
        const glow = ctx.createRadialGradient(lp.x, lp.y, 2, lp.x, lp.y, 34);
        glow.addColorStop(0, 'rgba(251, 191, 36, 0.24)');
        glow.addColorStop(1, 'rgba(251, 191, 36, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(lp.x, lp.y, 34, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1e293b';
        ctx.beginPath();
        ctx.arc(lp.x, lp.y, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fcd34d';
        ctx.beginPath();
        ctx.arc(lp.x, lp.y, 2, 0, Math.PI * 2);
        ctx.fill();
    });

    const trees = [
        { x: 65, y: 180, r: 34 }, { x: 65, y: 560, r: 38 }, { x: 65, y: 940, r: 35 },
        { x: 2865, y: 200, r: 36 }, { x: 2865, y: 600, r: 40 }, { x: 2865, y: 980, r: 34 },
        { x: 765, y: 615, r: 24 }, { x: 1475, y: 615, r: 26 }, { x: 2155, y: 615, r: 24 },
        { x: 580, y: 1260, r: 36 }, { x: 580, y: 1490, r: 34 },
        { x: 1620, y: 1260, r: 38 }, { x: 1620, y: 1490, r: 34 },
        { x: 320, y: 1360, r: 34 }, { x: 2050, y: 1340, r: 36 }
    ];

    trees.forEach(tr => {
        ctx.fillStyle = 'rgba(10, 15, 13, 0.42)';
        ctx.beginPath();
        ctx.arc(tr.x + 7, tr.y + 9, tr.r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#2d4736';
        ctx.beginPath();
        ctx.arc(tr.x, tr.y, tr.r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#3f624b';
        ctx.beginPath();
        ctx.arc(tr.x - tr.r * 0.22, tr.y - tr.r * 0.22, tr.r * 0.58, 0, Math.PI * 2);
        ctx.fill();
    });

    const planters = [
        { x: 920, y: 615 }, { x: 1280, y: 615 }, { x: 1680, y: 615 }, { x: 1960, y: 615 },
        { x: 745, y: 1320 }, { x: 745, y: 1470 }, { x: 1455, y: 1320 }, { x: 1455, y: 1470 }
    ];
    planters.forEach((pl, idx) => {
        ctx.fillStyle = '#44403c';
        drawRectRounded(pl.x - 26, pl.y - 11, 52, 22, 6);
        ctx.fill();
        ctx.fillStyle = '#365340';
        ctx.beginPath();
        ctx.ellipse(pl.x, pl.y, 21, 8, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = idx % 2 === 0 ? '#b45309' : '#9f1239';
        ctx.beginPath();
        ctx.arc(pl.x - 8, pl.y, 2.8, 0, Math.PI * 2);
        ctx.arc(pl.x + 8, pl.y, 2.8, 0, Math.PI * 2);
        ctx.fill();
    });

    const benches = [
        { x: 1050, y: 590 }, { x: 1790, y: 590 }, { x: 810, y: 1170 }, { x: 1360, y: 1170 }
    ];
    benches.forEach(b => {
        ctx.fillStyle = '#573c28';
        drawRectRounded(b.x, b.y, 56, 16, 4);
        ctx.fill();
        ctx.strokeStyle = '#291d14';
        ctx.lineWidth = 2;
        ctx.stroke();
    });
}

function drawNoticeBoard(x, y, label) {
    ctx.fillStyle = '#5c4033';
    drawRectRounded(x, y, 76, 22, 4);
    ctx.fill();
    ctx.strokeStyle = '#291d14';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(x + 8, y + 4, 14, 13);
    ctx.fillStyle = '#fde68a';
    ctx.fillRect(x + 28, y + 5, 14, 12);
    ctx.fillStyle = '#fecaca';
    ctx.fillRect(x + 48, y + 4, 18, 13);
    if (label) {
        ctx.fillStyle = 'rgba(226, 232, 240, 0.75)';
        ctx.font = 'bold 7px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(label, x + 38, y + 31);
    }
}

function drawPottedPlant(x, y) {
    ctx.fillStyle = '#6b4226';
    drawRectRounded(x - 9, y + 4, 18, 13, 3);
    ctx.fill();
    ctx.fillStyle = '#2d5a3c';
    ctx.beginPath();
    ctx.arc(x - 5, y - 2, 7, 0, Math.PI * 2);
    ctx.arc(x + 5, y - 2, 7, 0, Math.PI * 2);
    ctx.arc(x, y - 7, 8, 0, Math.PI * 2);
    ctx.fill();
}

function drawRoomDecor(r) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.045)';
    ctx.lineWidth = 1.2;
    for (let gx = r.x + 40; gx < r.x + r.w - 20; gx += 48) {
        ctx.beginPath(); ctx.moveTo(gx, r.y + 45); ctx.lineTo(gx, r.y + r.h - 20); ctx.stroke();
    }
    for (let gy = r.y + 55; gy < r.y + r.h - 20; gy += 48) {
        ctx.beginPath(); ctx.moveTo(r.x + 20, gy); ctx.lineTo(r.x + r.w - 20, gy); ctx.stroke();
    }

    if (r.id === 'library') {
        const bookColors = ['#7f1d1d', '#78350f', '#1e3a5f', '#365314', '#4c1d95'];
        for (let i = 0; i < 3; i++) {
            const bx = r.x + 38 + i * 150;
            const by = r.y + 54;
            ctx.fillStyle = '#3b2820';
            drawRectRounded(bx, by, 114, 26, 4);
            ctx.fill();
            ctx.strokeStyle = '#1f1511';
            ctx.lineWidth = 1.5;
            ctx.stroke();
            for (let b = 0; b < 8; b++) {
                ctx.fillStyle = bookColors[(i + b) % bookColors.length];
                ctx.fillRect(bx + 8 + b * 12, by + 5, 8, 16);
            }
        }
        drawNoticeBoard(r.x + 36, r.y + 115, 'QUIET ZONE');
        ctx.fillStyle = '#334155';
        drawRectRounded(r.x + r.w - 115, r.y + 115, 72, 32, 6);
        ctx.fill();
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(r.x + r.w - 92, r.y + 108, 24, 14);

        [0, 1].forEach(idx => {
            const dx = r.x + 90 + idx * 215;
            const dy = r.y + 245;
            ctx.fillStyle = '#5c4033';
            drawRectRounded(dx, dy, 108, 44, 8);
            ctx.fill();
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(dx + 16, dy + 10, 22, 16);
            ctx.fillStyle = '#d97706';
            ctx.beginPath(); ctx.arc(dx + 84, dy + 16, 6, 0, Math.PI * 2); ctx.fill();
        });
        drawPottedPlant(r.x + 38, r.y + 315);
        drawPottedPlant(r.x + r.w - 38, r.y + 315);

    } else if (r.id === 'cafeteria') {
        ctx.fillStyle = '#1e293b';
        drawRectRounded(r.x + 215, r.y + 50, 165, 25, 5);
        ctx.fill();
        ctx.fillStyle = '#e2e8f0';
        ctx.font = 'bold 9.5px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('AUW CAFETERIA • DAILY MENU', r.x + 297, r.y + 66);
        drawNoticeBoard(r.x + r.w - 115, r.y + 52, 'CAMPUS NOTICES');

        [0, 1, 2].forEach(i => {
            const tx = r.x + 115 + i * 165;
            const ty = r.y + 255;
            ctx.fillStyle = '#475569';
            ctx.beginPath(); ctx.arc(tx - 34, ty, 9, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(tx + 34, ty, 9, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#785a46';
            ctx.beginPath(); ctx.arc(tx, ty, 27, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#3e2d22'; ctx.lineWidth = 2.5; ctx.stroke();
        });
        drawPottedPlant(r.x + 38, r.y + 82);
        drawPottedPlant(r.x + r.w - 38, r.y + 315);

    } else if (r.id === 'classroom') {
        ctx.fillStyle = '#5c4033';
        drawRectRounded(r.x + 48, r.y + 62, 92, 36, 6);
        ctx.fill();
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(r.x + 76, r.y + 56, 26, 14);
        drawNoticeBoard(r.x + r.w - 115, r.y + 62, 'SCHEDULE');

        for (let row = 0; row < 2; row++) {
            for (let col = 0; col < 3; col++) {
                const sx = r.x + 72 + col * 136;
                const sy = r.y + 175 + row * 85;
                ctx.fillStyle = '#645349';
                drawRectRounded(sx, sy, 84, 34, 6);
                ctx.fill();
                ctx.fillStyle = '#334155';
                ctx.fillRect(sx + 16, sy + 8, 20, 13);
                ctx.fillStyle = '#cbd5e1';
                ctx.fillRect(sx + 48, sy + 9, 16, 12);
            }
        }
        drawPottedPlant(r.x + r.w - 38, r.y + 315);

    } else if (r.id === 'lab') {
        ctx.fillStyle = '#0f172a';
        drawRectRounded(r.x + 40, r.y + 60, 48, 90, 6);
        ctx.fill();
        ctx.fillStyle = '#10b981';
        ctx.fillRect(r.x + 48, r.y + 72, 32, 4);
        ctx.fillRect(r.x + 48, r.y + 88, 32, 4);
        drawNoticeBoard(r.x + 115, r.y + 60, 'LAB RULES');

        for (let i = 0; i < 3; i++) {
            const lx = r.x + 68 + i * 142;
            const ly = r.y + 235;
            ctx.fillStyle = '#334155';
            drawRectRounded(lx, ly, 98, 40, 6);
            ctx.fill();
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(lx + 14, ly - 11, 28, 17);
            ctx.fillRect(lx + 54, ly - 11, 28, 17);
            ctx.fillStyle = '#0ea5e9';
            ctx.fillRect(lx + 17, ly - 8, 22, 11);
            ctx.fillRect(lx + 57, ly - 8, 22, 11);
        }
        drawPottedPlant(r.x + r.w - 38, r.y + 80);

    } else if (r.id === 'tales') {
        ctx.fillStyle = '#3b2820';
        drawRectRounded(r.x + 42, r.y + 56, 115, 24, 4);
        ctx.fill();
        drawNoticeBoard(r.x + r.w - 118, r.y + 56, 'EVENTS');

        ctx.fillStyle = 'rgba(71, 85, 105, 0.28)';
        ctx.beginPath();
        ctx.ellipse(r.x + 260, r.y + 225, 165, 85, 0, 0, Math.PI * 2);
        ctx.fill();

        const seatColors = ['#6b4c5b', '#5c5338', '#4c4669', '#3b594b'];
        [0, 1, 2, 3].forEach(i => {
            ctx.fillStyle = seatColors[i];
            ctx.beginPath();
            ctx.arc(r.x + 120 + i * 95, r.y + 285, 17, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#1e293b'; ctx.lineWidth = 2; ctx.stroke();
        });
        drawPottedPlant(r.x + 38, r.y + 315);
        drawPottedPlant(r.x + r.w - 38, r.y + 315);

    } else if (r.id === 'dinning') {
        ctx.fillStyle = '#334155';
        drawRectRounded(r.x + 42, r.y + 64, 34, 48, 6);
        ctx.fill();
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(r.x + 48, r.y + 70, 22, 18);
        drawNoticeBoard(r.x + r.w - 118, r.y + 64, 'ZERO WASTE');

        [0, 1].forEach(i => {
            const dx = r.x + 95 + i * 240;
            const dy = r.y + 215;
            ctx.fillStyle = '#6b5b45';
            drawRectRounded(dx, dy, 130, 50, 8);
            ctx.fill();
            ctx.fillStyle = '#cbd5e1';
            ctx.beginPath();
            ctx.arc(dx + 34, dy + 25, 10, 0, Math.PI * 2);
            ctx.arc(dx + 96, dy + 25, 10, 0, Math.PI * 2);
            ctx.fill();
        });
        drawPottedPlant(r.x + r.w - 38, r.y + 315);

    } else if (r.id === 'residential') {
        drawNoticeBoard(r.x + 45, r.y + 60, 'DORM CURFEW');
        ctx.fillStyle = '#3b2820';
        drawRectRounded(r.x + r.w - 110, r.y + 58, 68, 32, 5);
        ctx.fill();

        ctx.fillStyle = 'rgba(100, 116, 139, 0.2)';
        drawRectRounded(r.x + 150, r.y + 175, 220, 120, 14);
        ctx.fill();

        [0, 1].forEach(i => {
            const bx = r.x + 55 + i * 325;
            const by = r.y + 185;
            ctx.fillStyle = '#5c4033';
            drawRectRounded(bx, by, 84, 125, 8);
            ctx.fill();
            ctx.fillStyle = '#cbd5e1';
            drawRectRounded(bx + 14, by + 10, 56, 20, 4);
            ctx.fill();
            ctx.fillStyle = '#7f2d3f';
            drawRectRounded(bx + 6, by + 46, 72, 70, 6);
            ctx.fill();
        });
        drawPottedPlant(r.x + 255, r.y + 315);

    } else if (r.id === 'basketball') {
        ctx.strokeStyle = 'rgba(226, 232, 240, 0.35)';
        ctx.lineWidth = 3.5;
        ctx.strokeRect(r.x + 34, r.y + 52, r.w - 68, r.h - 82);
        ctx.beginPath();
        ctx.moveTo(r.x + r.w / 2, r.y + 52);
        ctx.lineTo(r.x + r.w / 2, r.y + r.h - 30);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(r.x + r.w / 2, r.y + r.h / 2 + 10, 50, 0, Math.PI * 2);
        ctx.stroke();

    } else if (r.id === 'garden') {
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(r.x + 135, r.y + 180, 46, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#1e3a5f';
        ctx.beginPath();
        ctx.arc(r.x + 135, r.y + 180, 36, 0, Math.PI * 2);
        ctx.fill();

        [0, 1, 2].forEach(i => {
            drawPottedPlant(r.x + 380 + i * 55, r.y + 120);
            drawPottedPlant(r.x + 380 + i * 55, r.y + 250);
        });
    }
    ctx.restore();
}

function updateActionHUD() {
    if (!localPlayer) return;
    const roomName = getPlayerRoomName(localPlayer);
    document.getElementById('hud-room-name').innerText = roomName.toUpperCase();
    const miniTag = document.getElementById('minimap-room-tag');
    if (miniTag) miniTag.innerText = roomName.toUpperCase();

    const hudCctvBtn = document.getElementById('btn-hud-cctv');
    if (hudCctvBtn) {
        hudCctvBtn.classList.toggle('hidden', roomName !== 'Lab room');
    }

    const nearBreaker = isNearPowerBreaker();
    const nearClue = getNearbyClue();
    const nearCctv = isNearCctvTerminal();
    const nearTask = getNearbyTask();
    const nearEmergency = Math.hypot(localPlayer.x - EMERGENCY_BUTTON.x, localPlayer.y - EMERGENCY_BUTTON.y) < 90;
    const banner = document.getElementById('interaction-banner');
    const useBtn = document.getElementById('btn-use');

    if (nearBreaker) {
        banner.classList.remove('hidden');
        document.getElementById('interact-icon').innerText = '⚡';
        document.getElementById('interact-title').innerText = 'PRESS E TO RESTORE POWER';
        document.getElementById('interact-sub').innerText = 'Lab Electrical Breaker Box';
        document.getElementById('btn-interact-banner').onclick = () => interactWithNearby();
        useBtn.disabled = false;
    } else if (nearCctv) {
        banner.classList.remove('hidden');
        document.getElementById('interact-icon').innerText = '🎥';
        document.getElementById('interact-title').innerText = 'PRESS E FOR LAB CCTV';
        document.getElementById('interact-sub').innerText = 'Campus Security Surveillance Monitor';
        document.getElementById('btn-interact-banner').onclick = () => interactWithNearby();
        useBtn.disabled = false;
    } else if (nearClue) {
        banner.classList.remove('hidden');
        document.getElementById('interact-icon').innerText = '🔍';
        document.getElementById('interact-title').innerText = 'PRESS E TO INSPECT CLUE';
        document.getElementById('interact-sub').innerText = nearClue.title;
        document.getElementById('btn-interact-banner').onclick = () => interactWithNearby();
        useBtn.disabled = false;
    } else if (nearTask) {
        banner.classList.remove('hidden');
        document.getElementById('interact-icon').innerText = nearTask.icon;
        document.getElementById('interact-title').innerText = 'PRESS E TO USE';
        document.getElementById('interact-sub').innerText = `${nearTask.objectLabel} (${nearTask.title})`;
        document.getElementById('btn-interact-banner').onclick = () => interactWithNearby();
        useBtn.disabled = false;
    } else if (nearEmergency) {
        banner.classList.remove('hidden');
        document.getElementById('interact-icon').innerText = '🚨';
        document.getElementById('interact-title').innerText = 'PRESS E FOR MEETING';
        document.getElementById('interact-sub').innerText = 'Cafeteria Emergency Table';
        document.getElementById('btn-interact-banner').onclick = () => interactWithNearby();
        useBtn.disabled = false;
    } else {
        banner.classList.add('hidden');
        useBtn.disabled = true;
    }

    const nearBody = getNearbyBody();
    document.getElementById('btn-report').disabled = !(nearBody || nearEmergency);

    if (localPlayer.isImpostor) {
        const killBtn = document.getElementById('btn-kill');
        const target = getNearbyKillTarget();
        killBtn.disabled = !target;
        killBtn.innerText = killCooldown > 0 ? `🔪 ${Math.ceil(killCooldown)}s` : '🔪 KILL (Q)';
        document.getElementById('btn-vent').disabled = !getNearbyVent();

        const sabBtn = document.getElementById('btn-sabotage');
        sabBtn.disabled = sabotageCooldown > 0;
        sabBtn.innerText = sabotageCooldown > 0 ? `⚡ ${Math.ceil(sabotageCooldown)}s` : '⚡ SABOTAGE';

        const disBtn = document.getElementById('btn-disguise');
        disBtn.disabled = disguiseCooldown > 0 && disguiseTimer <= 0;
        if (disguiseTimer > 0) {
            disBtn.innerText = `🎭 ${Math.ceil(disguiseTimer)}s`;
        } else if (disguiseCooldown > 0) {
            disBtn.innerText = `🎭 ${Math.ceil(disguiseCooldown)}s`;
        } else {
            disBtn.innerText = '🎭 DISGUISE (F)';
        }
    }
}

function update(dt) {
    if (gameState !== 'PLAYING' || !localPlayer) return;
    roundElapsedTime += dt;
    if (killCooldown > 0) killCooldown = Math.max(0, killCooldown - dt);
    if (sabotageCooldown > 0) sabotageCooldown = Math.max(0, sabotageCooldown - dt);
    if (disguiseCooldown > 0) disguiseCooldown = Math.max(0, disguiseCooldown - dt);
    if (disguiseTimer > 0) {
        disguiseTimer = Math.max(0, disguiseTimer - dt);
        if (disguiseTimer === 0) disguiseAppearance = null;
    }

    // Random Dynamic Campus Events (Offline mode only; online mode syncs events across devices)
    if (connectionMode === 'OFFLINE') {
        nextRandomEventTimer -= dt;
        if (nextRandomEventTimer <= 0) {
            nextRandomEventTimer = 28 + Math.random() * 14;
            const roll = Math.random();
            if (roll < 0.35 && !sabotageLights) {
                sabotageLights = true;
                triggerPaAnnouncement('⚡ SUDDEN POWER FAILURE: Campus lights offline! Reset breaker in Lab room.');
            } else if (roll < 0.7 && lockdownTimer <= 0) {
                lockdownTimer = 14;
                DOORS.forEach((d, idx) => { d.locked = (idx === 1 || idx === 4 || idx === 7); });
                triggerPaAnnouncement('🔒 CAMPUS LOCKDOWN: Select corridor security gates sealed for 14 seconds!');
            } else {
                const alerts = [
                    '📢 CAMPUS PA: Unidentified footsteps reported near Residential Hall.',
                    '📢 CAMPUS PA: Check CCTV monitor in Lab room for live room feeds.',
                    '📢 CAMPUS PA: Weather advisory—light rain over AUW courtyard.'
                ];
                triggerPaAnnouncement(alerts[Math.floor(Math.random() * alerts.length)]);
            }
        }
    }

    if (lockdownTimer > 0) {
        lockdownTimer = Math.max(0, lockdownTimer - dt);
        if (lockdownTimer === 0) {
            DOORS.forEach(d => { d.locked = false; });
            triggerPaAnnouncement('🔓 LOCKDOWN LIFTED: All campus corridor gates unlocked.');
        }
    }

    DOORS.forEach(d => {
        const anyoneNear = !d.locked && players.some(p => !p.isDead && Math.hypot(p.x - d.x, p.y - d.y) < 95);
        const targetOpen = anyoneNear ? 1 : 0;
        if (d.openAmount < targetOpen) {
            if (d.openAmount === 0 && localPlayer && Math.hypot(localPlayer.x - d.x, localPlayer.y - d.y) < 120) sfx.doorSlide();
            d.openAmount = Math.min(1, d.openAmount + dt * 4);
        } else if (d.openAmount > targetOpen) {
            d.openAmount = Math.max(0, d.openAmount - dt * 3);
        }
    });

    deadBodies.forEach(b => {
        if (!b.discovered && localPlayer && !localPlayer.isDead && Math.hypot(localPlayer.x - b.x, localPlayer.y - b.y) < 115) {
            b.discovered = true;
            sfx.alarm();
            const overlay = document.getElementById('body-discovery-overlay');
            const sub = document.getElementById('body-discovery-sub');
            if (overlay && sub) {
                sub.innerText = `${b.name} was eliminated! Press R or REPORT immediately!`;
                overlay.classList.remove('hidden');
                setTimeout(() => overlay.classList.add('hidden'), 2200);
            }
        }
    });

    if (weatherMode === 'RAIN') {
        rainDrops.forEach(drop => {
            drop.x -= drop.speed * 0.25 * dt;
            drop.y += drop.speed * dt;
            if (drop.y > canvas.height) { drop.y = -20; drop.x = Math.random() * canvas.width; }
            if (drop.x < 0) drop.x += canvas.width;
        });
    }

    if (!localPlayer.isDead) {
        localPlayer.animTime += dt;
        if (localPlayer.celebrateTimer > 0) localPlayer.celebrateTimer = Math.max(0, localPlayer.celebrateTimer - dt);

        let dx = 0, dy = 0;
        if (keys['w'] || keys['arrowup'] || dpad.up) dy -= 1;
        if (keys['s'] || keys['arrowdown'] || dpad.down) dy += 1;
        if (keys['a'] || keys['arrowleft'] || dpad.left) dx -= 1;
        if (keys['d'] || keys['arrowright'] || dpad.right) dx += 1;

        if (dx !== 0 || dy !== 0) {
            const len = Math.hypot(dx, dy);
            dx /= len;
            dy /= len;
            if (dx < 0) localPlayer.facingRight = false;
            if (dx > 0) localPlayer.facingRight = true;

            const isRunning = Boolean(keys['shift']);
            localPlayer.animState = isRunning ? 'run' : 'walk';
            const speed = (isRunning ? 385 : 285) * dt;
            if (isPointWalkable(localPlayer.x + dx * speed, localPlayer.y)) localPlayer.x += dx * speed;
            if (isPointWalkable(localPlayer.x, localPlayer.y + dy * speed)) localPlayer.y += dy * speed;

            sfx.stepTimer -= dt;
            if (sfx.stepTimer <= 0) {
                sfx.footstep();
                sfx.stepTimer = isRunning ? 0.24 : 0.34;
            }
        } else if (localPlayer.celebrateTimer > 0) {
            localPlayer.animState = 'celebrate';
        } else {
            localPlayer.animState = 'idle';
        }
    }

    // Sync Local Player State to Online Multiplayer Room
    if (connectionMode === 'ONLINE' && window.mpBackend && localPlayer) {
        const nowMs = performance.now();
        if (nowMs - lastNetSync > 85) {
            lastNetSync = nowMs;
            window.mpBackend.syncLocalPlayer(localPlayer);
        }
    }

    // Smooth interpolation for remote online human players + AI Student behavior in Offline Mode
    players.forEach(p => {
        if (p.isUser || p.isDead) return;
        p.animTime += dt;

        if (p.isRemoteHuman) {
            if (typeof p.netTargetX === 'number' && typeof p.netTargetY === 'number') {
                const lerp = Math.min(1, dt * 14);
                p.x += (p.netTargetX - p.x) * lerp;
                p.y += (p.netTargetY - p.y) * lerp;
            }
            return;
        }

        if (p.aiWait > 0) {
            p.aiWait -= dt;
            p.animState = p.performingTask ? 'celebrate' : 'idle';
        } else {
            p.performingTask = false;
            const dist = Math.hypot(p.targetX - p.x, p.targetY - p.y);
            if (dist < 24) {
                if (!p.isImpostor && Math.random() < 0.45) {
                    const t = TASKS[Math.floor(Math.random() * TASKS.length)];
                    p.targetX = t.x + (Math.random() * 36 - 18);
                    p.targetY = t.y + 38;
                    p.performingTask = true;
                    p.aiWait = 2.2 + Math.random() * 1.5;
                } else {
                    const r = ROOMS[Math.floor(Math.random() * ROOMS.length)];
                    p.targetX = r.x + 80 + Math.random() * (r.w - 160);
                    p.targetY = r.y + 80 + Math.random() * (r.h - 160);
                    p.aiWait = 0.8 + Math.random() * 1.6;
                }
                p.animState = 'idle';
            } else {
                p.animState = 'walk';
                const vx = ((p.targetX - p.x) / dist) * 165 * dt;
                const vy = ((p.targetY - p.y) / dist) * 165 * dt;
                if (vx < 0) p.facingRight = false;
                if (vx > 0) p.facingRight = true;
                if (isPointWalkable(p.x + vx, p.y)) p.x += vx;
                else {
                    const r = ROOMS[Math.floor(Math.random() * ROOMS.length)];
                    p.targetX = r.x + r.w / 2;
                    p.targetY = r.y + r.h / 2;
                }
                if (isPointWalkable(p.x, p.y + vy)) p.y += vy;
            }
        }

        if (!p.isImpostor && deadBodies.some(b => Math.hypot(b.x - p.x, b.y - p.y) < 85) && Math.random() < 0.012) {
            witnessReports.push(`${p.flag} ${p.name}: "I just found a student down on campus!"`);
            startMeeting(`BODY REPORTED BY ${p.name.toUpperCase()}`);
        }

        if (p.isImpostor) {
            p.aiKillTimer -= dt;
            if (p.aiKillTimer <= 0) {
                const victim = players.find(v => !v.isImpostor && !v.isDead && Math.hypot(v.x - p.x, v.y - p.y) < 68);
                if (victim) {
                    killPlayer(victim);
                    p.aiKillTimer = 18;
                }
            }
        }
    });

    updateActionHUD();
    drawCampusRadar(document.getElementById('minimapCanvas'), false);
    renderCctvFeed();
}

/* ==========================================================================
   CUTE CHIBI CARTOON CHARACTER RENDERER (WITH CUSTOM DRESS COLOURS)
   ========================================================================== */
function drawOriginalCharacter(targetCtx, p) {
    const c = p.charColor || CHAR_COLORS[0];
    const dress = p.dressColor || DRESS_COLORS[0];
    const acc = p.accessory || 'none';
    const state = p.animState || 'idle';
    const t = p.animTime || 0;

    if (!p.facingRight) targetCtx.scale(-1, 1);

    let bounceY = 0;
    let leftLegY = 0;
    let rightLegY = 0;
    let bodyTilt = 0;
    let armAngle = 0;

    if (state === 'walk') {
        bounceY = -Math.abs(Math.sin(t * 10)) * 2.5;
        leftLegY = Math.sin(t * 10) * 3.5;
        rightLegY = -Math.sin(t * 10) * 3.5;
        bodyTilt = 0.04;
        armAngle = Math.sin(t * 10) * 0.35;
    } else if (state === 'run') {
        bounceY = -Math.abs(Math.sin(t * 16)) * 4;
        leftLegY = Math.sin(t * 16) * 5;
        rightLegY = -Math.sin(t * 16) * 5;
        bodyTilt = 0.14;
        armAngle = Math.sin(t * 16) * 0.6;
    } else if (state === 'celebrate') {
        bounceY = -Math.abs(Math.sin(t * 9)) * 7;
        armAngle = -1.1 + Math.sin(t * 14) * 0.25;
    } else {
        bounceY = Math.sin(t * 3.2) * 1;
    }

    targetCtx.fillStyle = 'rgba(0, 0, 0, 0.36)';
    targetCtx.beginPath();
    targetCtx.ellipse(0, 21, 14 - Math.abs(bounceY) * 0.4, 4.8, 0, 0, Math.PI * 2);
    targetCtx.fill();

    targetCtx.save();
    targetCtx.translate(0, bounceY);
    targetCtx.rotate(bodyTilt);

    if (acc === 'backpack') {
        targetCtx.fillStyle = c.shade;
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 2;
        targetCtx.beginPath();
        targetCtx.roundRect(-16, 1, 9, 13, 4);
        targetCtx.fill();
        targetCtx.stroke();
    }

    targetCtx.fillStyle = '#1e293b';
    targetCtx.strokeStyle = '#0f172a';
    targetCtx.lineWidth = 1.8;
    targetCtx.beginPath();
    targetCtx.roundRect(-7, 12 + leftLegY, 5.5, 8, 2.8);
    targetCtx.fill();
    targetCtx.stroke();

    targetCtx.beginPath();
    targetCtx.roundRect(2.5, 12 + rightLegY, 5.5, 8, 2.8);
    targetCtx.fill();
    targetCtx.stroke();

    // Customizable Dress / Tunic Body
    targetCtx.fillStyle = dress.main;
    targetCtx.strokeStyle = '#0f172a';
    targetCtx.lineWidth = 2;
    targetCtx.beginPath();
    targetCtx.moveTo(-9, 1);
    targetCtx.lineTo(9, 1);
    targetCtx.lineTo(13, 14.5);
    targetCtx.lineTo(-13, 14.5);
    targetCtx.closePath();
    targetCtx.fill();
    targetCtx.stroke();

    // Dress Hem Trim
    targetCtx.fillStyle = dress.hem;
    targetCtx.fillRect(-10.5, 11.5, 21, 2.4);

    // AUW Maroon Student ID Lanyard & Badge
    targetCtx.strokeStyle = '#881337';
    targetCtx.lineWidth = 1.6;
    targetCtx.beginPath();
    targetCtx.moveTo(-3, 1);
    targetCtx.lineTo(2, 6);
    targetCtx.lineTo(7, 1);
    targetCtx.stroke();

    targetCtx.fillStyle = '#881337';
    targetCtx.fillRect(0, 5.5, 4.5, 5.5);

    targetCtx.save();
    targetCtx.translate(-2, 5);
    targetCtx.rotate(armAngle);
    targetCtx.fillStyle = c.shade;
    targetCtx.strokeStyle = '#0f172a';
    targetCtx.lineWidth = 1.6;
    targetCtx.beginPath();
    targetCtx.roundRect(-2.5, 0, 5, 8, 2.5);
    targetCtx.fill();
    targetCtx.stroke();
    targetCtx.restore();

    targetCtx.fillStyle = c.main;
    targetCtx.strokeStyle = '#0f172a';
    targetCtx.lineWidth = 2.2;
    targetCtx.beginPath();
    targetCtx.roundRect(-14.5, -21, 29, 24, 12);
    targetCtx.fill();
    targetCtx.stroke();

    targetCtx.fillStyle = '#fff7ed';
    targetCtx.beginPath();
    targetCtx.roundRect(-10, -16.5, 22.5, 16.5, 8.5);
    targetCtx.fill();

    targetCtx.fillStyle = 'rgba(251, 113, 133, 0.65)';
    targetCtx.beginPath(); targetCtx.ellipse(-4.5, -5.5, 2.6, 1.5, 0, 0, Math.PI * 2); targetCtx.fill();
    targetCtx.beginPath(); targetCtx.ellipse(9.5, -5.5, 2.6, 1.5, 0, 0, Math.PI * 2); targetCtx.fill();

    if (state === 'celebrate') {
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 2;
        targetCtx.beginPath(); targetCtx.arc(-2, -9, 2.5, Math.PI, 0); targetCtx.stroke();
        targetCtx.beginPath(); targetCtx.arc(7, -9, 2.5, Math.PI, 0); targetCtx.stroke();
    } else {
        targetCtx.fillStyle = '#0f172a';
        targetCtx.beginPath(); targetCtx.arc(-2, -9.5, 2.3, 0, Math.PI * 2); targetCtx.fill();
        targetCtx.beginPath(); targetCtx.arc(7, -9.5, 2.3, 0, Math.PI * 2); targetCtx.fill();

        targetCtx.fillStyle = '#ffffff';
        targetCtx.beginPath(); targetCtx.arc(-1.3, -10.3, 0.9, 0, Math.PI * 2); targetCtx.fill();
        targetCtx.beginPath(); targetCtx.arc(7.7, -10.3, 0.9, 0, Math.PI * 2); targetCtx.fill();
    }

    targetCtx.strokeStyle = '#0f172a';
    targetCtx.lineWidth = 1.6;
    targetCtx.beginPath();
    if (state === 'celebrate') {
        targetCtx.arc(2.5, -6, 3, 0.1, Math.PI - 0.1);
    } else {
        targetCtx.arc(2.5, -6.5, 2.2, 0.15, Math.PI - 0.15);
    }
    targetCtx.stroke();

    if (acc === 'glasses') {
        targetCtx.strokeStyle = '#1e293b';
        targetCtx.lineWidth = 1.6;
        targetCtx.strokeRect(-5.5, -13, 6.5, 6);
        targetCtx.strokeRect(3.5, -13, 6.5, 6);
        targetCtx.beginPath(); targetCtx.moveTo(1, -10); targetCtx.lineTo(3.5, -10); targetCtx.stroke();
    } else if (acc === 'headphones') {
        targetCtx.strokeStyle = '#334155';
        targetCtx.lineWidth = 3;
        targetCtx.beginPath(); targetCtx.arc(0, -10, 15.5, Math.PI * 1.05, Math.PI * 1.95); targetCtx.stroke();
        targetCtx.fillStyle = '#38bdf8';
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 1.8;
        targetCtx.beginPath(); targetCtx.roundRect(-17.5, -13, 6, 10, 3); targetCtx.fill(); targetCtx.stroke();
    } else if (acc === 'bow') {
        targetCtx.fillStyle = '#f43f5e';
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 1.5;
        targetCtx.beginPath();
        targetCtx.moveTo(-7, -21); targetCtx.lineTo(-14, -26); targetCtx.lineTo(-13, -17); targetCtx.closePath(); targetCtx.fill(); targetCtx.stroke();
        targetCtx.beginPath();
        targetCtx.moveTo(-7, -21); targetCtx.lineTo(0, -26); targetCtx.lineTo(-1, -17); targetCtx.closePath(); targetCtx.fill(); targetCtx.stroke();
        targetCtx.beginPath(); targetCtx.arc(-7, -21, 2.5, 0, Math.PI * 2); targetCtx.fill();
    } else if (acc === 'cap') {
        targetCtx.fillStyle = '#0284c7';
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 1.8;
        targetCtx.beginPath(); targetCtx.arc(0, -17, 13, Math.PI, 0); targetCtx.fill(); targetCtx.stroke();
        targetCtx.fillRect(0, -19, 18, 3.5);
    } else if (acc === 'hairclip') {
        targetCtx.fillStyle = '#facc15';
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 1.4;
        targetCtx.beginPath();
        targetCtx.arc(-8, -16, 3.8, 0, Math.PI * 2);
        targetCtx.fill();
        targetCtx.stroke();
    } else if (acc === 'hat') {
        targetCtx.fillStyle = '#881337';
        targetCtx.strokeStyle = '#0f172a';
        targetCtx.lineWidth = 1.8;
        targetCtx.beginPath();
        targetCtx.ellipse(-1, -21, 14, 5.5, -0.15, 0, Math.PI * 2);
        targetCtx.fill();
        targetCtx.stroke();
    }

    targetCtx.restore();
}

function drawBean(p) {
    ctx.save();
    ctx.translate(p.x, p.y);
    const shown = (p.isUser && disguiseTimer > 0 && disguiseAppearance) ? disguiseAppearance : p;

    if (p.isUser && localPlayer) {
        const aura = ctx.createRadialGradient(0, 6, 4, 0, 6, 32);
        aura.addColorStop(0, 'rgba(34, 211, 238, 0.32)');
        aura.addColorStop(1, 'rgba(34, 211, 238, 0)');
        ctx.fillStyle = aura;
        ctx.beginPath();
        ctx.arc(0, 6, 32, 0, Math.PI * 2);
        ctx.fill();
    }

    ctx.font = '900 12px system-ui, sans-serif';
    ctx.textAlign = 'center';
    const badgeText = `${shown.flag || ''} ${shown.name}${p.isUser ? ' (You)' : ''}`;
    const badgeWidth = Math.max(66, ctx.measureText(badgeText).width + 16);

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    drawRectRounded(-badgeWidth / 2, -45, badgeWidth, 18, 9);
    ctx.fill();
    ctx.strokeStyle = p.isUser ? '#22d3ee' : 'rgba(148, 163, 184, 0.45)';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.fillStyle = (p.isImpostor && localPlayer && localPlayer.isImpostor && disguiseTimer <= 0) ? '#f87171' : '#ffffff';
    ctx.fillText(badgeText, 0, -32);

    drawOriginalCharacter(ctx, {
        charColor: shown.charColor,
        dressColor: shown.dressColor,
        accessory: shown.accessory,
        facingRight: p.facingRight,
        animState: p.animState,
        animTime: p.animTime
    });

    ctx.restore();
}

function drawFogOfWar() {
    if (!localPlayer || localPlayer.isDead) return;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const visionRadius = sabotageLights ? 145 : 370;

    const grad = ctx.createRadialGradient(cx, cy, visionRadius * 0.45, cx, cy, visionRadius);
    grad.addColorStop(0, 'rgba(2, 6, 23, 0)');
    grad.addColorStop(0.75, sabotageLights ? 'rgba(2, 6, 23, 0.88)' : 'rgba(2, 6, 23, 0.35)');
    grad.addColorStop(1, sabotageLights ? 'rgba(2, 6, 23, 0.98)' : 'rgba(2, 6, 23, 0.84)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function render() {
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (!localPlayer) return;

    ctx.save();
    ctx.translate(canvas.width / 2 - localPlayer.x, canvas.height / 2 - localPlayer.y);

    drawOutdoorCampusScenery();

    ctx.fillStyle = '#3f4852';
    CORRIDORS.forEach(c => {
        ctx.fillRect(c.x, c.y, c.w, c.h);
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 3;
        ctx.strokeRect(c.x, c.y, c.w, c.h);
    });

    DOORS.forEach(d => {
        ctx.save();
        ctx.translate(d.x, d.y);
        ctx.fillStyle = d.locked ? '#991b1b' : '#334155';
        ctx.strokeStyle = d.locked ? '#f87171' : '#94a3b8';
        ctx.lineWidth = 2;
        if (d.horizontal) {
            const slide = d.openAmount * 28;
            ctx.fillRect(-6, -42 - slide, 12, 38);
            ctx.strokeRect(-6, -42 - slide, 12, 38);
            ctx.fillRect(-6, 4 + slide, 12, 38);
            ctx.strokeRect(-6, 4 + slide, 12, 38);
        } else {
            const slide = d.openAmount * 28;
            ctx.fillRect(-42 - slide, -6, 38, 12);
            ctx.strokeRect(-42 - slide, -6, 38, 12);
            ctx.fillRect(4 + slide, -6, 38, 12);
            ctx.strokeRect(4 + slide, -6, 38, 12);
        }
        ctx.restore();
    });

    ROOMS.forEach(r => {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.52)';
        drawRectRounded(r.x + 12, r.y + 14, r.w, r.h, 24);
        ctx.fill();

        ctx.fillStyle = r.fill;
        drawRectRounded(r.x, r.y, r.w, r.h, 24);
        ctx.fill();

        ctx.strokeStyle = r.border;
        ctx.lineWidth = 8;
        ctx.stroke();

        drawRoomDecor(r);

        ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
        drawRectRounded(r.x + r.w / 2 - 94, r.y + 12, 188, 28, 10);
        ctx.fill();
        ctx.strokeStyle = r.border;
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = '900 13px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(r.name.toUpperCase(), r.x + r.w / 2, r.y + 30);
    });

    VENTS.forEach(v => {
        ctx.fillStyle = '#334155';
        ctx.fillRect(v.x - 18, v.y - 14, 36, 28);
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2;
        ctx.strokeRect(v.x - 18, v.y - 14, 36, 28);
        ctx.beginPath();
        ctx.moveTo(v.x - 12, v.y - 5); ctx.lineTo(v.x + 12, v.y - 5);
        ctx.moveTo(v.x - 12, v.y + 5); ctx.lineTo(v.x + 12, v.y + 5);
        ctx.stroke();
    });

    ctx.fillStyle = '#475569';
    ctx.beginPath();
    ctx.arc(EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y, EMERGENCY_BUTTON.r + 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.arc(EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y, EMERGENCY_BUTTON.r - 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 9px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('EMERGENCY', EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y + 3);

    // Lab Electrical Power Breaker Box
    ctx.fillStyle = sabotageLights ? '#7f1d1d' : '#1e293b';
    drawRectRounded(POWER_BREAKER.x - 23, POWER_BREAKER.y - 23, 46, 46, 8);
    ctx.fill();
    ctx.strokeStyle = sabotageLights ? '#f87171' : '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.font = '18px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('⚡', POWER_BREAKER.x, POWER_BREAKER.y + 6);

    // Lab Room CCTV Surveillance Monitor Station
    const nearCctv = isNearCctvTerminal();
    ctx.fillStyle = '#062c22';
    drawRectRounded(CCTV_TERMINAL.x - 33, CCTV_TERMINAL.y - 26, 66, 52, 9);
    ctx.fill();
    ctx.strokeStyle = nearCctv ? '#34d399' : '#10b981';
    ctx.lineWidth = nearCctv ? 3.5 : 2;
    ctx.stroke();

    ctx.fillStyle = '#022c22';
    ctx.fillRect(CCTV_TERMINAL.x - 25, CCTV_TERMINAL.y - 19, 22, 14);
    ctx.fillRect(CCTV_TERMINAL.x + 3, CCTV_TERMINAL.y - 19, 22, 14);
    ctx.fillRect(CCTV_TERMINAL.x - 25, CCTV_TERMINAL.y - 2, 22, 14);
    ctx.fillRect(CCTV_TERMINAL.x + 3, CCTV_TERMINAL.y - 2, 22, 14);

    ctx.fillStyle = '#34d399';
    ctx.fillRect(CCTV_TERMINAL.x - 22, CCTV_TERMINAL.y - 16, 16, 8);
    ctx.fillRect(CCTV_TERMINAL.x + 6, CCTV_TERMINAL.y - 16, 16, 8);
    ctx.fillRect(CCTV_TERMINAL.x - 22, CCTV_TERMINAL.y + 1, 16, 8);
    ctx.fillRect(CCTV_TERMINAL.x + 6, CCTV_TERMINAL.y + 1, 16, 8);

    ctx.fillStyle = '#a7f3d0';
    ctx.font = '900 8px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('🎥 LAB CCTV', CCTV_TERMINAL.x, CCTV_TERMINAL.y + 22);

    // Clues
    CLUES.forEach(c => {
        if (c.found) return;
        const glow = 8 + Math.sin(performance.now() / 180) * 3;
        ctx.fillStyle = 'rgba(250, 204, 21, 0.25)';
        ctx.beginPath(); ctx.arc(c.x, c.y, glow + 6, 0, Math.PI * 2); ctx.fill();
        ctx.font = '16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('🔍', c.x, c.y + 5);
    });

    TASKS.forEach(t => {
        const isNear = Math.hypot(localPlayer.x - t.x, localPlayer.y - t.y) < 92;
        ctx.save();
        ctx.translate(t.x, t.y);

        if (!t.completed) {
            const pulse = 36 + Math.sin(performance.now() / 180) * 6;
            ctx.strokeStyle = isNear ? 'rgba(52, 211, 153, 0.9)' : 'rgba(250, 204, 21, 0.65)';
            ctx.lineWidth = isNear ? 4 : 2.5;
            ctx.beginPath();
            ctx.arc(0, 0, pulse, 0, Math.PI * 2);
            ctx.stroke();
        }

        ctx.fillStyle = t.completed ? '#064e3b' : '#1e293b';
        drawRectRounded(-t.w / 2, -t.h / 2, t.w, t.h, 12);
        ctx.fill();
        ctx.strokeStyle = t.completed ? '#34d399' : (isNear ? '#34d399' : '#facc15');
        ctx.lineWidth = isNear ? 4 : 3;
        ctx.stroke();

        ctx.font = '20px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(t.completed ? '✅' : t.icon, 0, 5);

        ctx.fillStyle = t.completed ? '#6ee7b7' : '#fde047';
        ctx.font = '900 9px system-ui, sans-serif';
        ctx.fillText(t.objectLabel, 0, t.h / 2 + 13);
        ctx.restore();
    });

    deadBodies.forEach(b => {
        ctx.save();
        ctx.translate(b.x, b.y);
        ctx.fillStyle = 'rgba(220, 38, 38, 0.25)';
        ctx.beginPath(); ctx.ellipse(0, 8, 22, 9, 0, 0, Math.PI * 2); ctx.fill();
        ctx.rotate(Math.PI / 2);
        drawOriginalCharacter(ctx, {
            charColor: b.charColor,
            dressColor: b.dressColor,
            accessory: b.accessory,
            facingRight: true,
            animState: 'idle',
            animTime: 0
        });
        ctx.restore();

        ctx.fillStyle = '#fca5a5';
        ctx.font = '900 10px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`🚨 ${b.name} (REPORT)`, b.x, b.y - 24);
    });

    players.forEach(p => { if (!p.isDead) drawBean(p); });

    ctx.restore();

    drawFogOfWar();

    if (weatherMode === 'RAIN') {
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.28)';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        rainDrops.forEach(d => {
            ctx.moveTo(d.x, d.y);
            ctx.lineTo(d.x - 3, d.y + d.len);
        });
        ctx.stroke();
    }

    if (sabotageLights) {
        ctx.fillStyle = 'rgba(220, 38, 38, 0.16)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fca5a5';
        ctx.font = '900 14px system-ui, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('⚠️ LIGHTS SABOTAGED! GO TO LAB ROOM & PRESS E ON POWER BREAKER ⚠️', canvas.width / 2, 148);
    }
}

let lastTime = performance.now();
function gameLoop(now) {
    const dt = Math.min(0.05, (now - lastTime) / 1000);
    lastTime = now;
    update(dt);
    render();
    requestAnimationFrame(gameLoop);
}

/* ==========================================================================
   REAL-TIME ONLINE MULTIPLAYER ENGINE (FIRESTORE + PUBLIC WSS CLOUD)
   ========================================================================== */
(function setupMultiplayerBackend() {
    const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
    let firebaseConfig = null;
    try {
        if (typeof __firebase_config !== 'undefined' && __firebase_config) {
            firebaseConfig = JSON.parse(__firebase_config);
        }
    } catch (e) {
        firebaseConfig = null;
    }

    const PRESET_SERVERS = [
        { id: 'AUW-SERVER-1', label: 'AUW Campus Main #1' },
        { id: 'AUW-SERVER-2', label: 'AUW Scholars Hall #2' },
        { id: 'AUW-SERVER-3', label: 'AUW Asia Lounge #3' },
        { id: 'AUW-SERVER-4', label: 'AUW Night Patrol #4' }
    ];
    const PRESET_IDS = new Set(PRESET_SERVERS.map(s => s.id));
    const MIN_PLAYERS_TO_START = 4;

    let app = null;
    let auth = null;
    let db = null;
    let fsApi = null;
    let currentUser = null;
    let currentRoom = null;
    let unsubRoom = null;
    let unsubPlayers = null;
    let unsubServerBrowser = null;
    let heartbeatInterval = null;
    let lobbyCountdownInterval = null;
    let lobbyCountdownValue = null;
    let remotePlayersMap = new Map();
    let localReceiptMap = new Map();
    let lastSeenSeqMap = new Map();
    let lobbyPlayersList = [];
    let lastChatCount = 0;
    let lastLobbyChatCount = 0;
    let onlineMeetingTimer = null;
    let pendingLocalProfile = null;
    let currentRoomData = null;
    let myHeartbeatSeq = 0;

    async function initFirebaseIfAvailable() {
        if (!firebaseConfig) return false;
        if (app && auth && db && fsApi) return true;
        try {
            const appMod = await import("https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js");
            const authMod = await import("https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js");
            const fsMod = await import("https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js");
            app = appMod.initializeApp(firebaseConfig);
            auth = authMod.getAuth(app);
            db = fsMod.getFirestore(app);
            fsApi = { ...authMod, ...fsMod };
            return true;
        } catch (e) {
            app = null;
            auth = null;
            db = null;
            fsApi = null;
            return false;
        }
    }

    async function ensureAuth() {
        const hasFb = await initFirebaseIfAvailable();
        if (hasFb && auth && db && fsApi) {
            if (currentUser) return currentUser.uid;
            try {
                if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
                    try {
                        const cred = await fsApi.signInWithCustomToken(auth, __initial_auth_token);
                        currentUser = cred.user;
                    } catch (tokenErr) {
                        const anonCred = await fsApi.signInAnonymously(auth);
                        currentUser = anonCred.user;
                    }
                } else {
                    const cred = await fsApi.signInAnonymously(auth);
                    currentUser = cred.user;
                }
                return currentUser ? currentUser.uid : null;
            } catch (err) {
                console.error('Firebase Auth error:', err);
                return null;
            }
        }
        return mqttCloudRelay.ensureAuth();
    }

    function getRoomsColRef() {
        return fsApi.collection(db, 'artifacts', appId, 'public', 'data', 'auw_mp_rooms');
    }

    function getRoomDocRef(roomCode) {
        return fsApi.doc(db, 'artifacts', appId, 'public', 'data', 'auw_mp_rooms', roomCode);
    }

    function getPlayersColRef(roomCode) {
        return fsApi.collection(db, 'artifacts', appId, 'public', 'data', 'auw_mp_players_' + roomCode);
    }

    function getPlayerDocRef(roomCode, uid) {
        return fsApi.doc(db, 'artifacts', appId, 'public', 'data', 'auw_mp_players_' + roomCode, uid);
    }

    function renderServerBrowser(liveRooms) {
        const listEl = document.getElementById('online-server-list');
        if (!listEl) return;

        const inp = document.getElementById('online-room-code');
        const selectedCode = (inp ? inp.value.trim().toUpperCase() : 'AUW-SERVER-1') || 'AUW-SERVER-1';

        const roomMap = new Map();
        PRESET_SERVERS.forEach(s => {
            roomMap.set(s.id, {
                roomCode: s.id,
                label: s.label,
                activeCount: 0,
                status: 'WAITING'
            });
        });

        (liveRooms || []).forEach(r => {
            if (!r || !r.roomCode) return;
            const count = Math.max(0, Number(r.activeCount) || 0);
            if (count === 0 && !roomMap.has(r.roomCode)) return;
            const existing = roomMap.get(r.roomCode);
            roomMap.set(r.roomCode, {
                roomCode: r.roomCode,
                label: existing ? existing.label : 'Player Created Room',
                activeCount: count,
                status: r.status || 'WAITING'
            });
        });

        listEl.innerHTML = '';
        roomMap.forEach(srv => {
            const isChosen = srv.roomCode === selectedCode;
            const isReady = srv.activeCount >= MIN_PLAYERS_TO_START;
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = `p-2 rounded-xl border text-left transition flex items-center justify-between gap-2 ${
                isChosen
                    ? 'border-cyan-400 bg-cyan-950/80 shadow-[0_0_12px_rgba(34,211,238,0.3)]'
                    : 'border-slate-700 bg-slate-900/90 hover:border-cyan-400/60'
            }`;
            const statusBadge = srv.status === 'PLAYING'
                ? `<span class="px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-400 text-[9px] font-bold text-emerald-300">LIVE (${srv.activeCount})</span>`
                : (isReady
                    ? `<span class="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-400 text-[9px] font-bold text-cyan-200">${srv.activeCount}/10 READY</span>`
                    : `<span class="px-1.5 py-0.5 rounded bg-amber-950/80 border border-amber-400/70 text-[9px] font-bold text-amber-200">${srv.activeCount}/4 WAITING</span>`);

            btn.innerHTML = `
                <div class="truncate">
                    <div class="font-mono-code font-black text-[11px] text-white truncate">${srv.roomCode}</div>
                    <div class="text-[9px] text-slate-400 truncate">${srv.label}</div>
                </div>
                <div class="shrink-0">${statusBadge}</div>
            `;
            btn.onclick = () => {
                sfx.click();
                if (inp) inp.value = srv.roomCode;
                renderServerBrowser(liveRooms);
            };
            listEl.appendChild(btn);
        });
    }

    function updateLobbyUI(activeList, roomData) {
        lobbyPlayersList = activeList;
        onlineLobbyCount = activeList.length;

        const titleEl = document.getElementById('lobby-server-title');
        const shareEl = document.getElementById('lobby-share-code');
        const counterEl = document.getElementById('lobby-player-counter');
        const bannerEl = document.getElementById('lobby-status-banner');
        const headEl = document.getElementById('lobby-status-headline');
        const subEl = document.getElementById('lobby-status-sub');
        const launchBtn = document.getElementById('btn-launch-online-match');
        const gridEl = document.getElementById('lobby-players-grid');

        if (titleEl) titleEl.innerText = `ROOM CODE: ${currentRoom}`;
        if (shareEl) shareEl.innerText = currentRoom;
        if (counterEl) counterEl.innerText = `${activeList.length} / 10`;

        if (gridEl) {
            gridEl.innerHTML = activeList.map((p, idx) => `
                <div class="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-900 border ${p.uid === currentUser.uid ? 'border-cyan-400' : 'border-slate-700'} text-xs">
                    <div class="flex items-center gap-2 truncate">
                        <span class="w-3.5 h-3.5 rounded-full shrink-0 border border-white/40" style="background:${p.color}"></span>
                        <span class="font-bold text-white truncate">${p.flag || '🎓'} ${p.name} ${p.uid === currentUser.uid ? '(You)' : ''}</span>
                    </div>
                    <span class="text-[10px] font-orbitron font-bold text-emerald-400 shrink-0">#${idx + 1} HUMAN</span>
                </div>
            `).join('');
        }

        const needed = Math.max(0, MIN_PLAYERS_TO_START - activeList.length);
        if (needed > 0) {
            if (lobbyCountdownInterval) {
                clearInterval(lobbyCountdownInterval);
                lobbyCountdownInterval = null;
                lobbyCountdownValue = null;
            }
            if (bannerEl) bannerEl.className = 'mb-4 p-3.5 rounded-2xl border-2 border-amber-400 bg-amber-950/60 text-center';
            if (headEl) {
                headEl.className = 'font-orbitron font-black text-sm sm:text-base text-amber-200 animate-pulse';
                headEl.innerText = `⏳ WAITING FOR REAL PLAYERS: ${activeList.length} / ${MIN_PLAYERS_TO_START} MINIMUM JOINED`;
            }
            if (subEl) {
                subEl.innerHTML = `Waiting for <strong>${needed} more real player${needed > 1 ? 's' : ''}</strong> to enter Room Code <strong class="text-cyan-300 font-mono-code">${currentRoom}</strong>. (No bots in Online Mode)`;
            }
            if (launchBtn) {
                launchBtn.disabled = true;
                launchBtn.innerText = `⏳ WAITING FOR ${needed} MORE REAL PLAYER${needed > 1 ? 'S' : ''} (${activeList.length}/${MIN_PLAYERS_TO_START})...`;
            }
        } else {
            if (bannerEl) bannerEl.className = 'mb-4 p-3.5 rounded-2xl border-2 border-emerald-400 bg-emerald-950/70 text-center';
            if (launchBtn) {
                launchBtn.disabled = false;
                launchBtn.innerText = `🚀 START ONLINE MATCH NOW (${activeList.length} REAL PLAYERS) →`;
            }
            if (!lobbyCountdownInterval) {
                lobbyCountdownValue = 4;
                if (headEl) {
                    headEl.className = 'font-orbitron font-black text-sm sm:text-base text-emerald-300';
                    headEl.innerText = `✅ ${activeList.length} REAL PLAYERS CONNECTED! STARTING IN ${lobbyCountdownValue}s...`;
                }
                if (subEl) {
                    subEl.innerHTML = `Minimum 4 real players reached in Room <strong class="text-cyan-300 font-mono-code">${currentRoom}</strong>! Synchronizing all devices...`;
                }
                lobbyCountdownInterval = setInterval(() => {
                    lobbyCountdownValue--;
                    if (headEl && lobbyCountdownValue > 0) {
                        headEl.innerText = `✅ ${lobbyPlayersList.length} REAL PLAYERS CONNECTED! STARTING IN ${lobbyCountdownValue}s...`;
                    }
                    if (lobbyCountdownValue <= 0) {
                        clearInterval(lobbyCountdownInterval);
                        lobbyCountdownInterval = null;
                        window.mpBackend.launchOnlineMatchFromLobby();
                    }
                }, 1000);
            }
        }

        const lChat = (roomData && Array.isArray(roomData.lobbyChat)) ? roomData.lobbyChat : [];
        const chatBox = document.getElementById('lobby-chat-log');
        if (chatBox && lChat.length !== lastLobbyChatCount) {
            chatBox.innerHTML = lChat.length === 0
                ? `<div class="text-slate-400 italic">Room ${currentRoom} active. Share this Room Code with friends so 4+ real players can join!</div>`
                : lChat.map(m => `<div><strong style="color:${m.color}">${m.sender}:</strong> <span class="text-slate-200">${m.text}</span></div>`).join('');
            chatBox.scrollTop = chatBox.scrollHeight;
            lastLobbyChatCount = lChat.length;
        }
    }

    function enterSynchronizedOnlineGameplay(roomState) {
        if (lobbyCountdownInterval) {
            clearInterval(lobbyCountdownInterval);
            lobbyCountdownInterval = null;
        }
        document.getElementById('modal-online-lobby').classList.add('hidden');

        deadBodies = Array.isArray(roomState.deadBodies) ? roomState.deadBodies : [];
        sabotageLights = Boolean(roomState.sabotageLights);
        killCooldown = 8;
        sabotageCooldown = 10;
        disguiseCooldown = 5;
        disguiseTimer = 0;
        disguiseAppearance = null;
        campusScore = 0;
        roundElapsedTime = 0;
        nextRandomEventTimer = 32;
        lockdownTimer = 0;
        witnessReports = [];
        syncedPaId = (roomState.paAnnouncement && roomState.paAnnouncement.id) ? roomState.paAnnouncement.id : 0;
        activeMeetingState = null;

        weatherMode = 'CLOUDY';
        const weatherBadge = document.getElementById('hud-weather-badge');
        if (weatherBadge) weatherBadge.innerText = '☁️ OVERCAST';

        const completedIds = Array.isArray(roomState.completedTaskIds) ? roomState.completedTaskIds : [];
        TASKS.forEach(t => { t.completed = completedIds.includes(t.id); });
        CLUES.forEach(c => { c.found = false; });
        DOORS.forEach(d => { d.openAmount = 0; d.locked = false; });

        const impostorUid = roomState.impostorUid || '';
        const amImpostor = currentUser && impostorUid === currentUser.uid;
        const elimIds = Array.isArray(roomState.eliminatedIds) ? roomState.eliminatedIds : [];

        const spawnIndex = Math.max(0, lobbyPlayersList.findIndex(p => p.uid === currentUser.uid));
        const spawnX = 960 + (spawnIndex % 5) * 75;
        const spawnY = 330 + Math.floor(spawnIndex / 5) * 65;

        localPlayer = {
            id: currentUser.uid,
            uid: currentUser.uid,
            isRemoteHuman: false,
            name: pendingLocalProfile.name,
            flag: pendingLocalProfile.flag,
            color: pendingLocalProfile.color,
            charColor: pendingLocalProfile.charColor,
            dressColor: pendingLocalProfile.dressColor,
            accessory: pendingLocalProfile.accessory,
            isUser: true,
            isImpostor: amImpostor,
            isDead: elimIds.includes(currentUser.uid),
            x: spawnX,
            y: spawnY,
            facingRight: true,
            animState: 'idle',
            animTime: 0,
            celebrateTimer: 0
        };

        remotePlayersMap.clear();
        lobbyPlayersList.forEach(p => {
            if (p.uid === currentUser.uid) return;
            remotePlayersMap.set(p.uid, {
                id: p.uid,
                uid: p.uid,
                isRemoteHuman: true,
                isUser: false,
                name: p.name,
                flag: p.flag,
                color: p.color,
                charColor: p.charColor || CHAR_COLORS[0],
                dressColor: p.dressColor || DRESS_COLORS[0],
                accessory: p.accessory || 'none',
                isImpostor: p.uid === impostorUid,
                isDead: elimIds.includes(p.uid) || Boolean(p.isDead),
                x: typeof p.x === 'number' ? p.x : 1120,
                y: typeof p.y === 'number' ? p.y : 360,
                netTargetX: typeof p.x === 'number' ? p.x : 1120,
                netTargetY: typeof p.y === 'number' ? p.y : 360,
                facingRight: p.facingRight !== false,
                animState: p.animState || 'idle',
                animTime: Math.random() * 4
            });
        });

        rebuildPlayersRoster();

        document.getElementById('hud-player-profile').innerText = `${localPlayer.flag} ${localPlayer.name}`;
        const roleLbl = document.getElementById('hud-role-label');
        roleLbl.innerText = localPlayer.isImpostor ? 'IMPOSTOR' : 'CREWMATE';
        roleLbl.className = localPlayer.isImpostor ? 'text-red-400' : 'text-cyan-400';

        document.getElementById('btn-kill').classList.toggle('hidden', !localPlayer.isImpostor);
        document.getElementById('btn-vent').classList.toggle('hidden', !localPlayer.isImpostor);
        document.getElementById('btn-sabotage').classList.toggle('hidden', !localPlayer.isImpostor);
        document.getElementById('btn-disguise').classList.toggle('hidden', !localPlayer.isImpostor);

        updateTaskHUD();
        gameState = 'PLAYING';
        window.mpBackend.syncLocalPlayer(localPlayer);
        triggerPaAnnouncement(`🌐 ROOM [${currentRoom}] LIVE: ${players.length} real human players connected!`);
    }

    function rebuildPlayersRoster() {
        if (!localPlayer) return;
        const remotes = Array.from(remotePlayersMap.values());
        players = [localPlayer, ...remotes];
        const connBadge = document.getElementById('hud-connection-badge');
        if (connBadge && connectionMode === 'ONLINE' && currentRoom) {
            connBadge.innerText = `🌐 ${currentRoom} (${players.length} LIVE)`;
            connBadge.className = 'bg-cyan-950/90 border border-cyan-400/80 px-2.5 py-1.5 rounded-xl font-orbitron font-black text-[10px] text-cyan-200 shadow-lg';
        }
    }

    function renderSyncedMeeting(meeting) {
        if (!meeting || !meeting.active) return;

        if (gameState !== 'MEETING') {
            if (activeTask) closeTaskModal();
            sfx.alarm();
            gameState = 'MEETING';
            deadBodies = [];
            sabotageLights = false;
            lastChatCount = 0;

            document.getElementById('meeting-badge').innerText = meeting.reason || 'EMERGENCY MEETING';
            document.getElementById('meeting-result-banner').classList.add('hidden');
            document.getElementById('btn-skip-vote').disabled = localPlayer.isDead;
            document.getElementById('modal-meeting').classList.remove('hidden');

            const chatLog = document.getElementById('meeting-chat-log');
            chatLog.innerHTML = `<div class="text-amber-300 font-bold">System: Live Campus Emergency Meeting in ${currentRoom}! Discuss &amp; vote with your group.</div>`;

            if (onlineMeetingTimer) clearInterval(onlineMeetingTimer);
            onlineMeetingTimer = setInterval(() => {
                const elapsed = Math.floor((Date.now() - (meeting.startedAt || Date.now())) / 1000);
                const left = Math.max(0, 22 - elapsed);
                const timerEl = document.getElementById('meeting-timer');
                if (timerEl) timerEl.innerText = `${left}s`;
                if (left <= 0 && currentUser && currentRoom) {
                    clearInterval(onlineMeetingTimer);
                    resolveOnlineMeeting(meeting);
                }
            }, 500);
        }

        const grid = document.getElementById('meeting-players-grid');
        const votes = meeting.votes || {};
        const myVote = currentUser ? votes[currentUser.uid] : null;
        if (grid) {
            grid.innerHTML = '';
            players.forEach(p => {
                const targetKey = p.uid || String(p.id);
                const voteCount = Object.values(votes).filter(v => v === targetKey).length;
                const btn = document.createElement('button');
                btn.disabled = p.isDead || localPlayer.isDead || Boolean(myVote);
                btn.className = `flex items-center justify-between gap-2 p-2 rounded-xl border-2 text-left text-xs font-bold ${
                    p.isDead ? 'bg-slate-950 border-slate-800 opacity-40 line-through' :
                    (myVote === targetKey ? 'bg-amber-950/70 border-amber-400' : 'bg-slate-800 border-slate-600 hover:border-amber-400')
                }`;
                btn.innerHTML = `
                    <span class="flex items-center gap-1.5 truncate">
                        <span class="w-3.5 h-3.5 rounded-full inline-block shrink-0" style="background:${p.color}"></span>
                        <span class="truncate">${p.flag || ''} ${p.name}</span>
                    </span>
                    ${voteCount > 0 ? `<span class="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-black">${voteCount}</span>` : ''}
                `;
                btn.onclick = () => window.mpBackend.castOnlineVote(targetKey);
                grid.appendChild(btn);
            });
        }

        const chatArr = Array.isArray(meeting.chat) ? meeting.chat : [];
        if (chatArr.length > lastChatCount) {
            for (let i = lastChatCount; i < chatArr.length; i++) {
                const m = chatArr[i];
                appendChat(m.sender, m.color, m.text);
            }
            lastChatCount = chatArr.length;
        }

        const aliveOnlineUids = players.filter(p => !p.isDead && p.uid).map(p => p.uid);
        const allVoted = aliveOnlineUids.length > 0 && aliveOnlineUids.every(uid => Boolean(votes[uid]));
        if (allVoted) {
            resolveOnlineMeeting(meeting);
        }
    }

    async function resolveOnlineMeeting(meeting) {
        if (!currentUser || !currentRoom || !meeting || !meeting.active) return;
        if (onlineMeetingTimer) clearInterval(onlineMeetingTimer);

        const votes = meeting.votes || {};
        const tally = {};
        Object.values(votes).forEach(v => {
            if (v && v !== 'SKIP') tally[v] = (tally[v] || 0) + 1;
        });

        let topTarget = null;
        let maxVotes = 0;
        Object.entries(tally).forEach(([id, count]) => {
            if (count > maxVotes) {
                maxVotes = count;
                topTarget = id;
            }
        });

        const banner = document.getElementById('meeting-result-banner');
        if (banner) {
            banner.classList.remove('hidden');
            if (topTarget && maxVotes >= 1) {
                const ejected = players.find(p => (p.uid || String(p.id)) === topTarget);
                if (ejected) {
                    ejected.isDead = true;
                    banner.innerText = `${ejected.name} was ejected! (${ejected.isImpostor ? 'WAS THE DISGUISED INTRUDER!' : 'Was NOT the Intruder.'})`;
                } else {
                    banner.innerText = 'Suspect ejected from campus!';
                }
            } else {
                banner.innerText = 'No one was ejected (Skipped / Tie).';
            }
        }

        if (db && fsApi) {
            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                const snapData = snap.exists() ? snap.data() : null;
                if (snapData && snapData.meeting && snapData.meeting.active) {
                    const prevElims = Array.isArray(snapData.eliminatedIds) ? snapData.eliminatedIds : [];
                    const nextElims = (topTarget && maxVotes >= 1 && !prevElims.includes(topTarget))
                        ? [...prevElims, topTarget]
                        : prevElims;
                    await fsApi.updateDoc(roomRef, {
                        meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                        deadBodies: [],
                        sabotageLights: false,
                        eliminatedIds: nextElims,
                        updatedAt: Date.now()
                    });
                }
            } catch (e) {}
        } else {
            mqttCloudRelay.finishMeeting(topTarget && maxVotes >= 1 ? topTarget : null);
        }

        setTimeout(() => {
            document.getElementById('modal-meeting').classList.add('hidden');
            if (gameState === 'MEETING') gameState = 'PLAYING';
            if (localPlayer && localPlayer.isDead) {
                endGame('EJECTED FROM CAMPUS!', 'The campus emergency vote ejected you from AUW!', '🚨', 'text-red-500');
            } else {
                checkWinConditions();
            }
        }, 2400);
    }

    /* ======================================================================
       PUBLIC INTERNET CLOUD BROKER (WSS + RETAINED STATE FOR STANDALONE USE)
       ====================================================================== */
    const mqttCloudRelay = {
        client: null,
        connected: false,
        prefix: 'auw_campus_cloud_v4',
        playersMap: new Map(),
        directoryMap: new Map(),
        roomMeta: null,
        activeRoomSub: null,

        async loadMqttLib() {
            if (window.mqtt) return true;
            const urls = [
                'https://unpkg.com/mqtt@5.10.1/dist/mqtt.min.js',
                'https://cdn.jsdelivr.net/npm/mqtt@5.10.1/dist/mqtt.min.js'
            ];
            for (const src of urls) {
                const loaded = await new Promise(resolve => {
                    const s = document.createElement('script');
                    s.src = src;
                    s.onload = () => resolve(true);
                    s.onerror = () => resolve(false);
                    document.head.appendChild(s);
                });
                if (loaded && window.mqtt) return true;
            }
            return false;
        },

        async connectBroker(willTopic) {
            const ok = await this.loadMqttLib();
            if (!ok) return false;

            if (this.client && this.connected) return true;
            if (this.client) {
                try { this.client.end(true); } catch (e) {}
                this.client = null;
                this.connected = false;
            }

            const brokers = [
                'wss://broker.hivemq.com:8884/mqtt',
                'wss://broker.emqx.io:8084/mqtt'
            ];

            for (const url of brokers) {
                const success = await new Promise(resolve => {
                    let settled = false;
                    const opts = {
                        clientId: 'auw_' + Math.random().toString(36).slice(2, 10) + '_' + Date.now().toString(36),
                        clean: true,
                        connectTimeout: 5500,
                        reconnectPeriod: 2000
                    };
                    if (willTopic) {
                        opts.will = { topic: willTopic, payload: '', qos: 1, retain: true };
                    }
                    const c = window.mqtt.connect(url, opts);
                    const timer = setTimeout(() => {
                        if (!settled) {
                            settled = true;
                            try { c.end(true); } catch (e) {}
                            resolve(false);
                        }
                    }, 6000);

                    c.on('connect', () => {
                        if (!settled) {
                            settled = true;
                            clearTimeout(timer);
                            this.client = c;
                            this.connected = true;
                            this.attachHandlers(c);
                            resolve(true);
                        }
                    });
                    c.on('error', () => {
                        if (!settled) {
                            settled = true;
                            clearTimeout(timer);
                            try { c.end(true); } catch (e) {}
                            resolve(false);
                        }
                    });
                });
                if (success) return true;
            }
            return false;
        },

        attachHandlers(c) {
            c.on('message', (topic, message) => {
                const raw = message ? message.toString() : '';
                if (topic.startsWith(`${this.prefix}/directory/`)) {
                    const code = topic.split('/').pop();
                    if (!raw) {
                        this.directoryMap.delete(code);
                    } else {
                        try { this.directoryMap.set(code, JSON.parse(raw)); } catch (e) {}
                    }
                    renderServerBrowser(Array.from(this.directoryMap.values()));
                    return;
                }

                if (!currentRoom) return;
                const metaTopic = `${this.prefix}/rooms/${currentRoom}/meta`;
                const playersPrefix = `${this.prefix}/rooms/${currentRoom}/players/`;

                if (topic === metaTopic && raw) {
                    try {
                        this.roomMeta = JSON.parse(raw);
                        currentRoomData = this.roomMeta;
                        this.handleRoomStateUpdate(this.roomMeta);
                    } catch (e) {}
                    return;
                }

                if (topic.startsWith(playersPrefix)) {
                    const pUid = topic.slice(playersPrefix.length);
                    if (!raw) {
                        this.playersMap.delete(pUid);
                    } else {
                        try {
                            const pData = JSON.parse(raw);
                            this.playersMap.set(pUid, pData);
                            localReceiptMap.set(pUid, Date.now());
                        } catch (e) {}
                    }
                    this.handlePlayersUpdate();
                }
            });

            c.on('offline', () => {
                const banner = document.getElementById('lobby-error-banner');
                if (banner && gameState === 'ONLINE_LOBBY') {
                    banner.innerText = '⚠️ Connection interrupted — reconnecting to cloud server...';
                    banner.classList.remove('hidden');
                }
            });
            c.on('connect', () => {
                const banner = document.getElementById('lobby-error-banner');
                if (banner) banner.classList.add('hidden');
            });
        },

        async ensureAuth() {
            if (!currentUser) {
                currentUser = { uid: 'auw-' + Math.random().toString(36).slice(2, 10) };
            }
            const ok = await this.connectBroker(null);
            return ok ? currentUser.uid : null;
        },

        watchDirectory() {
            if (!this.client || !this.connected) return;
            this.client.subscribe(`${this.prefix}/directory/+`, { qos: 1 });
        },

        publishMeta(metaObj) {
            if (!this.client || !this.connected || !currentRoom) return;
            this.roomMeta = metaObj;
            currentRoomData = metaObj;
            this.client.publish(`${this.prefix}/rooms/${currentRoom}/meta`, JSON.stringify(metaObj), { qos: 1, retain: true });
            this.client.publish(`${this.prefix}/directory/${currentRoom}`, JSON.stringify({
                roomCode: currentRoom,
                status: metaObj.status,
                activeCount: this.playersMap.size
            }), { qos: 1, retain: true });
        },

        publishPlayer(playerObj) {
            if (!this.client || !this.connected || !currentRoom || !currentUser) return;
            this.playersMap.set(currentUser.uid, playerObj);
            this.client.publish(`${this.prefix}/rooms/${currentRoom}/players/${currentUser.uid}`, JSON.stringify(playerObj), { qos: 1, retain: true });
        },

        async joinRoom(roomCode, profile, createNew) {
            if (!currentUser) {
                currentUser = { uid: 'auw-' + Math.random().toString(36).slice(2, 10) };
            }
            const willTopic = `${this.prefix}/rooms/${roomCode}/players/${currentUser.uid}`;
            const connected = await this.connectBroker(willTopic);
            if (!connected) {
                return { ok: false, error: '❌ Unable to reach the public online server. Check your internet connection and retry.' };
            }

            if (this.activeRoomSub) {
                try { this.client.unsubscribe(this.activeRoomSub); } catch (e) {}
            }
            this.playersMap.clear();
            this.roomMeta = null;
            currentRoom = roomCode;
            pendingLocalProfile = profile;

            const subPattern = `${this.prefix}/rooms/${roomCode}/#`;
            this.activeRoomSub = subPattern;
            this.client.subscribe(subPattern, { qos: 1 });

            await new Promise(r => setTimeout(r, 950));

            const isPreset = PRESET_IDS.has(roomCode);
            if (!createNew && !isPreset && (!this.roomMeta || this.roomMeta.status === 'GAMEOVER')) {
                try { this.client.unsubscribe(subPattern); } catch (e) {}
                currentRoom = null;
                return { ok: false, error: `❌ Room "${roomCode}" not found on server. Ask the host to click CREATE NEW ROOM first!` };
            }

            const now = Date.now();
            const shouldInitMeta = createNew || !this.roomMeta || this.roomMeta.status === 'GAMEOVER' || this.playersMap.size === 0;
            if (shouldInitMeta) {
                this.publishMeta({
                    roomCode,
                    status: 'WAITING',
                    activeCount: 1,
                    impostorUid: '',
                    sabotageLights: false,
                    completedTaskIds: [],
                    deadBodies: [],
                    eliminatedIds: [],
                    gameOver: null,
                    meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                    lobbyChat: [],
                    paAnnouncement: { text: '', id: 0 },
                    updatedAt: now
                });
            }

            const initialPlayer = {
                uid: currentUser.uid,
                roomCode,
                name: profile.name,
                flag: profile.flag,
                color: profile.color,
                charColor: profile.charColor,
                dressColor: profile.dressColor,
                accessory: profile.accessory,
                preferredRole: profile.preferredRole || 'CREWMATE',
                isImpostor: false,
                isDead: false,
                x: 1120,
                y: 360,
                facingRight: true,
                animState: 'idle',
                joinedAt: now,
                heartbeatSeq: 1
            };
            this.publishPlayer(initialPlayer);
            this.handlePlayersUpdate();

            heartbeatInterval = setInterval(() => {
                if (!currentUser || !currentRoom || !this.connected) return;
                myHeartbeatSeq++;
                const cur = this.playersMap.get(currentUser.uid);
                if (cur) {
                    cur.heartbeatSeq = myHeartbeatSeq;
                    this.publishPlayer(cur);
                }
            }, 3000);

            return { ok: true };
        },

        handlePlayersUpdate() {
            const now = Date.now();
            const active = [];
            const seen = new Set();

            this.playersMap.forEach((data, uid) => {
                if (!data || !uid) return;
                const age = now - (localReceiptMap.get(uid) || now);
                if (uid !== currentUser.uid && age > 25000) return;
                active.push(data);
                seen.add(uid);

                if (gameState === 'PLAYING' && uid !== currentUser.uid) {
                    let remote = remotePlayersMap.get(uid);
                    if (!remote) {
                        const impUid = this.roomMeta ? this.roomMeta.impostorUid : '';
                        remote = {
                            id: uid,
                            uid,
                            isRemoteHuman: true,
                            isUser: false,
                            isImpostor: uid === impUid,
                            x: typeof data.x === 'number' ? data.x : 1120,
                            y: typeof data.y === 'number' ? data.y : 360,
                            netTargetX: typeof data.x === 'number' ? data.x : 1120,
                            netTargetY: typeof data.y === 'number' ? data.y : 360,
                            animTime: Math.random() * 5
                        };
                        remotePlayersMap.set(uid, remote);
                    }
                    const look = data.disguiseAppearance ? data.disguiseAppearance : data;
                    remote.name = look.name || data.name || 'Student';
                    remote.flag = look.flag || data.flag || '🎓';
                    remote.color = look.color || data.color || '#38bdf8';
                    remote.charColor = look.charColor || data.charColor || CHAR_COLORS[0];
                    remote.dressColor = look.dressColor || data.dressColor || DRESS_COLORS[0];
                    remote.accessory = look.accessory || data.accessory || 'none';
                    remote.isDead = Boolean(data.isDead);
                    remote.netTargetX = typeof data.x === 'number' ? data.x : remote.x;
                    remote.netTargetY = typeof data.y === 'number' ? data.y : remote.y;
                    remote.facingRight = data.facingRight !== false;
                    remote.animState = data.animState || 'idle';
                }
            });

            active.sort((a, b) => (a.joinedAt || 0) - (b.joinedAt || 0));

            if (gameState === 'ONLINE_LOBBY') {
                updateLobbyUI(active, this.roomMeta);
                if (this.client && this.connected && currentRoom) {
                    this.client.publish(`${this.prefix}/directory/${currentRoom}`, JSON.stringify({
                        roomCode: currentRoom,
                        status: this.roomMeta ? this.roomMeta.status : 'WAITING',
                        activeCount: active.length
                    }), { qos: 1, retain: true });
                }
            } else if (gameState === 'PLAYING') {
                for (const k of remotePlayersMap.keys()) {
                    if (!seen.has(k)) remotePlayersMap.delete(k);
                }
                rebuildPlayersRoster();
            }
        },

        handleRoomStateUpdate(state) {
            if (!state) return;
            if (gameState === 'ONLINE_LOBBY') {
                updateLobbyUI(lobbyPlayersList, state);
                if (state.status === 'PLAYING' && lobbyPlayersList.length >= MIN_PLAYERS_TO_START) {
                    enterSynchronizedOnlineGameplay(state);
                }
                return;
            }

            if (state.gameOver && state.gameOver.active && gameState !== 'GAMEOVER') {
                endGame(state.gameOver.title, state.gameOver.desc, state.gameOver.emoji, state.gameOver.colorClass);
                return;
            }
            if (typeof state.sabotageLights === 'boolean' && state.sabotageLights !== sabotageLights) {
                sabotageLights = state.sabotageLights;
                if (sabotageLights) sfx.alarm();
            }
            if (Array.isArray(state.completedTaskIds)) {
                let anyNew = false;
                state.completedTaskIds.forEach(tid => {
                    const t = TASKS.find(item => item.id === tid);
                    if (t && !t.completed) { t.completed = true; anyNew = true; }
                });
                if (anyNew) updateTaskHUD();
            }
            if (Array.isArray(state.deadBodies)) deadBodies = state.deadBodies;
            if (Array.isArray(state.eliminatedIds) && state.eliminatedIds.includes(currentUser.uid) && localPlayer && !localPlayer.isDead) {
                localPlayer.isDead = true;
                endGame('ELIMINATED BY INTRUDER!', 'The disguised Impostor caught you on the AUW campus!', '💀', 'text-red-500');
            }
            if (state.paAnnouncement && state.paAnnouncement.id && state.paAnnouncement.id !== syncedPaId) {
                syncedPaId = state.paAnnouncement.id;
                if (state.paAnnouncement.text) triggerPaAnnouncement(state.paAnnouncement.text);
            }
            if (state.meeting && state.meeting.active) {
                activeMeetingState = state.meeting;
                renderSyncedMeeting(state.meeting);
            } else if (activeMeetingState && activeMeetingState.active) {
                activeMeetingState = null;
                if (onlineMeetingTimer) clearInterval(onlineMeetingTimer);
                document.getElementById('modal-meeting').classList.add('hidden');
                if (gameState === 'MEETING') gameState = 'PLAYING';
            }
        },

        finishMeeting(ejectedUid) {
            if (!this.roomMeta) return;
            const prevElims = Array.isArray(this.roomMeta.eliminatedIds) ? this.roomMeta.eliminatedIds : [];
            const nextElims = ejectedUid && !prevElims.includes(ejectedUid) ? [...prevElims, ejectedUid] : prevElims;
            this.publishMeta({
                ...this.roomMeta,
                meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                deadBodies: [],
                sabotageLights: false,
                eliminatedIds: nextElims,
                updatedAt: Date.now()
            });
        },

        leaveRoom() {
            if (this.client && this.connected && currentRoom && currentUser) {
                this.client.publish(`${this.prefix}/rooms/${currentRoom}/players/${currentUser.uid}`, '', { qos: 1, retain: true });
                const remaining = Math.max(0, this.playersMap.size - 1);
                this.client.publish(`${this.prefix}/directory/${currentRoom}`, remaining === 0 ? '' : JSON.stringify({
                    roomCode: currentRoom,
                    status: this.roomMeta ? this.roomMeta.status : 'WAITING',
                    activeCount: remaining
                }), { qos: 1, retain: true });
            }
            if (this.activeRoomSub && this.client) {
                try { this.client.unsubscribe(this.activeRoomSub); } catch (e) {}
                this.activeRoomSub = null;
            }
            this.playersMap.clear();
            this.roomMeta = null;
        }
    };

    window.mpBackend = {
        available: true,
        ensureAuth,
        renderServerBrowser,

        selectServerFromList(code) {
            const inp = document.getElementById('online-room-code');
            if (inp) inp.value = code;
            this.watchServerList();
        },

        watchServerList() {
            if (!db || !fsApi) {
                mqttCloudRelay.watchDirectory();
                return;
            }
            if (!currentUser) {
                renderServerBrowser([]);
                return;
            }
            if (unsubServerBrowser) {
                unsubServerBrowser();
                unsubServerBrowser = null;
            }
            unsubServerBrowser = fsApi.onSnapshot(getRoomsColRef(), snapshot => {
                const list = [];
                snapshot.forEach(docSnap => {
                    list.push(docSnap.data());
                });
                renderServerBrowser(list);
            }, err => {
                console.error('Server browser listener error:', err);
            });
        },

        async joinServerLobby(roomCode, profile, opts = {}) {
            const createNew = Boolean(opts && opts.createNew);
            const uid = await ensureAuth();
            if (!uid) {
                return { ok: false, error: '❌ Online authentication failed. Please check your internet connection.' };
            }

            if (unsubRoom) { unsubRoom(); unsubRoom = null; }
            if (unsubPlayers) { unsubPlayers(); unsubPlayers = null; }
            if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null; }

            currentRoom = roomCode;
            pendingLocalProfile = profile;
            remotePlayersMap.clear();
            localReceiptMap.clear();
            lastSeenSeqMap.clear();
            lobbyPlayersList = [];
            lastLobbyChatCount = 0;
            myHeartbeatSeq = 1;

            if (!db || !fsApi) {
                return await mqttCloudRelay.joinRoom(roomCode, profile, createNew);
            }

            const roomRef = getRoomDocRef(roomCode);
            const myPlayerRef = getPlayerDocRef(roomCode, uid);
            const now = Date.now();
            const isPreset = PRESET_IDS.has(roomCode);

            try {
                const roomSnap = await fsApi.getDoc(roomRef);
                const existing = roomSnap.exists() ? roomSnap.data() : null;

                if (!createNew && !isPreset && (!existing || existing.status === 'GAMEOVER')) {
                    currentRoom = null;
                    return { ok: false, error: `❌ Room "${roomCode}" was not found on the server. Ask the host to click CREATE NEW ROOM first!` };
                }

                const shouldResetRoom = createNew || !existing || existing.status === 'GAMEOVER' || (Number(existing.activeCount) || 0) <= 0;
                if (shouldResetRoom) {
                    await fsApi.setDoc(roomRef, {
                        roomCode,
                        status: 'WAITING',
                        activeCount: 1,
                        impostorUid: '',
                        sabotageLights: false,
                        completedTaskIds: [],
                        deadBodies: [],
                        eliminatedIds: [],
                        gameOver: null,
                        meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                        lobbyChat: [],
                        paAnnouncement: { text: '', id: 0 },
                        updatedAt: now
                    });
                }

                await fsApi.setDoc(myPlayerRef, {
                    uid,
                    roomCode,
                    name: profile.name,
                    flag: profile.flag,
                    color: profile.color,
                    charColor: profile.charColor,
                    dressColor: profile.dressColor,
                    accessory: profile.accessory,
                    preferredRole: profile.preferredRole || 'CREWMATE',
                    isImpostor: false,
                    isDead: false,
                    x: 1120,
                    y: 360,
                    facingRight: true,
                    animState: 'idle',
                    joinedAt: now,
                    heartbeatSeq: myHeartbeatSeq
                });
            } catch (e) {
                console.error('Join room error:', e);
                currentRoom = null;
                return { ok: false, error: `❌ Server connection error: ${e.message || 'Unable to register in room.'}` };
            }

            heartbeatInterval = setInterval(async () => {
                if (!db || !fsApi || !currentUser || !currentRoom) return;
                myHeartbeatSeq++;
                try {
                    await fsApi.updateDoc(getPlayerDocRef(currentRoom, currentUser.uid), {
                        heartbeatSeq: myHeartbeatSeq
                    });
                } catch (e) {}
            }, 2500);

            unsubPlayers = fsApi.onSnapshot(getPlayersColRef(roomCode), async snapshot => {
                const localNow = Date.now();
                const active = [];
                const seenUids = new Set();

                snapshot.forEach(docSnap => {
                    const data = docSnap.data();
                    if (!data || !data.uid) return;

                    const prevSeq = lastSeenSeqMap.get(data.uid);
                    const curSeq = data.heartbeatSeq || 0;
                    if (prevSeq !== curSeq || !localReceiptMap.has(data.uid)) {
                        lastSeenSeqMap.set(data.uid, curSeq);
                        localReceiptMap.set(data.uid, localNow);
                    }

                    const ageMs = localNow - (localReceiptMap.get(data.uid) || localNow);
                    if (data.uid !== uid && ageMs > 25000) return;

                    active.push(data);
                    seenUids.add(data.uid);

                    if (gameState === 'PLAYING' && data.uid !== uid) {
                        let remote = remotePlayersMap.get(data.uid);
                        if (!remote) {
                            const impUid = currentRoomData ? currentRoomData.impostorUid : '';
                            remote = {
                                id: data.uid,
                                uid: data.uid,
                                isRemoteHuman: true,
                                isUser: false,
                                isImpostor: data.uid === impUid,
                                x: typeof data.x === 'number' ? data.x : 1120,
                                y: typeof data.y === 'number' ? data.y : 360,
                                netTargetX: typeof data.x === 'number' ? data.x : 1120,
                                netTargetY: typeof data.y === 'number' ? data.y : 360,
                                animTime: Math.random() * 5
                            };
                            remotePlayersMap.set(data.uid, remote);
                        }
                        const look = data.disguiseAppearance ? data.disguiseAppearance : data;
                        remote.name = look.name || data.name || 'Student';
                        remote.flag = look.flag || data.flag || '🎓';
                        remote.color = look.color || data.color || '#38bdf8';
                        remote.charColor = look.charColor || data.charColor || CHAR_COLORS[0];
                        remote.dressColor = look.dressColor || data.dressColor || DRESS_COLORS[0];
                        remote.accessory = look.accessory || data.accessory || 'none';
                        remote.isDead = Boolean(data.isDead);
                        remote.netTargetX = typeof data.x === 'number' ? data.x : remote.x;
                        remote.netTargetY = typeof data.y === 'number' ? data.y : remote.y;
                        remote.facingRight = data.facingRight !== false;
                        remote.animState = data.animState || 'idle';
                    }
                });

                active.sort((a, b) => (a.joinedAt || 0) - (b.joinedAt || 0));

                if (gameState === 'ONLINE_LOBBY') {
                    updateLobbyUI(active, currentRoomData);
                    try {
                        await fsApi.updateDoc(roomRef, {
                            activeCount: active.length,
                            updatedAt: Date.now()
                        });
                    } catch (e) {}
                } else if (gameState === 'PLAYING') {
                    for (const key of remotePlayersMap.keys()) {
                        if (!seenUids.has(key)) remotePlayersMap.delete(key);
                    }
                    rebuildPlayersRoster();
                }
            }, err => {
                console.error('Server players sync error:', err);
            });

            unsubRoom = fsApi.onSnapshot(roomRef, docSnap => {
                if (!docSnap.exists()) return;
                const state = docSnap.data();
                currentRoomData = state;

                if (gameState === 'ONLINE_LOBBY') {
                    updateLobbyUI(lobbyPlayersList, state);
                    if (state.status === 'PLAYING' && lobbyPlayersList.length >= MIN_PLAYERS_TO_START) {
                        enterSynchronizedOnlineGameplay(state);
                    }
                    return;
                }

                if (state.gameOver && state.gameOver.active && gameState !== 'GAMEOVER') {
                    endGame(state.gameOver.title, state.gameOver.desc, state.gameOver.emoji, state.gameOver.colorClass);
                    return;
                }

                if (typeof state.sabotageLights === 'boolean' && state.sabotageLights !== sabotageLights) {
                    sabotageLights = state.sabotageLights;
                    if (sabotageLights) sfx.alarm();
                }

                if (Array.isArray(state.completedTaskIds)) {
                    let anyNew = false;
                    state.completedTaskIds.forEach(tid => {
                        const t = TASKS.find(item => item.id === tid);
                        if (t && !t.completed) {
                            t.completed = true;
                            anyNew = true;
                        }
                    });
                    if (anyNew) updateTaskHUD();
                }

                if (Array.isArray(state.deadBodies)) {
                    deadBodies = state.deadBodies;
                }

                if (Array.isArray(state.eliminatedIds) && state.eliminatedIds.includes(uid) && localPlayer && !localPlayer.isDead) {
                    localPlayer.isDead = true;
                    endGame('ELIMINATED BY INTRUDER!', 'The disguised Impostor caught you on the AUW campus!', '💀', 'text-red-500');
                }

                if (state.paAnnouncement && state.paAnnouncement.id && state.paAnnouncement.id !== syncedPaId) {
                    syncedPaId = state.paAnnouncement.id;
                    if (state.paAnnouncement.text) triggerPaAnnouncement(state.paAnnouncement.text);
                }

                if (state.meeting && state.meeting.active) {
                    activeMeetingState = state.meeting;
                    renderSyncedMeeting(state.meeting);
                } else if (activeMeetingState && activeMeetingState.active) {
                    activeMeetingState = null;
                    if (onlineMeetingTimer) clearInterval(onlineMeetingTimer);
                    document.getElementById('modal-meeting').classList.add('hidden');
                    if (gameState === 'MEETING') gameState = 'PLAYING';
                }
            }, err => {
                console.error('Server room sync error:', err);
            });

            return { ok: true };
        },

        async launchOnlineMatchFromLobby() {
            if (!currentUser || !currentRoom) return;
            if (lobbyPlayersList.length < MIN_PLAYERS_TO_START) return;

            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta || mqttCloudRelay.roomMeta.status === 'PLAYING') return;
                const impCandidates = lobbyPlayersList.filter(p => p.preferredRole === 'IMPOSTOR');
                const chosenImp = impCandidates.length > 0
                    ? impCandidates[Math.floor(Math.random() * impCandidates.length)]
                    : lobbyPlayersList[Math.floor(Math.random() * lobbyPlayersList.length)];
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    status: 'PLAYING',
                    activeCount: lobbyPlayersList.length,
                    impostorUid: chosenImp.uid,
                    sabotageLights: false,
                    completedTaskIds: [],
                    deadBodies: [],
                    eliminatedIds: [],
                    gameOver: null,
                    meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                    updatedAt: Date.now()
                });
                return;
            }

            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                const data = snap.exists() ? snap.data() : null;
                if (data && data.status === 'PLAYING') {
                    enterSynchronizedOnlineGameplay(data);
                    return;
                }

                const impCandidates = lobbyPlayersList.filter(p => p.preferredRole === 'IMPOSTOR');
                const chosenImp = impCandidates.length > 0
                    ? impCandidates[Math.floor(Math.random() * impCandidates.length)]
                    : lobbyPlayersList[Math.floor(Math.random() * lobbyPlayersList.length)];

                await fsApi.updateDoc(roomRef, {
                    status: 'PLAYING',
                    activeCount: lobbyPlayersList.length,
                    impostorUid: chosenImp.uid,
                    sabotageLights: false,
                    completedTaskIds: [],
                    deadBodies: [],
                    eliminatedIds: [],
                    gameOver: null,
                    meeting: { active: false, reason: '', startedAt: 0, votes: {}, chat: [] },
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async sendLobbyChat(sender, color, text) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                const prev = Array.isArray(mqttCloudRelay.roomMeta.lobbyChat) ? mqttCloudRelay.roomMeta.lobbyChat : [];
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    lobbyChat: [...prev.slice(-25), { sender, color, text, ts: Date.now() }],
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                if (!snap.exists()) return;
                const prev = Array.isArray(snap.data().lobbyChat) ? snap.data().lobbyChat : [];
                await fsApi.updateDoc(roomRef, {
                    lobbyChat: [...prev.slice(-25), { sender, color, text, ts: Date.now() }],
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async syncLocalPlayer(playerObj) {
            if (!currentUser || !currentRoom || !playerObj) return;
            myHeartbeatSeq++;
            const existing = (!db || !fsApi) ? mqttCloudRelay.playersMap.get(currentUser.uid) : null;
            const payload = {
                uid: currentUser.uid,
                roomCode: currentRoom,
                name: playerObj.name,
                flag: playerObj.flag,
                color: playerObj.color,
                charColor: playerObj.charColor,
                dressColor: playerObj.dressColor,
                accessory: playerObj.accessory,
                isImpostor: playerObj.isImpostor,
                isDead: playerObj.isDead,
                x: Math.round(playerObj.x),
                y: Math.round(playerObj.y),
                facingRight: playerObj.facingRight,
                animState: playerObj.animState,
                disguiseAppearance: (typeof disguiseTimer !== 'undefined' && disguiseTimer > 0) ? disguiseAppearance : null,
                joinedAt: (existing && existing.joinedAt) ? existing.joinedAt : Date.now(),
                heartbeatSeq: myHeartbeatSeq
            };
            if (!db || !fsApi) {
                mqttCloudRelay.publishPlayer(payload);
                return;
            }
            try {
                await fsApi.setDoc(getPlayerDocRef(currentRoom, currentUser.uid), payload, { merge: true });
            } catch (e) {}
        },

        async syncTaskCompleted(taskObj) {
            if (!currentUser || !currentRoom) return;
            const annText = `✅ ${localPlayer.flag} ${localPlayer.name} completed ${taskObj.roomName}: ${taskObj.title}!`;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                const prev = Array.isArray(mqttCloudRelay.roomMeta.completedTaskIds) ? mqttCloudRelay.roomMeta.completedTaskIds : [];
                if (!prev.includes(taskObj.id)) {
                    mqttCloudRelay.publishMeta({
                        ...mqttCloudRelay.roomMeta,
                        completedTaskIds: [...prev, taskObj.id],
                        paAnnouncement: { id: Date.now(), text: annText },
                        updatedAt: Date.now()
                    });
                }
                return;
            }
            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                if (!snap.exists()) return;
                const prev = Array.isArray(snap.data().completedTaskIds) ? snap.data().completedTaskIds : [];
                if (!prev.includes(taskObj.id)) {
                    await fsApi.updateDoc(roomRef, {
                        completedTaskIds: [...prev, taskObj.id],
                        paAnnouncement: { id: Date.now(), text: annText },
                        updatedAt: Date.now()
                    });
                }
            } catch (e) {}
        },

        async syncSabotage(lightsOut, announcementText) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    sabotageLights: Boolean(lightsOut),
                    paAnnouncement: { id: Date.now(), text: announcementText },
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                await fsApi.updateDoc(getRoomDocRef(currentRoom), {
                    sabotageLights: Boolean(lightsOut),
                    paAnnouncement: { id: Date.now(), text: announcementText },
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async syncElimination(bodyObj, victimUid) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                const prevBodies = Array.isArray(mqttCloudRelay.roomMeta.deadBodies) ? mqttCloudRelay.roomMeta.deadBodies : [];
                const prevElims = Array.isArray(mqttCloudRelay.roomMeta.eliminatedIds) ? mqttCloudRelay.roomMeta.eliminatedIds : [];
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    deadBodies: [...prevBodies, bodyObj],
                    eliminatedIds: victimUid && !prevElims.includes(victimUid) ? [...prevElims, victimUid] : prevElims,
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                if (!snap.exists()) return;
                const prevBodies = Array.isArray(snap.data().deadBodies) ? snap.data().deadBodies : [];
                const prevElims = Array.isArray(snap.data().eliminatedIds) ? snap.data().eliminatedIds : [];
                await fsApi.updateDoc(roomRef, {
                    deadBodies: [...prevBodies, bodyObj],
                    eliminatedIds: victimUid && !prevElims.includes(victimUid) ? [...prevElims, victimUid] : prevElims,
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async startOnlineMeeting(reason) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    sabotageLights: false,
                    deadBodies: [],
                    meeting: { active: true, reason, startedAt: Date.now(), votes: {}, chat: [] },
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                await fsApi.updateDoc(getRoomDocRef(currentRoom), {
                    sabotageLights: false,
                    deadBodies: [],
                    meeting: {
                        active: true,
                        reason,
                        startedAt: Date.now(),
                        votes: {},
                        chat: []
                    },
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async sendOnlineChat(sender, color, text) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta || !mqttCloudRelay.roomMeta.meeting || !mqttCloudRelay.roomMeta.meeting.active) return;
                const prevChat = Array.isArray(mqttCloudRelay.roomMeta.meeting.chat) ? mqttCloudRelay.roomMeta.meeting.chat : [];
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    meeting: {
                        ...mqttCloudRelay.roomMeta.meeting,
                        chat: [...prevChat, { sender, color, text, ts: Date.now() }]
                    },
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                const roomRef = getRoomDocRef(currentRoom);
                const snap = await fsApi.getDoc(roomRef);
                const snapData = snap.exists() ? snap.data() : null;
                if (!snapData || !snapData.meeting || !snapData.meeting.active) return;
                const prevChat = Array.isArray(snapData.meeting.chat) ? snapData.meeting.chat : [];
                await fsApi.updateDoc(roomRef, {
                    'meeting.chat': [...prevChat, { sender, color, text, ts: Date.now() }],
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async castOnlineVote(targetId) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta || !mqttCloudRelay.roomMeta.meeting || !mqttCloudRelay.roomMeta.meeting.active) return;
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    meeting: {
                        ...mqttCloudRelay.roomMeta.meeting,
                        votes: { ...(mqttCloudRelay.roomMeta.meeting.votes || {}), [currentUser.uid]: targetId }
                    },
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                await fsApi.updateDoc(getRoomDocRef(currentRoom), {
                    [`meeting.votes.${currentUser.uid}`]: targetId,
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async syncGameOver(title, desc, emoji, colorClass) {
            if (!currentUser || !currentRoom) return;
            if (!db || !fsApi) {
                if (!mqttCloudRelay.roomMeta) return;
                mqttCloudRelay.publishMeta({
                    ...mqttCloudRelay.roomMeta,
                    status: 'GAMEOVER',
                    gameOver: { active: true, title, desc, emoji, colorClass },
                    updatedAt: Date.now()
                });
                return;
            }
            try {
                await fsApi.updateDoc(getRoomDocRef(currentRoom), {
                    status: 'GAMEOVER',
                    gameOver: { active: true, title, desc, emoji, colorClass },
                    updatedAt: Date.now()
                });
            } catch (e) {}
        },

        async leaveRoom() {
            if (unsubRoom) { unsubRoom(); unsubRoom = null; }
            if (unsubPlayers) { unsubPlayers(); unsubPlayers = null; }
            if (heartbeatInterval) { clearInterval(heartbeatInterval); heartbeatInterval = null; }
            if (lobbyCountdownInterval) { clearInterval(lobbyCountdownInterval); lobbyCountdownInterval = null; }
            if (onlineMeetingTimer) { clearInterval(onlineMeetingTimer); onlineMeetingTimer = null; }
            if (!db || !fsApi) {
                mqttCloudRelay.leaveRoom();
                currentRoom = null;
                return;
            }
            if (db && fsApi && currentUser && currentRoom) {
                const r = currentRoom;
                const u = currentUser.uid;
                currentRoom = null;
                try {
                    await fsApi.deleteDoc(getPlayerDocRef(r, u));
                    const roomRef = getRoomDocRef(r);
                    const snap = await fsApi.getDoc(roomRef);
                    if (snap.exists()) {
                        const nextCount = Math.max(0, (snap.data().activeCount || 1) - 1);
                        await fsApi.updateDoc(roomRef, {
                            activeCount: nextCount,
                            status: nextCount === 0 ? 'WAITING' : snap.data().status,
                            updatedAt: Date.now()
                        });
                    }
                } catch (e) {}
            } else {
                currentRoom = null;
            }
        }
    };

    window.addEventListener('beforeunload', () => {
        if (window.mpBackend) window.mpBackend.leaveRoom();
    });
})();

/* ==========================================================================
   INITIALIZE GAME ON PAGE LOAD
   ========================================================================== */
function bootGame() {
    renderCountrySelection();
    renderCharacterCustomizer();
    requestAnimationFrame(drawCharacterPreviewLoop);
    try {
        const params = new URLSearchParams(window.location.search);
        const hashMatch = (window.location.hash || '').match(/room=([A-Za-z0-9_-]+)/i);
        const sharedRoom = (params.get('room') || (hashMatch ? hashMatch[1] : '')).trim().toUpperCase();
        if (sharedRoom) {
            const inp = document.getElementById('online-room-code');
            if (inp) inp.value = sharedRoom;
            selectConnectionMode('ONLINE');
        }
    } catch (e) {}
    requestAnimationFrame(gameLoop);
}

if (document.readyState === 'complete') {
    bootGame();
} else {
    window.addEventListener('load', bootGame);
}